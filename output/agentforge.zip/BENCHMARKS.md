# AgentForge -- Benchmarks

Generated: 2026-02-08

## Test Suite Summary

109 tests across 9 test files. All unit tests run with mocked providers (no API keys required).

| Module | Test File | Tests | Description |
|--------|-----------|-------|-------------|
| Client | `test_client.py` | ~16 | Orchestrator: chat, stream, fallback, provider routing |
| CLI | `test_cli.py` | ~12 | Click commands: chat, stream, benchmark, health |
| Cost Tracker | `test_cost_tracker.py` | ~12 | Per-request cost, provider breakdown, session totals |
| Prompt Template | `test_prompt_template.py` | ~14 | Variable extraction, rendering, built-in templates |
| Rate Limiter | `test_rate_limiter.py` | ~14 | Token bucket, burst handling, per-provider limits |
| Retry | `test_retry.py` | ~12 | Exponential backoff, jitter, retryable exceptions |
| Structured Output | `test_structured.py` | ~12 | JSON extraction, schema validation, retry with LLM |
| Tools | `test_tools.py` | ~14 | Tool definition, registration, execution pipeline |
| Integration | `test_integration.py` | ~3 | End-to-end with real providers (requires API keys) |
| **Total** | **9 files** | **109** | |

## Provider Benchmark (Mock)

| Provider   | Model        | Latency | Tokens | Est. Cost |
|------------|--------------|---------|--------|-----------|
| Mock       | mock-instant | ~128ms  | 45-95  | $0.0000   |

**Cost model (per 1K tokens)**: Claude $0.008 | OpenAI $0.006 | Perplexity $0.003 | Gemini $0.002

Run `agentforge benchmark` with API keys configured for live provider comparison.

## How to Reproduce

```bash
git clone https://github.com/ChunkyTortoise/ai-orchestrator.git
cd ai-orchestrator
pip install -r requirements.txt
make test
# or: python -m pytest tests/ -v

# Provider benchmarks (requires API keys)
agentforge benchmark
```

## Notes

- All unit tests use the mock provider for deterministic results
- Integration tests require API keys and are skipped by default
- Rate limiter tests use simulated time progression
