import asyncio

from agentforge import AIOrchestrator


async def main() -> None:
    orc = AIOrchestrator()
    response = await orc.chat("gemini", "Explain RAG in 2 sentences")
    print(response.content)


if __name__ == "__main__":
    asyncio.run(main())
