# Streamlit Cloud Deployment Guide

This guide covers deploying the AgentForge Flow Visualizer to Streamlit Cloud.

## Prerequisites

- GitHub account
- Repository pushed to GitHub (`ChunkyTortoise/ai-orchestrator`)
- Streamlit Cloud account (free tier available)

## Quick Deploy

[![Deploy to Streamlit Cloud](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://share.streamlit.io/deploy?repository=ChunkyTortoise/ai-orchestrator&branch=main&fileName=streamlit_app.py)

## Manual Deployment Steps

### 1. Push to GitHub

Ensure your code is pushed to the GitHub repository:

```bash
git add .
git commit -m "Prepare for Streamlit Cloud deployment"
git push origin main
```

### 2. Create Streamlit Cloud App

1. Go to [share.streamlit.io](https://share.streamlit.io)
2. Sign in with your GitHub account
3. Click "New app"
4. Select:
   - **Repository**: `ChunkyTortoise/ai-orchestrator`
   - **Branch**: `main`
   - **Main file path**: `streamlit_app.py`
5. Click "Deploy"

### 3. Configure Secrets (Optional)

If you want to use live LLM providers instead of mock data:

1. In Streamlit Cloud dashboard, go to your app settings
2. Navigate to "Secrets"
3. Add your API keys:

```toml
[api_keys]
anthropic_api_key = "sk-ant-your-key-here"
openai_api_key = "sk-your-key-here"
```

**Note**: The app works in demo mode without any API keys using mock data.

## Project Structure for Deployment

```
ai-orchestrator/
├── streamlit_app.py      # Entry point for Streamlit Cloud
├── app.py                # Main Streamlit application
├── requirements.txt      # Python dependencies
├── pyproject.toml        # Package configuration
├── .streamlit/
│   └── config.toml       # Streamlit configuration
└── agentforge/           # Core package (installed automatically)
    ├── __init__.py
    ├── tracing.py        # Used by the visualizer
    └── ...
```

## How It Works

1. **Entry Point**: Streamlit Cloud looks for `streamlit_app.py` by default
2. **Dependencies**: `requirements.txt` installs core deps; `pyproject.toml` defines the package
3. **Demo Mode**: The app includes mock data generation, so it works without API keys
4. **Live Mode**: With API keys configured, the EventCollector can capture real traces

## Local Development

Run locally with:

```bash
# Clone the repository
git clone https://github.com/ChunkyTortoise/ai-orchestrator.git
cd ai-orchestrator

# Install dependencies
pip install -e .

# Run the Streamlit app
streamlit run streamlit_app.py
```

## Troubleshooting

### App won't start
- Check that `streamlit_app.py` exists in the root directory
- Verify `requirements.txt` has all necessary dependencies
- Check Streamlit Cloud logs for specific errors

### Import errors
- Ensure `agentforge/` directory has `__init__.py`
- The package is installed via `pip install -e .` automatically

### Missing features
- Some features require API keys (set in Streamlit secrets)
- Demo mode uses mock data for visualization

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ANTHROPIC_API_KEY` | No | For live Claude API calls |
| `OPENAI_API_KEY` | No | For live OpenAI API calls |

The app functions fully in demo mode without these keys.

## Updating the Deployment

Any push to the `main` branch automatically triggers a redeploy on Streamlit Cloud.

```bash
git add .
git commit -m "Update app"
git push origin main
```

## Resources

- [Streamlit Cloud Documentation](https://docs.streamlit.io/streamlit-cloud)
- [AgentForge README](./README.md)
- [Streamlit App URL](https://ct-agentforge.streamlit.app)
