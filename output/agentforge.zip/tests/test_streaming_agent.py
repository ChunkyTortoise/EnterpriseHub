"""Tests for the streaming ReAct agent."""

from __future__ import annotations

import pytest

from agentforge.streaming_agent import (
    AgentStreamEvent,
    StreamAggregator,
    StreamEventType,
    StreamingReActAgent,
)
from agentforge.tools import ToolCall, ToolRegistry
from agentforge.tracing import EventCollector


# ---- Helpers ----


def _make_registry() -> ToolRegistry:
    """Create a registry with simple test tools."""
    reg = ToolRegistry()
    reg.register(
        "add",
        "Add two numbers",
        {"type": "object", "properties": {"a": {"type": "number"}, "b": {"type": "number"}}},
        handler=lambda a, b: float(a) + float(b),
    )
    return reg


def _immediate_answer_fn(goal, history):
    """Returns final answer immediately."""
    return ("I know the answer", None, "42")


def _two_step_fn(goal, history):
    """First step calls tool, second returns answer."""
    if len(history) == 0:
        return (
            "Need to compute",
            ToolCall(name="add", arguments={"a": 2, "b": 3}, call_id="c1"),
            None,
        )
    return ("Got result", None, history[0]["observation"])


def _multi_step_fn(goal, history):
    """Three-step reasoning."""
    n = len(history)
    if n < 2:
        return (
            f"Step {n + 1}",
            ToolCall(name="add", arguments={"a": n, "b": n + 1}, call_id=f"c{n}"),
            None,
        )
    return ("Done", None, "completed")


def _error_reason_fn(goal, history):
    """Always raises an error."""
    raise RuntimeError("reasoning exploded")


def _no_action_fn(goal, history):
    """Thinks without acting, then answers."""
    if len(history) == 0:
        return ("Thinking deeply", None, None)
    return ("Got it", None, "thought-only answer")


async def _async_reason_fn(goal, history):
    """Async reason function."""
    return ("Async thought", None, "async answer")


# ---- Event Tests ----


class TestAgentStreamEvent:
    def test_create_event(self):
        event = AgentStreamEvent(
            event_type=StreamEventType.THOUGHT,
            content="Analyzing input",
            step_number=1,
        )
        assert event.event_type == StreamEventType.THOUGHT
        assert event.content == "Analyzing input"
        assert event.step_number == 1
        assert event.timestamp > 0

    def test_event_type_values(self):
        assert StreamEventType.THOUGHT.value == "thought"
        assert StreamEventType.ACTION.value == "action"
        assert StreamEventType.OBSERVATION.value == "observation"
        assert StreamEventType.FINAL.value == "final"
        assert StreamEventType.ERROR.value == "error"

    def test_event_metadata_default(self):
        event = AgentStreamEvent(
            event_type=StreamEventType.THOUGHT,
            content="test",
        )
        assert event.metadata == {}

    def test_event_with_metadata(self):
        event = AgentStreamEvent(
            event_type=StreamEventType.ACTION,
            content="tool call",
            metadata={"tool": "search"},
        )
        assert event.metadata["tool"] == "search"


# ---- Streaming Flow Tests ----


class TestStreamingReActAgent:
    @pytest.mark.asyncio
    async def test_immediate_answer(self):
        agent = StreamingReActAgent(ToolRegistry(), _immediate_answer_fn)
        events = []
        async for event in agent.stream("What?"):
            events.append(event)

        assert len(events) == 2  # thought + final
        assert events[0].event_type == StreamEventType.THOUGHT
        assert events[1].event_type == StreamEventType.FINAL
        assert events[1].content == "42"

    @pytest.mark.asyncio
    async def test_two_step_with_tool(self):
        reg = _make_registry()
        agent = StreamingReActAgent(reg, _two_step_fn)
        events = []
        async for event in agent.stream("Add numbers"):
            events.append(event)

        types = [e.event_type for e in events]
        assert StreamEventType.THOUGHT in types
        assert StreamEventType.ACTION in types
        assert StreamEventType.OBSERVATION in types
        assert StreamEventType.FINAL in types

    @pytest.mark.asyncio
    async def test_multi_step_reasoning(self):
        reg = _make_registry()
        agent = StreamingReActAgent(reg, _multi_step_fn)
        events = []
        async for event in agent.stream("Compute"):
            events.append(event)

        final_events = [e for e in events if e.event_type == StreamEventType.FINAL]
        assert len(final_events) == 1
        assert final_events[0].content == "completed"

    @pytest.mark.asyncio
    async def test_step_numbers_sequential(self):
        reg = _make_registry()
        agent = StreamingReActAgent(reg, _multi_step_fn)
        events = []
        async for event in agent.stream("Go"):
            events.append(event)

        thought_steps = [
            e.step_number for e in events if e.event_type == StreamEventType.THOUGHT
        ]
        assert thought_steps == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_empty_goal(self):
        agent = StreamingReActAgent(ToolRegistry(), _immediate_answer_fn)
        events = []
        async for event in agent.stream(""):
            events.append(event)

        assert len(events) == 1
        assert events[0].event_type == StreamEventType.ERROR
        assert "Empty" in events[0].content

    @pytest.mark.asyncio
    async def test_whitespace_goal(self):
        agent = StreamingReActAgent(ToolRegistry(), _immediate_answer_fn)
        events = []
        async for event in agent.stream("   "):
            events.append(event)

        assert len(events) == 1
        assert events[0].event_type == StreamEventType.ERROR

    @pytest.mark.asyncio
    async def test_error_handling(self):
        agent = StreamingReActAgent(ToolRegistry(), _error_reason_fn)
        events = []
        async for event in agent.stream("Fail"):
            events.append(event)

        assert len(events) == 1
        assert events[0].event_type == StreamEventType.ERROR
        assert "exploded" in events[0].content

    @pytest.mark.asyncio
    async def test_max_steps_reached(self):
        def never_finishes(goal, history):
            return ("Still thinking", None, None)

        agent = StreamingReActAgent(ToolRegistry(), never_finishes, max_steps=3)
        events = []
        async for event in agent.stream("Forever"):
            events.append(event)

        error_events = [e for e in events if e.event_type == StreamEventType.ERROR]
        assert len(error_events) == 1
        assert "Max steps" in error_events[0].content

    @pytest.mark.asyncio
    async def test_no_action_step(self):
        agent = StreamingReActAgent(ToolRegistry(), _no_action_fn)
        events = []
        async for event in agent.stream("Think"):
            events.append(event)

        obs = [e for e in events if e.event_type == StreamEventType.OBSERVATION]
        assert len(obs) == 1
        assert obs[0].content == "No action taken."

    @pytest.mark.asyncio
    async def test_tool_error_reported(self):
        def calls_missing(goal, history):
            if len(history) == 0:
                return (
                    "Try missing tool",
                    ToolCall(name="nonexistent", arguments={}, call_id="c1"),
                    None,
                )
            return ("Done", None, "recovered")

        agent = StreamingReActAgent(ToolRegistry(), calls_missing)
        events = []
        async for event in agent.stream("Missing"):
            events.append(event)

        obs = [e for e in events if e.event_type == StreamEventType.OBSERVATION]
        assert any("error" in o.content.lower() for o in obs)

    @pytest.mark.asyncio
    async def test_async_reason_fn(self):
        agent = StreamingReActAgent(ToolRegistry(), _async_reason_fn)
        events = []
        async for event in agent.stream("Async test"):
            events.append(event)

        assert any(e.event_type == StreamEventType.FINAL for e in events)
        final = [e for e in events if e.event_type == StreamEventType.FINAL][0]
        assert final.content == "async answer"

    @pytest.mark.asyncio
    async def test_event_collector_integration(self):
        collector = EventCollector()
        collector.start_span("stream-test")

        agent = StreamingReActAgent(
            ToolRegistry(), _immediate_answer_fn, event_collector=collector
        )
        async for _ in agent.stream("Traced"):
            pass

        span = collector.get_trace("stream-test")
        assert span is not None
        event_types = [e.event_type for e in span.events]
        assert "stream_start" in event_types
        assert "stream_final" in event_types

    @pytest.mark.asyncio
    async def test_action_metadata(self):
        reg = _make_registry()
        agent = StreamingReActAgent(reg, _two_step_fn)
        events = []
        async for event in agent.stream("Add"):
            events.append(event)

        actions = [e for e in events if e.event_type == StreamEventType.ACTION]
        assert len(actions) >= 1
        assert actions[0].metadata["tool"] == "add"


# ---- Aggregator Tests ----


class TestStreamAggregator:
    def test_empty_aggregator(self):
        agg = StreamAggregator()
        assert agg.events == []
        assert agg.thoughts == []
        assert agg.final_answer is None
        assert agg.step_count == 0

    def test_add_events(self):
        agg = StreamAggregator()
        agg.add_event(
            AgentStreamEvent(
                event_type=StreamEventType.THOUGHT, content="Thinking", step_number=1
            )
        )
        agg.add_event(
            AgentStreamEvent(
                event_type=StreamEventType.FINAL, content="Answer", step_number=1
            )
        )
        assert len(agg.events) == 2
        assert agg.thoughts == ["Thinking"]
        assert agg.final_answer == "Answer"

    def test_step_count(self):
        agg = StreamAggregator()
        for step in range(1, 4):
            agg.add_event(
                AgentStreamEvent(
                    event_type=StreamEventType.THOUGHT,
                    content=f"Step {step}",
                    step_number=step,
                )
            )
        assert agg.step_count == 3

    def test_observations(self):
        agg = StreamAggregator()
        agg.add_event(
            AgentStreamEvent(
                event_type=StreamEventType.OBSERVATION,
                content="Result: 42",
                step_number=1,
            )
        )
        assert agg.observations == ["Result: 42"]

    def test_actions(self):
        agg = StreamAggregator()
        agg.add_event(
            AgentStreamEvent(
                event_type=StreamEventType.ACTION,
                content="Calling tool",
                step_number=1,
                metadata={"tool": "search"},
            )
        )
        assert len(agg.actions) == 1
        assert agg.actions[0].metadata["tool"] == "search"

    def test_errors(self):
        agg = StreamAggregator()
        agg.add_event(
            AgentStreamEvent(
                event_type=StreamEventType.ERROR, content="Boom", step_number=0
            )
        )
        assert agg.errors == ["Boom"]

    def test_clear(self):
        agg = StreamAggregator()
        agg.add_event(
            AgentStreamEvent(
                event_type=StreamEventType.THOUGHT, content="test", step_number=1
            )
        )
        agg.clear()
        assert agg.events == []
        assert agg.step_count == 0

    def test_to_dict(self):
        agg = StreamAggregator()
        agg.add_event(
            AgentStreamEvent(
                event_type=StreamEventType.THOUGHT,
                content="Thinking",
                step_number=1,
            )
        )
        result = agg.to_dict()
        assert result["thoughts"] == ["Thinking"]
        assert result["step_count"] == 1
        assert result["final_answer"] is None
        assert len(result["events"]) == 1

    @pytest.mark.asyncio
    async def test_aggregator_with_stream(self):
        agent = StreamingReActAgent(ToolRegistry(), _immediate_answer_fn)
        agg = StreamAggregator()
        async for event in agent.stream("Test"):
            agg.add_event(event)

        assert agg.final_answer == "42"
        assert len(agg.thoughts) == 1
        assert agg.step_count == 1


# ---- Partial JSON Parsing Tests ----


class TestPartialJsonParsing:
    def test_complete_json(self):
        agg = StreamAggregator()
        result = agg.feed_partial_json('{"name": "test", "value": 42}')
        assert result is not None
        assert result["name"] == "test"
        assert result["value"] == 42

    def test_partial_then_complete(self):
        agg = StreamAggregator()
        assert agg.feed_partial_json('{"name":') is None
        result = agg.feed_partial_json(' "test"}')
        assert result is not None
        assert result["name"] == "test"

    def test_multiple_chunks(self):
        agg = StreamAggregator()
        assert agg.feed_partial_json("{") is None
        assert agg.feed_partial_json('"key"') is None
        assert agg.feed_partial_json(": ") is None
        result = agg.feed_partial_json('"value"}')
        assert result is not None
        assert result["key"] == "value"

    def test_empty_input(self):
        agg = StreamAggregator()
        assert agg.feed_partial_json("") is None

    def test_nested_json(self):
        agg = StreamAggregator()
        result = agg.feed_partial_json('{"outer": {"inner": true}}')
        assert result is not None
        assert result["outer"]["inner"] is True

    def test_json_with_string_braces(self):
        agg = StreamAggregator()
        result = agg.feed_partial_json('{"text": "hello {world}"}')
        assert result is not None
        assert result["text"] == "hello {world}"
