"""Tests for the workflow DAG module."""

from __future__ import annotations

import pytest

from agentforge.workflow_dag import (
    DAGExecutor,
    ExecutionContext,
    RetryPolicy,
    WorkflowDAG,
    WorkflowEdge,
    WorkflowNode,
)
from agentforge.tracing import EventCollector


# ---- Helpers ----


def _simple_agent_fn(agent_id: str, input_data: dict) -> dict:
    """Synchronous agent function for testing."""
    return {"agent": agent_id, "processed": True, **input_data}


async def _async_agent_fn(agent_id: str, input_data: dict) -> dict:
    """Async agent function for testing."""
    return {"agent": agent_id, "processed": True, **input_data}


def _failing_agent_fn(agent_id: str, input_data: dict) -> dict:
    """Agent function that always fails."""
    raise RuntimeError(f"Agent {agent_id} failed")


# ---- Node Tests ----


class TestWorkflowNode:
    def test_create_node_minimal(self):
        node = WorkflowNode(agent_id="classifier")
        assert node.agent_id == "classifier"
        assert node.input_schema == {}
        assert node.output_schema == {}
        assert node.retry_policy.max_retries == 3

    def test_create_node_with_schemas(self):
        node = WorkflowNode(
            agent_id="summarizer",
            input_schema={"properties": {"text": {"type": "string"}}},
            output_schema={"properties": {"summary": {"type": "string"}}},
        )
        assert "text" in node.input_schema["properties"]
        assert "summary" in node.output_schema["properties"]

    def test_create_node_with_retry_policy(self):
        policy = RetryPolicy(max_retries=5, backoff_seconds=2.0)
        node = WorkflowNode(agent_id="retrier", retry_policy=policy)
        assert node.retry_policy.max_retries == 5
        assert node.retry_policy.backoff_seconds == 2.0

    def test_retry_policy_defaults(self):
        policy = RetryPolicy()
        assert policy.max_retries == 3
        assert policy.backoff_seconds == 1.0


# ---- Edge Tests ----


class TestWorkflowEdge:
    def test_create_edge_minimal(self):
        edge = WorkflowEdge(source="a", target="b")
        assert edge.source == "a"
        assert edge.target == "b"
        assert edge.condition is None
        assert edge.priority == 0

    def test_create_edge_with_condition(self):
        def cond(data):
            return data.get("confidence", 0) > 0.8

        edge = WorkflowEdge(source="a", target="b", condition=cond, priority=10)
        assert edge.condition is not None
        assert edge.priority == 10
        assert edge.condition({"confidence": 0.9}) is True
        assert edge.condition({"confidence": 0.5}) is False


# ---- DAG Structure Tests ----


class TestWorkflowDAG:
    def test_add_node(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        assert len(dag.nodes) == 1
        assert dag.get_node("a") is not None

    def test_add_duplicate_node_raises(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        with pytest.raises(ValueError, match="already exists"):
            dag.add_node(WorkflowNode(agent_id="a"))

    def test_add_edge(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_edge(WorkflowEdge(source="a", target="b"))
        assert len(dag.edges) == 1

    def test_add_edge_missing_source_raises(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="b"))
        with pytest.raises(ValueError, match="Source node not found"):
            dag.add_edge(WorkflowEdge(source="a", target="b"))

    def test_add_edge_missing_target_raises(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        with pytest.raises(ValueError, match="Target node not found"):
            dag.add_edge(WorkflowEdge(source="a", target="b"))

    def test_get_node_not_found(self):
        dag = WorkflowDAG()
        assert dag.get_node("nonexistent") is None

    def test_get_outgoing_edges_sorted_by_priority(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_node(WorkflowNode(agent_id="c"))
        dag.add_edge(WorkflowEdge(source="a", target="b", priority=1))
        dag.add_edge(WorkflowEdge(source="a", target="c", priority=10))
        outgoing = dag.get_outgoing_edges("a")
        assert outgoing[0].target == "c"
        assert outgoing[1].target == "b"


# ---- Topological Sort Tests ----


class TestTopologicalSort:
    def test_linear_dag(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_node(WorkflowNode(agent_id="c"))
        dag.add_edge(WorkflowEdge(source="a", target="b"))
        dag.add_edge(WorkflowEdge(source="b", target="c"))
        order = dag.topological_sort()
        assert order == ["a", "b", "c"]

    def test_diamond_dag(self):
        dag = WorkflowDAG()
        for nid in ["a", "b", "c", "d"]:
            dag.add_node(WorkflowNode(agent_id=nid))
        dag.add_edge(WorkflowEdge(source="a", target="b"))
        dag.add_edge(WorkflowEdge(source="a", target="c"))
        dag.add_edge(WorkflowEdge(source="b", target="d"))
        dag.add_edge(WorkflowEdge(source="c", target="d"))
        order = dag.topological_sort()
        assert order.index("a") < order.index("b")
        assert order.index("a") < order.index("c")
        assert order.index("b") < order.index("d")
        assert order.index("c") < order.index("d")

    def test_single_node(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="solo"))
        order = dag.topological_sort()
        assert order == ["solo"]

    def test_disconnected_nodes(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="x"))
        dag.add_node(WorkflowNode(agent_id="y"))
        order = dag.topological_sort()
        assert set(order) == {"x", "y"}
        assert len(order) == 2


# ---- Cycle Detection Tests ----


class TestCycleDetection:
    def test_simple_cycle_raises(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_edge(WorkflowEdge(source="a", target="b"))
        dag.add_edge(WorkflowEdge(source="b", target="a"))
        with pytest.raises(ValueError, match="Cycle detected"):
            dag.topological_sort()

    def test_three_node_cycle_raises(self):
        dag = WorkflowDAG()
        for nid in ["a", "b", "c"]:
            dag.add_node(WorkflowNode(agent_id=nid))
        dag.add_edge(WorkflowEdge(source="a", target="b"))
        dag.add_edge(WorkflowEdge(source="b", target="c"))
        dag.add_edge(WorkflowEdge(source="c", target="a"))
        with pytest.raises(ValueError, match="Cycle detected"):
            dag.topological_sort()

    def test_validate_reports_cycle(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_edge(WorkflowEdge(source="a", target="b"))
        dag.add_edge(WorkflowEdge(source="b", target="a"))
        errors = dag.validate()
        assert any("Cycle" in e for e in errors)


# ---- Validation Tests ----


class TestValidation:
    def test_valid_dag_no_errors(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_edge(WorkflowEdge(source="a", target="b"))
        assert dag.validate() == []

    def test_schema_incompatibility(self):
        dag = WorkflowDAG()
        dag.add_node(
            WorkflowNode(
                agent_id="a",
                output_schema={"properties": {"summary": {"type": "string"}}},
            )
        )
        dag.add_node(
            WorkflowNode(
                agent_id="b",
                input_schema={
                    "properties": {"text": {"type": "string"}},
                    "required": ["text"],
                },
            )
        )
        dag.add_edge(WorkflowEdge(source="a", target="b"))
        errors = dag.validate()
        assert len(errors) == 1
        assert "text" in errors[0]

    def test_schema_compatible(self):
        dag = WorkflowDAG()
        dag.add_node(
            WorkflowNode(
                agent_id="a",
                output_schema={"properties": {"text": {"type": "string"}}},
            )
        )
        dag.add_node(
            WorkflowNode(
                agent_id="b",
                input_schema={
                    "properties": {"text": {"type": "string"}},
                    "required": ["text"],
                },
            )
        )
        dag.add_edge(WorkflowEdge(source="a", target="b"))
        assert dag.validate() == []


# ---- DAG Executor Tests ----


class TestDAGExecutor:
    @pytest.mark.asyncio
    async def test_execute_linear_sync(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_edge(WorkflowEdge(source="a", target="b"))

        executor = DAGExecutor(dag, _simple_agent_fn)
        ctx = await executor.execute({"seed": 42})
        assert "a" in ctx.results
        assert "b" in ctx.results
        assert ctx.results["a"]["agent"] == "a"
        assert len(ctx.errors) == 0

    @pytest.mark.asyncio
    async def test_execute_linear_async(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_edge(WorkflowEdge(source="a", target="b"))

        executor = DAGExecutor(dag, _async_agent_fn)
        ctx = await executor.execute({"seed": 42})
        assert "a" in ctx.results
        assert "b" in ctx.results
        assert len(ctx.errors) == 0

    @pytest.mark.asyncio
    async def test_execute_with_failure(self):
        dag = WorkflowDAG()
        dag.add_node(
            WorkflowNode(
                agent_id="a",
                retry_policy=RetryPolicy(max_retries=0, backoff_seconds=0),
            )
        )
        executor = DAGExecutor(dag, _failing_agent_fn)
        ctx = await executor.execute()
        assert "a" in ctx.errors
        assert "failed" in ctx.errors["a"]

    @pytest.mark.asyncio
    async def test_execute_memoization(self):
        call_count = 0

        def counting_fn(agent_id, data):
            nonlocal call_count
            call_count += 1
            return {"count": call_count}

        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        executor = DAGExecutor(dag, counting_fn)
        ctx = await executor.execute()
        assert call_count == 1
        assert ctx.results["a"]["count"] == 1

    @pytest.mark.asyncio
    async def test_execute_traces_recorded(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_edge(WorkflowEdge(source="a", target="b"))

        executor = DAGExecutor(dag, _simple_agent_fn)
        ctx = await executor.execute()
        assert len(ctx.traces) == 2
        assert all(t["success"] for t in ctx.traces)

    @pytest.mark.asyncio
    async def test_execute_with_event_collector(self):
        collector = EventCollector()
        collector.start_span("dag-test")

        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        executor = DAGExecutor(dag, _simple_agent_fn, event_collector=collector)
        await executor.execute()

        span = collector.get_trace("dag-test")
        assert span is not None
        event_types = [e.event_type for e in span.events]
        assert "dag_start" in event_types
        assert "dag_end" in event_types

    @pytest.mark.asyncio
    async def test_execute_conditional_edge_skip(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))

        # Condition that will not be met
        dag.add_edge(
            WorkflowEdge(
                source="a",
                target="b",
                condition=lambda data: data.get("confidence", 0) > 0.8,
            )
        )

        def low_confidence_fn(agent_id, data):
            return {"confidence": 0.3}

        executor = DAGExecutor(dag, low_confidence_fn)
        ctx = await executor.execute()
        assert "a" in ctx.results
        assert "b" not in ctx.results  # skipped by condition

    @pytest.mark.asyncio
    async def test_execute_conditional_edge_pass(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_edge(
            WorkflowEdge(
                source="a",
                target="b",
                condition=lambda data: data.get("confidence", 0) > 0.5,
            )
        )

        def high_confidence_fn(agent_id, data):
            return {"confidence": 0.9}

        executor = DAGExecutor(dag, high_confidence_fn)
        ctx = await executor.execute()
        assert "a" in ctx.results
        assert "b" in ctx.results

    @pytest.mark.asyncio
    async def test_execute_cycle_returns_error(self):
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="a"))
        dag.add_node(WorkflowNode(agent_id="b"))
        dag.add_edge(WorkflowEdge(source="a", target="b"))
        dag.add_edge(WorkflowEdge(source="b", target="a"))

        executor = DAGExecutor(dag, _simple_agent_fn)
        ctx = await executor.execute()
        assert "_dag" in ctx.errors

    @pytest.mark.asyncio
    async def test_execute_retry_on_failure(self):
        attempts = 0

        def flaky_fn(agent_id, data):
            nonlocal attempts
            attempts += 1
            if attempts < 3:
                raise RuntimeError("flaky")
            return {"ok": True}

        dag = WorkflowDAG()
        dag.add_node(
            WorkflowNode(
                agent_id="flaky",
                retry_policy=RetryPolicy(max_retries=3, backoff_seconds=0),
            )
        )
        executor = DAGExecutor(dag, flaky_fn)
        ctx = await executor.execute()
        assert "flaky" in ctx.results
        assert attempts == 3


class TestExecutionContext:
    def test_defaults(self):
        ctx = ExecutionContext()
        assert ctx.results == {}
        assert ctx.traces == []
        assert ctx.errors == {}
