"""Tests for CostTracker."""

import threading

from agentforge.cost_tracker import CostTracker

# ── Single Record ───────────────────────────────────────────────────────────


def test_single_record():
    """Recording a single API call computes correct cost."""
    tracker = CostTracker()
    record = tracker.record(
        "claude", "claude-3-5-sonnet", input_tokens=1000, output_tokens=500
    )

    assert record.provider == "claude"
    assert record.model == "claude-3-5-sonnet"
    assert record.input_tokens == 1000
    assert record.output_tokens == 500
    # claude-3-5-sonnet: $3/M input, $15/M output
    assert abs(record.input_cost_usd - 0.003) < 1e-9
    assert abs(record.output_cost_usd - 0.0075) < 1e-9
    assert abs(record.total_cost_usd - 0.0105) < 1e-9


def test_single_record_session_cost():
    """Session cost reflects the single recorded call."""
    tracker = CostTracker()
    tracker.record("openai", "gpt-4o", input_tokens=2000, output_tokens=1000)

    session = tracker.get_session_cost()
    assert session["total_input_tokens"] == 2000
    assert session["total_output_tokens"] == 1000
    assert session["record_count"] == 1
    # gpt-4o: $2.50/M input, $10/M output
    expected = (2000 / 1_000_000) * 2.50 + (1000 / 1_000_000) * 10.0
    assert abs(session["total_cost_usd"] - expected) < 1e-9


# ── Multiple Records ────────────────────────────────────────────────────────


def test_multiple_records_accumulate():
    """Multiple records are accumulated in session cost."""
    tracker = CostTracker()
    tracker.record("claude", "claude-3-5-sonnet", input_tokens=1000, output_tokens=500)
    tracker.record("claude", "claude-3-5-sonnet", input_tokens=2000, output_tokens=1000)

    session = tracker.get_session_cost()
    assert session["total_input_tokens"] == 3000
    assert session["total_output_tokens"] == 1500
    assert session["record_count"] == 2


# ── Per-Provider Aggregation ────────────────────────────────────────────────


def test_cost_by_provider():
    """Costs are correctly grouped by provider."""
    tracker = CostTracker()
    tracker.record("claude", "claude-3-5-sonnet", input_tokens=1000, output_tokens=500)
    tracker.record("openai", "gpt-4o", input_tokens=2000, output_tokens=1000)
    tracker.record("claude", "claude-3-5-sonnet", input_tokens=500, output_tokens=200)

    by_provider = tracker.get_cost_by_provider()
    assert "claude" in by_provider
    assert "openai" in by_provider
    assert by_provider["claude"]["call_count"] == 2
    assert by_provider["openai"]["call_count"] == 1
    assert by_provider["claude"]["input_tokens"] == 1500
    assert by_provider["openai"]["input_tokens"] == 2000


def test_cost_by_model():
    """Costs are correctly grouped by model."""
    tracker = CostTracker()
    tracker.record("openai", "gpt-4o", input_tokens=1000, output_tokens=500)
    tracker.record("openai", "gpt-4o-mini", input_tokens=5000, output_tokens=2000)

    by_model = tracker.get_cost_by_model()
    assert "gpt-4o" in by_model
    assert "gpt-4o-mini" in by_model
    assert by_model["gpt-4o"]["call_count"] == 1
    assert by_model["gpt-4o-mini"]["call_count"] == 1


# ── Reset ───────────────────────────────────────────────────────────────────


def test_reset_clears_records():
    """Reset clears all recorded usage data."""
    tracker = CostTracker()
    tracker.record("claude", "claude-3-5-sonnet", input_tokens=1000, output_tokens=500)
    tracker.record("openai", "gpt-4o", input_tokens=2000, output_tokens=1000)

    tracker.reset()

    session = tracker.get_session_cost()
    assert session["total_input_tokens"] == 0
    assert session["total_output_tokens"] == 0
    assert session["total_cost_usd"] == 0.0
    assert session["record_count"] == 0
    assert tracker.get_cost_by_provider() == {}


# ── Unknown Model Defaults ──────────────────────────────────────────────────


def test_unknown_model_uses_fallback_rate():
    """Unknown models use the default fallback rate."""
    tracker = CostTracker()
    record = tracker.record(
        "custom", "my-custom-model", input_tokens=1_000_000, output_tokens=1_000_000
    )

    # Fallback: $1.00/M input, $3.00/M output
    assert abs(record.input_cost_usd - 1.0) < 1e-9
    assert abs(record.output_cost_usd - 3.0) < 1e-9


def test_custom_rates_override_defaults():
    """Custom rates override built-in defaults."""
    tracker = CostTracker(custom_rates={"gpt-4o": (5.0, 20.0)})
    record = tracker.record(
        "openai", "gpt-4o", input_tokens=1_000_000, output_tokens=1_000_000
    )

    assert abs(record.input_cost_usd - 5.0) < 1e-9
    assert abs(record.output_cost_usd - 20.0) < 1e-9


def test_prefix_matching_for_model_variants():
    """Model variants match by prefix (e.g. claude-3-5-sonnet-20241022)."""
    tracker = CostTracker()
    record = tracker.record(
        "claude",
        "claude-3-5-sonnet-20241022",
        input_tokens=1_000_000,
        output_tokens=1_000_000,
    )
    # Should match "claude-3-5-sonnet" rate: $3/M input, $15/M output
    assert abs(record.input_cost_usd - 3.0) < 1e-9
    assert abs(record.output_cost_usd - 15.0) < 1e-9


# ── Thread Safety ───────────────────────────────────────────────────────────


def test_concurrent_access():
    """CostTracker is thread-safe under concurrent writes."""
    tracker = CostTracker()
    num_threads = 10
    records_per_thread = 100

    def writer():
        for _ in range(records_per_thread):
            tracker.record(
                "claude", "claude-3-5-sonnet", input_tokens=100, output_tokens=50
            )

    threads = [threading.Thread(target=writer) for _ in range(num_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    session = tracker.get_session_cost()
    expected_count = num_threads * records_per_thread
    assert session["record_count"] == expected_count
    assert session["total_input_tokens"] == expected_count * 100
    assert session["total_output_tokens"] == expected_count * 50
