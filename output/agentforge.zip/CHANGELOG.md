# Changelog

All notable changes to AgentForge will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

### Added
- Dockerfile and docker-compose.yml for containerized deployment
- Architecture Decision Records (ADRs) for key design choices
- Comprehensive benchmark suite (runs without API keys)
- SECURITY.md vulnerability disclosure policy
- CODE_OF_CONDUCT.md (Contributor Covenant v2.0)
- Mermaid architecture diagram in README

## [0.6.0] - 2026-02-08

### Added — Wave 6: Agent Intelligence (+134 tests)
- **Agent Memory** (`agent_memory.py`) — persistent memory store with TTL-based expiry, relevance scoring, and conversation context reconstruction
- **Guardrails Engine** (`guardrails.py`) — configurable content filters, token budget enforcement, PII detection, and topic boundaries with allow/deny lists
- **Multi-Agent Mesh** (`multi_agent.py`) — agent registration, message-passing coordination, consensus-based decision making (majority/unanimous/weighted), and confidence-gated handoff protocol
- **Streaming ReAct Agent** (`streaming_agent.py`) — real-time thought/action/observation streaming with event aggregation and backpressure support
- **Workflow DAG** (`workflow_dag.py`) — directed acyclic graph execution engine with parallel node execution, retry policies, and conditional branching
- **Conversation Memory** (`memory.py`) — sliding window and summary-based memory strategies with semantic search over history

### Changed
- Test suite expanded to 423+ tests across 21 test files

## [0.5.0] - 2026-02-06

### Added — Wave 5: Autonomous Agents (+75 tests)
- **ReAct Agent** (`react_agent.py`) — Reasoning + Acting loop with configurable max iterations, loop detection, and structured Thought/Action/Observation traces
- **Evaluation Framework** (`evaluation.py`) — automated agent evaluation with configurable eval cases, pass/fail criteria, and aggregate reporting
- **Model Registry** (`model_registry.py`) — version-tracked model catalog with capability metadata, cost comparison, and A/B model selection
- **REST API** (`api.py`) — FastAPI HTTP endpoints for chat, streaming, health checks, and provider benchmarks
- **Tracing & Observability** (`tracing.py`) — event collection with span hierarchy, provider attribution, and latency tracking
- **Streamlit Visualizer** (`viz/`) — interactive flow diagrams and metrics dashboards for trace inspection

## [0.4.0] - 2026-02-04

### Added — Wave 4: Production Hardening
- **Structured Output** (`structured.py`) — JSON extraction from LLM responses with schema validation and type coercion
- **Cost Tracker** (`cost_tracker.py`) — per-request cost recording with provider-level breakdown and session totals
- **Tools & Function Calling** (`tools.py`) — tool definition, registration, provider-agnostic formatting, and execution engine

## [0.3.0] - 2026-02-01

### Added — Wave 3: Reliability
- **Retry with Backoff** (`retry.py`) — exponential backoff with jitter, configurable retryable exceptions, and max attempts
- **Rate Limiter** (`rate_limiter.py`) — token-bucket algorithm with separate RPM and TPM buckets per provider
- **Prompt Templates** (`prompt_template.py`) — reusable templates with `{{variable}}` substitution and built-in variable support

## [0.2.0] - 2026-01-28

### Added — Wave 2: Multi-Provider
- Claude provider (Anthropic API)
- OpenAI provider (GPT-4o)
- Perplexity provider (Sonar)
- Provider fallback routing
- Click CLI with streaming support

## [0.1.0] - 2026-01-25

### Added — Wave 1: Foundation
- `AIOrchestrator` unified async interface
- Gemini provider (Google AI)
- Mock provider for testing
- Initial test suite (35 tests)
- GitHub Actions CI (Python 3.10, 3.11, 3.12)
