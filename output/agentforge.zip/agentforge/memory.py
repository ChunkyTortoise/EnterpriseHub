"""Agent memory systems: sliding window, summary, and semantic search.

Provides conversation memory with token budgets, automatic summarization,
and TF-IDF-based semantic search over message history.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class MemoryEntry:
    """A single message in memory."""

    role: str
    content: str
    timestamp: float = field(default_factory=time.time)
    metadata: dict = field(default_factory=dict)


@dataclass
class MemorySearchResult:
    """Result of a semantic search over memory."""

    entry: MemoryEntry
    score: float


def _estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token."""
    return max(1, len(text) // 4)


class ConversationMemory:
    """General-purpose conversation memory with search and summarization.

    Stores messages and supports token-budgeted retrieval, keyword-based
    summarization, and TF-IDF semantic search.
    """

    def __init__(self) -> None:
        self._entries: list[MemoryEntry] = []

    @property
    def entries(self) -> list[MemoryEntry]:
        return list(self._entries)

    def add(self, role: str, content: str, metadata: dict | None = None) -> MemoryEntry:
        """Add a message to memory."""
        entry = MemoryEntry(role=role, content=content, metadata=metadata or {})
        self._entries.append(entry)
        return entry

    def get_context(self, max_tokens: int = 4000) -> list[MemoryEntry]:
        """Get most recent messages fitting within the token budget.

        Returns entries in chronological order (oldest first).
        """
        result: list[MemoryEntry] = []
        budget = max_tokens
        for entry in reversed(self._entries):
            cost = _estimate_tokens(entry.content)
            if cost > budget:
                break
            result.append(entry)
            budget -= cost
        result.reverse()
        return result

    def summarize(self, messages: list[MemoryEntry]) -> str:
        """Compress messages to a summary string via keyword extraction.

        Extracts top TF-IDF terms from each message and merges them
        into a concise summary.
        """
        if not messages:
            return ""
        texts = [m.content for m in messages if m.content.strip()]
        if not texts:
            return ""
        if len(texts) == 1:
            words = texts[0].split()
            return " ".join(words[:20])
        try:
            vectorizer = TfidfVectorizer(max_features=20, stop_words="english")
            vectorizer.fit_transform(texts)
            keywords = vectorizer.get_feature_names_out().tolist()
        except ValueError:
            keywords = []
        if not keywords:
            return texts[0][:100]
        roles = {m.role for m in messages}
        role_str = ", ".join(sorted(roles))
        return f"Summary ({role_str}): {', '.join(keywords)}"

    def search(self, query: str, top_k: int = 3) -> list[MemorySearchResult]:
        """Semantic search over memory using TF-IDF cosine similarity.

        Args:
            query: The search query.
            top_k: Maximum number of results.

        Returns:
            Top-k matching entries sorted by descending score.
        """
        if not self._entries or not query.strip():
            return []
        texts = [e.content for e in self._entries]
        corpus = texts + [query]
        try:
            vectorizer = TfidfVectorizer()
            tfidf = vectorizer.fit_transform(corpus)
        except ValueError:
            return []
        query_vec = tfidf[-1:]
        doc_vecs = tfidf[:-1]
        sims = cosine_similarity(query_vec, doc_vecs)[0]
        scored = [(self._entries[i], float(sims[i])) for i in range(len(self._entries))]
        scored.sort(key=lambda x: x[1], reverse=True)
        results = []
        for entry, score in scored[:top_k]:
            if score > 0:
                results.append(MemorySearchResult(entry=entry, score=score))
        return results

    def clear(self) -> None:
        """Reset memory."""
        self._entries.clear()

    def __len__(self) -> int:
        return len(self._entries)


class SlidingWindowMemory(ConversationMemory):
    """Memory that keeps only the last N messages.

    Older messages are automatically dropped when the window overflows.
    """

    def __init__(self, window_size: int = 20) -> None:
        super().__init__()
        self._window_size = window_size

    @property
    def window_size(self) -> int:
        return self._window_size

    def add(self, role: str, content: str, metadata: dict | None = None) -> MemoryEntry:
        entry = super().add(role, content, metadata)
        while len(self._entries) > self._window_size:
            self._entries.pop(0)
        return entry


class SummaryMemory(ConversationMemory):
    """Memory that auto-summarizes when message count exceeds a threshold.

    When the number of messages exceeds ``threshold``, the oldest half is
    compressed into a summary entry and replaced.
    """

    def __init__(self, threshold: int = 20) -> None:
        super().__init__()
        self._threshold = threshold

    @property
    def threshold(self) -> int:
        return self._threshold

    def add(self, role: str, content: str, metadata: dict | None = None) -> MemoryEntry:
        entry = super().add(role, content, metadata)
        if len(self._entries) > self._threshold:
            self._compact()
        return entry

    def _compact(self) -> None:
        """Summarize the oldest half of entries and replace them."""
        midpoint = len(self._entries) // 2
        old_entries = self._entries[:midpoint]
        summary_text = self.summarize(old_entries)
        summary_entry = MemoryEntry(
            role="system",
            content=summary_text,
            metadata={"is_summary": True, "summarized_count": len(old_entries)},
        )
        self._entries = [summary_entry] + self._entries[midpoint:]
