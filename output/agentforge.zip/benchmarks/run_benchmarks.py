import argparse
import asyncio
from time import time

from agentforge import AIOrchestrator


async def run_benchmarks(prompt: str = "Say hello", output: str | None = None) -> None:
    orc = AIOrchestrator(max_tokens=50)
    rows = []
    providers = ["gemini", "perplexity", "claude", "openai"]

    for provider in providers:
        if not orc._providers[provider].is_configured():
            rows.append((provider, "skipped", "-", "-"))
            continue
        start = time()
        try:
            response = await orc.chat(provider, prompt)
            elapsed = (time() - start) * 1000
            rows.append(
                (provider, f"{elapsed:.0f}ms", len(response.content), response.model)
            )
        except Exception as exc:
            rows.append((provider, f"error: {exc}", "-", "-"))

    table = [
        "| Provider | Latency | Response Length | Model |",
        "|----------|---------|-----------------|-------|",
    ]
    for provider, latency, length, model in rows:
        table.append(f"| {provider} | {latency} | {length} | {model} |")

    output_text = "\n".join(table)
    print(output_text)

    if output:
        with open(output, "w", encoding="utf-8") as handle:
            handle.write(output_text + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run AgentForge provider benchmarks")
    parser.add_argument("--prompt", default="Say hello", help="Prompt to send")
    parser.add_argument("--output", help="Write markdown table to file")
    args = parser.parse_args()
    asyncio.run(run_benchmarks(prompt=args.prompt, output=args.output))


if __name__ == "__main__":
    main()
