# AgentForge Benchmark Results

**Date**: 2026-02-09 03:40:37

| Operation | Iterations | P50 (ms) | P95 (ms) | P99 (ms) | Throughput |
|-----------|-----------|----------|----------|----------|------------|
| Tool Dispatch (50 tools) | 10,000 | 0.0002 | 0.0003 | 0.0003 | 4,375,923 ops/sec |
| ReAct Loop (5 steps) | 2,000 | 0.0048 | 0.0054 | 0.0642 | 34,768 ops/sec |
| Agent Message Routing (10 agents) | 5,000 | 0.0044 | 0.0047 | 0.0145 | 26,424 ops/sec |
| Token Estimation + Cost Calc | 5,000 | 0.0016 | 0.0037 | 0.007 | 72,048 ops/sec |
| Rate Limiter Check | 10,000 | 0.0004 | 0.0005 | 0.0005 | 243,627 ops/sec |

> All benchmarks use mock data. No external API keys required.
