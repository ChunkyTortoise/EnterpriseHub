# ADR 0002: Token Bucket Rate Limiting

## Status
Accepted

## Context
LLM APIs enforce strict rate limits. Exceeding these limits triggers 429 errors and can result in account-level throttling or temporary bans. Naive retry-after-failure approaches lead to burst-then-wait patterns that waste time and degrade user experience. We need a proactive rate limiting strategy that distributes requests smoothly.

## Decision
Implement the token-bucket algorithm with separate buckets per provider. Each provider gets two independent buckets: one for tokens-per-minute (TPM) and one for requests-per-minute (RPM). Bucket size and refill rate are configurable per provider to match their published limits. Requests that would exceed the bucket are queued rather than rejected.

## Consequences
- **Positive**: Smooth request distribution eliminates burst-then-wait patterns. Memory overhead is minimal at ~2KB per bucket. Configurable per provider allows precise tuning. Queue-based overflow prevents dropped requests.
- **Negative**: Requires per-provider tuning as rate limits change. Bucket overflow during sudden traffic spikes can cause increased latency. Distributed deployments need shared bucket state (e.g., via Redis) to maintain accuracy.
