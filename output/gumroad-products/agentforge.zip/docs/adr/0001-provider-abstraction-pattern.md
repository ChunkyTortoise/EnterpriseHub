# ADR 0001: Provider Abstraction Pattern

## Status
Accepted

## Context
We need to support multiple LLM providers (Claude, GPT-4, Gemini) without coupling business logic to any specific API. Each provider has different authentication mechanisms, pricing models, rate limits, and response formats. Hardcoding provider-specific logic throughout the codebase would make switching or adding providers expensive and error-prone.

## Decision
Abstract the provider interface using the adapter pattern. Each provider adapter implements a common interface with three core methods: `complete()`, `stream()`, and `count_tokens()`. Provider selection happens at runtime via configuration, allowing the same business logic to work with any supported provider. Provider-specific configuration (API keys, endpoints, model names) is isolated in adapter initialization.

## Consequences
- **Positive**: Adding a new provider requires only ~100 lines of adapter code. Business logic remains completely provider-agnostic. Testing is simplified through mock adapters. Provider switching can happen without code changes.
- **Negative**: Provider-specific features (e.g., Claude's extended thinking, GPT-4's function calling) require interface extensions or escape hatches. The unified API represents a lowest-common-denominator approach that may not fully leverage each provider's unique capabilities.
