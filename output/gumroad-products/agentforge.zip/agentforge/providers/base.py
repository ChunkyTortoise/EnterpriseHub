"""Base provider interface for AgentForge."""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, AsyncGenerator

from ..exceptions import AuthenticationError

if TYPE_CHECKING:
    from ..client import AIOrchestrator
    from ..client_types import AIResponse


class ProviderBase(ABC):
    name: str
    default_model: str
    env_key: str

    def __init__(self, orchestrator: AIOrchestrator) -> None:
        self.orchestrator = orchestrator

    def is_configured(self) -> bool:
        return bool(os.getenv(self.env_key))

    def _require_key(self) -> str:
        key = os.getenv(self.env_key)
        if not key:
            raise AuthenticationError(self.name, f"Missing {self.env_key}")
        return key

    @abstractmethod
    async def chat(
        self,
        prompt: str,
        system: str,
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> AIResponse:
        raise NotImplementedError

    @abstractmethod
    async def stream(
        self,
        prompt: str,
        system: str,
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> AsyncGenerator[str, None]:
        raise NotImplementedError


def extract_sse_data(line: str) -> str | None:
    if not line:
        return None
    if line.startswith("data:"):
        return line[5:].strip()
    if line.startswith("event:"):
        return None
    return line.strip()
