"""Per-request cost tracking for LLM API usage."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Optional


@dataclass
class UsageRecord:
    """Single API call usage record."""

    provider: str
    model: str
    input_tokens: int
    output_tokens: int
    input_cost_usd: float
    output_cost_usd: float

    @property
    def total_cost_usd(self) -> float:
        return self.input_cost_usd + self.output_cost_usd


# Cost rates per million tokens: (input_rate, output_rate)
DEFAULT_COST_RATES: dict[str, tuple[float, float]] = {
    # Claude models
    "claude-3-5-sonnet": (3.0, 15.0),
    "claude-3-5-sonnet-20241022": (3.0, 15.0),
    "claude-3-haiku": (0.25, 1.25),
    "claude-3-opus": (15.0, 75.0),
    # OpenAI models
    "gpt-4o": (2.50, 10.0),
    "gpt-4o-mini": (0.15, 0.60),
    "gpt-4-turbo": (10.0, 30.0),
    # Google models
    "gemini-1.5-pro": (1.25, 5.0),
    "gemini-1.5-flash": (0.075, 0.30),
    "gemini-2.0-flash": (0.10, 0.40),
    # Perplexity models
    "sonar-reasoning-pro": (1.0, 5.0),
    "sonar-pro": (0.60, 3.0),
    "sonar": (0.20, 1.0),
}

# Fallback rate for unknown models (per million tokens)
_DEFAULT_FALLBACK_RATE: tuple[float, float] = (1.0, 3.0)


class CostTracker:
    """Thread-safe tracker for LLM API usage costs.

    Tracks input/output tokens and computes estimated USD cost based on
    per-model pricing rates.

    Usage:
        tracker = CostTracker()
        tracker.record("claude", "claude-3-5-sonnet", input_tokens=500, output_tokens=200)
        print(tracker.get_session_cost())  # {'total_cost_usd': 0.0045, ...}
    """

    def __init__(
        self,
        custom_rates: Optional[dict[str, tuple[float, float]]] = None,
        fallback_rate: Optional[tuple[float, float]] = None,
    ) -> None:
        """Initialize the cost tracker.

        Args:
            custom_rates: Optional dict mapping model names to
                (input_rate_per_M, output_rate_per_M) tuples.
            fallback_rate: Rate to use for unknown models.
                Defaults to ($1.00/M input, $3.00/M output).
        """
        self._lock = threading.Lock()
        self._records: list[UsageRecord] = []
        self._rates = dict(DEFAULT_COST_RATES)
        if custom_rates:
            self._rates.update(custom_rates)
        self._fallback_rate = fallback_rate or _DEFAULT_FALLBACK_RATE

    def _get_rates(self, model: str) -> tuple[float, float]:
        """Look up cost rates for a model, with prefix matching fallback."""
        if model in self._rates:
            return self._rates[model]

        # Try prefix matching (e.g. "claude-3-5-sonnet-20241022" matches "claude-3-5-sonnet")
        for known_model in sorted(self._rates.keys(), key=len, reverse=True):
            if model.startswith(known_model):
                return self._rates[known_model]

        return self._fallback_rate

    def record(
        self,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
    ) -> UsageRecord:
        """Record a single API call's token usage.

        Args:
            provider: Provider name (e.g. "claude", "openai").
            model: Model identifier (e.g. "gpt-4o").
            input_tokens: Number of input/prompt tokens.
            output_tokens: Number of output/completion tokens.

        Returns:
            The created UsageRecord with computed costs.
        """
        input_rate, output_rate = self._get_rates(model)
        input_cost = (input_tokens / 1_000_000) * input_rate
        output_cost = (output_tokens / 1_000_000) * output_rate

        usage = UsageRecord(
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            input_cost_usd=input_cost,
            output_cost_usd=output_cost,
        )

        with self._lock:
            self._records.append(usage)

        return usage

    def get_session_cost(self) -> dict:
        """Get aggregate cost summary for the current session.

        Returns:
            Dict with total_input_tokens, total_output_tokens,
            total_cost_usd, and record_count.
        """
        with self._lock:
            records = list(self._records)

        total_input = sum(r.input_tokens for r in records)
        total_output = sum(r.output_tokens for r in records)
        total_cost = sum(r.total_cost_usd for r in records)

        return {
            "total_input_tokens": total_input,
            "total_output_tokens": total_output,
            "total_cost_usd": round(total_cost, 8),
            "record_count": len(records),
        }

    def get_cost_by_provider(self) -> dict[str, dict]:
        """Get cost breakdown grouped by provider.

        Returns:
            Dict mapping provider names to their aggregate stats
            (input_tokens, output_tokens, cost_usd, call_count).
        """
        with self._lock:
            records = list(self._records)

        by_provider: dict[str, dict] = {}
        for r in records:
            if r.provider not in by_provider:
                by_provider[r.provider] = {
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cost_usd": 0.0,
                    "call_count": 0,
                }
            entry = by_provider[r.provider]
            entry["input_tokens"] += r.input_tokens
            entry["output_tokens"] += r.output_tokens
            entry["cost_usd"] += r.total_cost_usd
            entry["call_count"] += 1

        # Round costs
        for entry in by_provider.values():
            entry["cost_usd"] = round(entry["cost_usd"], 8)

        return by_provider

    def get_cost_by_model(self) -> dict[str, dict]:
        """Get cost breakdown grouped by model.

        Returns:
            Dict mapping model names to their aggregate stats.
        """
        with self._lock:
            records = list(self._records)

        by_model: dict[str, dict] = {}
        for r in records:
            if r.model not in by_model:
                by_model[r.model] = {
                    "provider": r.provider,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cost_usd": 0.0,
                    "call_count": 0,
                }
            entry = by_model[r.model]
            entry["input_tokens"] += r.input_tokens
            entry["output_tokens"] += r.output_tokens
            entry["cost_usd"] += r.total_cost_usd
            entry["call_count"] += 1

        for entry in by_model.values():
            entry["cost_usd"] = round(entry["cost_usd"], 8)

        return by_model

    def reset(self) -> None:
        """Clear all recorded usage data."""
        with self._lock:
            self._records.clear()
