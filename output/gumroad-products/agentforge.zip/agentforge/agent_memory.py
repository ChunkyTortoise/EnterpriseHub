"""Agent memory and conversation context management.

Provides in-memory stores with TTL expiration, relevance-based retrieval,
LRU eviction, and multi-turn conversation context tracking.
"""

from __future__ import annotations

import logging
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("agentforge.agent_memory")


@dataclass
class AgentMemoryEntry:
    """A single entry in the agent memory store."""

    key: str
    value: Any
    timestamp: float = field(default_factory=time.time)
    ttl_seconds: float = 0.0
    relevance_score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_expired(self) -> bool:
        """Check if entry has exceeded its TTL (0 means no expiration)."""
        if self.ttl_seconds <= 0:
            return False
        return (time.time() - self.timestamp) > self.ttl_seconds


class AgentMemoryStore:
    """In-memory store with TTL expiration, relevance retrieval, and LRU eviction.

    Thread-safe key-value store that supports:
    - TTL-based automatic expiration
    - Relevance-scored search with keyword matching
    - Max capacity with LRU eviction policy

    Args:
        max_capacity: Maximum number of entries (0 = unlimited).
    """

    def __init__(self, max_capacity: int = 0) -> None:
        self._lock = threading.Lock()
        self._entries: dict[str, AgentMemoryEntry] = {}
        self._access_order: list[str] = []
        self._max_capacity = max_capacity

    def _touch(self, key: str) -> None:
        """Move key to end of access order (most recently used)."""
        if key in self._access_order:
            self._access_order.remove(key)
        self._access_order.append(key)

    def _evict_lru(self) -> None:
        """Evict the least recently used entry if over capacity."""
        if self._max_capacity <= 0:
            return
        while len(self._entries) > self._max_capacity and self._access_order:
            lru_key = self._access_order.pop(0)
            if lru_key in self._entries:
                del self._entries[lru_key]
                logger.debug("evicted LRU key=%s", lru_key)

    def store(
        self,
        key: str,
        value: Any,
        ttl_seconds: float = 0.0,
        relevance_score: float = 0.0,
        metadata: dict[str, Any] | None = None,
    ) -> AgentMemoryEntry:
        """Store a value with optional TTL and relevance score.

        Args:
            key: Unique key for the entry.
            value: Value to store.
            ttl_seconds: Time-to-live in seconds (0 = no expiration).
            relevance_score: Score for relevance-based retrieval.
            metadata: Optional metadata dict.

        Returns:
            The created AgentMemoryEntry.
        """
        entry = AgentMemoryEntry(
            key=key,
            value=value,
            ttl_seconds=ttl_seconds,
            relevance_score=relevance_score,
            metadata=metadata or {},
        )
        with self._lock:
            self._entries[key] = entry
            self._touch(key)
            self._evict_lru()
        logger.debug("stored key=%s ttl=%s", key, ttl_seconds)
        return entry

    def retrieve(self, key: str) -> AgentMemoryEntry | None:
        """Retrieve an entry by key, returning None if missing or expired.

        Args:
            key: The key to look up.

        Returns:
            AgentMemoryEntry if found and not expired, else None.
        """
        with self._lock:
            entry = self._entries.get(key)
            if entry is None:
                return None
            if entry.is_expired:
                del self._entries[key]
                if key in self._access_order:
                    self._access_order.remove(key)
                logger.debug("expired key=%s", key)
                return None
            self._touch(key)
            return entry

    def search(self, query: str, top_k: int = 5) -> list[AgentMemoryEntry]:
        """Search entries by keyword match, sorted by relevance score.

        Matches entries whose key or string value contains any query word.
        Expired entries are excluded.

        Args:
            query: Search query string.
            top_k: Maximum number of results to return.

        Returns:
            List of matching AgentMemoryEntry objects, highest relevance first.
        """
        query_words = query.lower().split()
        if not query_words:
            return []

        results: list[AgentMemoryEntry] = []
        with self._lock:
            expired_keys: list[str] = []
            for key, entry in self._entries.items():
                if entry.is_expired:
                    expired_keys.append(key)
                    continue
                searchable = f"{entry.key} {entry.value}".lower()
                if any(word in searchable for word in query_words):
                    results.append(entry)
            for key in expired_keys:
                del self._entries[key]
                if key in self._access_order:
                    self._access_order.remove(key)

        results.sort(key=lambda e: e.relevance_score, reverse=True)
        return results[:top_k]

    def evict_expired(self) -> int:
        """Remove all expired entries.

        Returns:
            Number of entries evicted.
        """
        count = 0
        with self._lock:
            expired_keys = [k for k, v in self._entries.items() if v.is_expired]
            for key in expired_keys:
                del self._entries[key]
                if key in self._access_order:
                    self._access_order.remove(key)
                count += 1
        if count:
            logger.debug("evicted %d expired entries", count)
        return count

    def clear(self) -> None:
        """Remove all entries."""
        with self._lock:
            self._entries.clear()
            self._access_order.clear()

    @property
    def size(self) -> int:
        """Current number of entries."""
        with self._lock:
            return len(self._entries)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the store to a dictionary.

        Returns:
            Dict with entries list and metadata.
        """
        with self._lock:
            entries = []
            for entry in self._entries.values():
                entries.append(
                    {
                        "key": entry.key,
                        "value": entry.value,
                        "timestamp": entry.timestamp,
                        "ttl_seconds": entry.ttl_seconds,
                        "relevance_score": entry.relevance_score,
                        "metadata": entry.metadata,
                    }
                )
            return {
                "entries": entries,
                "max_capacity": self._max_capacity,
                "size": len(self._entries),
            }


@dataclass
class ConversationTurn:
    """A single turn in a conversation."""

    role: str
    content: str
    timestamp: float = field(default_factory=time.time)


class ConversationContext:
    """Multi-turn conversation context manager.

    Tracks conversation history, extracts entities, and identifies
    active topics from recent turns.

    Args:
        max_turns: Maximum turns to retain (0 = unlimited).
        summary_window: Number of recent turns for summary generation.
    """

    def __init__(self, max_turns: int = 0, summary_window: int = 3) -> None:
        self._lock = threading.Lock()
        self._turns: list[ConversationTurn] = []
        self._max_turns = max_turns
        self._summary_window = summary_window

    def add_turn(self, role: str, content: str) -> ConversationTurn:
        """Add a conversation turn.

        Args:
            role: Speaker role (e.g. "user", "assistant").
            content: Turn content text.

        Returns:
            The created ConversationTurn.
        """
        turn = ConversationTurn(role=role, content=content)
        with self._lock:
            self._turns.append(turn)
            if self._max_turns > 0 and len(self._turns) > self._max_turns:
                self._turns = self._turns[-self._max_turns :]
        return turn

    def get_history(self, last_n: int = 0) -> list[ConversationTurn]:
        """Get conversation history.

        Args:
            last_n: Number of recent turns (0 = all).

        Returns:
            List of ConversationTurn objects.
        """
        with self._lock:
            if last_n <= 0:
                return list(self._turns)
            return list(self._turns[-last_n:])

    def get_summary(self) -> str:
        """Get a concatenated summary of recent turns.

        Returns:
            Summary string from the last N turns (per summary_window).
        """
        with self._lock:
            recent = self._turns[-self._summary_window :]
        if not recent:
            return ""
        parts = [f"{t.role}: {t.content}" for t in recent]
        return "\n".join(parts)

    @staticmethod
    def extract_entities(text: str) -> list[str]:
        """Extract simple entities from text via regex.

        Detects capitalized multi-word names, email addresses, and numbers.

        Args:
            text: Input text to extract from.

        Returns:
            Deduplicated list of extracted entity strings.
        """
        entities: list[str] = []

        # Email addresses
        emails = re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
        entities.extend(emails)

        # Numbers (integers and decimals, including $ prefixed)
        numbers = re.findall(r"\$?[\d,]+\.?\d*", text)
        entities.extend(n for n in numbers if any(c.isdigit() for c in n))

        # Capitalized words/names (2+ chars, not at sentence start heuristic)
        cap_words = re.findall(
            r"(?<!\. )(?<!\.\n)\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b", text
        )
        # Filter common English words
        stop_words = {
            "The",
            "This",
            "That",
            "These",
            "Those",
            "What",
            "When",
            "Where",
            "Which",
            "Who",
            "How",
            "But",
            "And",
            "For",
            "Not",
            "You",
            "All",
            "Can",
            "Her",
            "Was",
            "One",
            "Our",
            "Out",
            "Are",
            "Has",
            "Have",
            "Its",
            "May",
            "Some",
            "Into",
            "Also",
            "Just",
            "Only",
            "Each",
        }
        for word in cap_words:
            if word not in stop_words and len(word) >= 2:
                entities.append(word)

        # Deduplicate preserving order
        seen: set[str] = set()
        unique: list[str] = []
        for entity in entities:
            if entity not in seen:
                seen.add(entity)
                unique.append(entity)
        return unique

    @property
    def active_topic(self) -> str:
        """Identify the active topic from the most recent turns.

        Returns the content of the most recent user turn, or empty string
        if no turns exist.
        """
        with self._lock:
            for turn in reversed(self._turns):
                if turn.role == "user":
                    return turn.content
            # Fallback to most recent turn of any role
            if self._turns:
                return self._turns[-1].content
        return ""

    @property
    def turn_count(self) -> int:
        """Current number of turns."""
        with self._lock:
            return len(self._turns)
