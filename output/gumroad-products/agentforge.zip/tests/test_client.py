"""Unit tests for AgentForge client.

All API calls are mocked - no real network requests are made.
Run with: pytest test_client.py -v
"""

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from agentforge import (
    AgentForgeError,
    AIOrchestrator,
    AIResponse,
    AuthenticationError,
    ProviderError,
    RateLimitError,
)

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def orchestrator():
    """Create an orchestrator with fast retry for testing."""
    return AIOrchestrator(temperature=0.5, max_tokens=1024, max_retries=3, timeout=5.0)


# ── AIResponse Dataclass ─────────────────────────────────────────────────────


def test_airesponse_fields():
    """AIResponse stores content, provider, and model."""
    resp = AIResponse(content="Hello", provider="gemini", model="gemini-1.5-pro")
    assert resp.content == "Hello"
    assert resp.provider == "gemini"
    assert resp.model == "gemini-1.5-pro"


def test_airesponse_defaults():
    """AIResponse has sensible defaults for optional fields."""
    resp = AIResponse(content="test", provider="claude", model="claude-3")
    assert resp.elapsed_ms == 0.0
    assert resp.metadata == {}


def test_airesponse_metadata():
    """AIResponse accepts custom metadata."""
    resp = AIResponse(content="x", provider="p", model="m", metadata={"tokens": 42})
    assert resp.metadata["tokens"] == 42


# ── Provider Routing ──────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_routes_to_gemini(orchestrator):
    """chat('gemini', ...) calls the Gemini provider method."""
    mock_response = AIResponse(
        content="from gemini", provider="gemini", model="gemini-1.5-pro"
    )
    with patch.object(
        orchestrator._providers["gemini"],
        "chat",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        result = await orchestrator.chat("gemini", "test prompt")
        orchestrator._providers["gemini"].chat.assert_awaited_once()
        assert result.provider == "gemini"


@pytest.mark.asyncio
async def test_routes_to_perplexity(orchestrator):
    """chat('perplexity', ...) calls the Perplexity provider method."""
    mock_response = AIResponse(
        content="from perplexity", provider="perplexity", model="sonar-reasoning-pro"
    )
    with patch.object(
        orchestrator._providers["perplexity"],
        "chat",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        result = await orchestrator.chat("perplexity", "test prompt")
        orchestrator._providers["perplexity"].chat.assert_awaited_once()
        assert result.provider == "perplexity"


@pytest.mark.asyncio
async def test_routes_to_claude(orchestrator):
    """chat('claude', ...) calls the Claude provider method."""
    mock_response = AIResponse(
        content="from claude", provider="claude", model="claude-3-5-sonnet-20241022"
    )
    with patch.object(
        orchestrator._providers["claude"],
        "chat",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        result = await orchestrator.chat("claude", "test prompt")
        orchestrator._providers["claude"].chat.assert_awaited_once()
        assert result.provider == "claude"


@pytest.mark.asyncio
async def test_routes_to_openai(orchestrator):
    """chat('openai', ...) calls the OpenAI provider method."""
    mock_response = AIResponse(content="from openai", provider="openai", model="gpt-4o")
    with patch.object(
        orchestrator._providers["openai"],
        "chat",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        result = await orchestrator.chat("openai", "test prompt")
        orchestrator._providers["openai"].chat.assert_awaited_once()
        assert result.provider == "openai"


@pytest.mark.asyncio
async def test_unknown_provider_raises_valueerror(orchestrator):
    """chat() with an unsupported provider raises ValueError."""
    with pytest.raises(ValueError, match="Unknown provider: unknown"):
        await orchestrator.chat("unknown", "test")


# ── Custom Model Override ─────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_custom_model_override(orchestrator):
    """Passing a model name overrides the default for that provider."""
    mock_response = AIResponse(
        content="ok", provider="gemini", model="gemini-2.0-flash"
    )
    with patch.object(
        orchestrator._providers["gemini"],
        "chat",
        new_callable=AsyncMock,
        return_value=mock_response,
    ) as mock:
        await orchestrator.chat("gemini", "test", model="gemini-2.0-flash")
        call_args = mock.call_args
        assert call_args[0][2] == "gemini-2.0-flash"


# ── Configuration ─────────────────────────────────────────────────────────────


def test_default_configuration():
    """AIOrchestrator uses sensible defaults."""
    orc = AIOrchestrator()
    assert orc.temperature == 0.2
    assert orc.max_tokens == 4096
    assert orc.max_retries == 3
    assert orc.timeout == 60.0
    assert orc.fallback_chain == []


def test_custom_configuration():
    """AIOrchestrator accepts custom temperature and max_tokens."""
    orc = AIOrchestrator(
        temperature=0.9,
        max_tokens=2048,
        max_retries=5,
        timeout=30.0,
        fallback_chain=["openai"],
    )
    assert orc.temperature == 0.9
    assert orc.max_tokens == 2048
    assert orc.max_retries == 5
    assert orc.timeout == 30.0
    assert orc.fallback_chain == ["openai"]


# ── Error Handling ────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_authentication_error_on_401(orchestrator):
    """HTTP 401 raises AuthenticationError immediately (no retry)."""
    mock_response = MagicMock()
    mock_response.status_code = 401

    with patch(
        "httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_response
    ):
        with pytest.raises(AuthenticationError) as exc_info:
            await orchestrator._request_json("gemini", "https://example.com", {})
        assert exc_info.value.status_code == 401
        assert exc_info.value.provider == "gemini"


@pytest.mark.asyncio
async def test_rate_limit_error_on_429(orchestrator):
    """HTTP 429 raises RateLimitError immediately (no retry)."""
    mock_response = MagicMock()
    mock_response.status_code = 429

    with patch(
        "httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_response
    ):
        with pytest.raises(RateLimitError) as exc_info:
            await orchestrator._request_json("claude", "https://example.com", {})
        assert exc_info.value.status_code == 429


# ── Retry Logic ───────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_retry_on_timeout(orchestrator):
    """Transient timeout triggers retry, succeeds on second attempt."""
    success_response = MagicMock()
    success_response.status_code = 200
    success_response.json.return_value = {"result": "ok"}
    success_response.raise_for_status = MagicMock()

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.side_effect = [
            httpx.TimeoutException("timed out"),
            success_response,
        ]
        with patch("asyncio.sleep", new_callable=AsyncMock):
            result, elapsed_ms, status_code = await orchestrator._request_json(
                "gemini", "https://example.com", {}
            )

    assert result == {"result": "ok"}
    assert status_code == 200
    assert elapsed_ms >= 0
    assert mock_post.await_count == 2


@pytest.mark.asyncio
async def test_exhausted_retries_raises_provider_error(orchestrator):
    """All retries exhausted raises ProviderError."""
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.side_effect = httpx.ConnectError("connection refused")
        with patch("asyncio.sleep", new_callable=AsyncMock):
            with pytest.raises(ProviderError, match="Request failed after 3 attempts"):
                await orchestrator._request_json(
                    "perplexity", "https://example.com", {}
                )

    assert mock_post.await_count == 3


# ── Fallback Routing ─────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_fallback_on_provider_error():
    """ProviderError triggers fallback routing."""
    orc = AIOrchestrator(fallback_chain=["openai"])
    with patch.object(
        orc._providers["claude"],
        "chat",
        new_callable=AsyncMock,
        side_effect=ProviderError("claude", "fail"),
    ):
        with patch.object(
            orc._providers["openai"],
            "chat",
            new_callable=AsyncMock,
            return_value=AIResponse("ok", "openai", "gpt-4o"),
        ):
            result = await orc.chat("claude", "test")
            assert result.provider == "openai"


# ── Streaming ────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "provider,env_key,lines,expected",
    [
        (
            "openai",
            "OPENAI_API_KEY",
            ['data: {"choices":[{"delta":{"content":"Hi"}}]}', "data: [DONE]"],
            "Hi",
        ),
        (
            "perplexity",
            "PERPLEXITY_API_KEY",
            ['data: {"choices":[{"delta":{"content":"Hello"}}]}', "data: [DONE]"],
            "Hello",
        ),
        (
            "gemini",
            "GOOGLE_API_KEY",
            ['data: {"candidates":[{"content":{"parts":[{"text":"Yo"}]}}]}'],
            "Yo",
        ),
        (
            "claude",
            "ANTHROPIC_API_KEY",
            ["event: content_block_delta", 'data: {"delta":{"text":"Hey"}}'],
            "Hey",
        ),
    ],
)
async def test_streaming_parsers(monkeypatch, provider, env_key, lines, expected):
    """Streaming parsers extract content chunks from SSE lines."""
    monkeypatch.setenv(env_key, "test-key")
    orc = AIOrchestrator()

    async def fake_stream_lines(*_args, **_kwargs):
        for line in lines:
            yield line

    with patch.object(orc, "_stream_lines", new=fake_stream_lines):
        chunks = []
        async for chunk in orc.stream(provider, "prompt"):
            chunks.append(chunk)
        assert "".join(chunks) == expected


# ── Health Checks ────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_health_checks(monkeypatch):
    """Health returns True for configured providers and False otherwise."""
    monkeypatch.setenv("OPENAI_API_KEY", "test")
    orc = AIOrchestrator()

    with patch.object(
        orc._providers["openai"],
        "chat",
        new_callable=AsyncMock,
        return_value=AIResponse("ok", "openai", "gpt-4o"),
    ):
        results = await orc.health()
        assert results["openai"] is True
        assert results["gemini"] is False
        assert results["perplexity"] is False
        assert results["claude"] is False


# ── Exception Hierarchy ──────────────────────────────────────────────────────


def test_exception_hierarchy():
    """All custom exceptions inherit from AgentForgeError."""
    assert issubclass(ProviderError, AgentForgeError)
    assert issubclass(AuthenticationError, ProviderError)
    assert issubclass(RateLimitError, ProviderError)
