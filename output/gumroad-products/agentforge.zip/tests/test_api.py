"""Tests for agentforge.api — REST API and agent templates."""

from __future__ import annotations

import pytest
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from agentforge.api import (
    AGENT_TEMPLATES,
    TemplateInfo,
    create_api,
)


@pytest.fixture()
def app() -> FastAPI:
    """Create a test app in demo mode (no orchestrator)."""
    return create_api()


@pytest.fixture()
def transport(app: FastAPI) -> ASGITransport:
    return ASGITransport(app=app)


# --- Template tests ---


class TestTemplates:
    @pytest.mark.asyncio()
    async def test_list_templates_returns_all(self, transport: ASGITransport) -> None:
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/templates")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == len(AGENT_TEMPLATES)

    @pytest.mark.asyncio()
    async def test_get_template_found(self, transport: ASGITransport) -> None:
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/templates/code-reviewer")
        assert resp.status_code == 200
        body = resp.json()
        assert body["name"] == "Code Reviewer"
        assert body["provider"] == "anthropic"

    @pytest.mark.asyncio()
    async def test_get_template_not_found_404(self, transport: ASGITransport) -> None:
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/templates/nonexistent")
        assert resp.status_code == 404

    def test_template_info_model(self) -> None:
        info = TemplateInfo(**AGENT_TEMPLATES["summarizer"])
        assert info.name == "Summarizer"
        assert info.temperature == 0.1

    def test_agent_templates_dict_structure(self) -> None:
        required_keys = {
            "name",
            "description",
            "provider",
            "model",
            "system_prompt",
            "temperature",
        }
        for key, tmpl in AGENT_TEMPLATES.items():
            assert isinstance(key, str)
            assert required_keys.issubset(tmpl.keys()), f"{key} missing keys"


# --- Chat tests ---


class TestChat:
    @pytest.mark.asyncio()
    async def test_chat_demo_mode(self, transport: ASGITransport) -> None:
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/chat",
                json={
                    "provider": "anthropic",
                    "message": "Hello world",
                },
            )
        assert resp.status_code == 200
        body = resp.json()
        assert "Demo response for: Hello world" in body["content"]
        assert body["provider"] == "anthropic"

    @pytest.mark.asyncio()
    async def test_chat_with_template_success(self, transport: ASGITransport) -> None:
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/chat/template/summarizer",
                params={"message": "Summarize this text"},
            )
        assert resp.status_code == 200
        body = resp.json()
        assert "Demo response for: Summarize this text" in body["content"]

    @pytest.mark.asyncio()
    async def test_chat_with_template_not_found(self, transport: ASGITransport) -> None:
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/chat/template/does-not-exist",
                params={"message": "test"},
            )
        assert resp.status_code == 404

    @pytest.mark.asyncio()
    async def test_chat_response_model_fields(self, transport: ASGITransport) -> None:
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.post(
                "/chat",
                json={
                    "provider": "openai",
                    "message": "field check",
                    "model": "gpt-4o",
                },
            )
        body = resp.json()
        assert "content" in body
        assert "provider" in body
        assert "model" in body
        assert "tokens_used" in body
        assert "latency_ms" in body


# --- Factory test ---


class TestFactory:
    def test_create_api_returns_fastapi_app(self) -> None:
        app = create_api()
        assert isinstance(app, FastAPI)
        assert app.title == "AgentForge API"

    def test_create_api_with_orchestrator_arg(self) -> None:
        """create_api accepts an orchestrator arg without error."""
        app = create_api(orchestrator="fake")
        assert isinstance(app, FastAPI)
