"""Tests for multi-agent coordination: mesh, consensus, and handoff."""

from __future__ import annotations

import pytest

from agentforge.multi_agent import (
    AgentMesh,
    AgentMessage,
    AgentRegistration,
    AgentStatus,
    ConsensusResolver,
    HandoffProtocol,
    MessageType,
)


# ---------------------------------------------------------------------------
# AgentRegistration
# ---------------------------------------------------------------------------


class TestAgentRegistration:
    """Tests for agent registration dataclass."""

    def test_create_registration(self) -> None:
        reg = AgentRegistration(agent_id="a1", name="Tester", capabilities=["test"])
        assert reg.agent_id == "a1"
        assert reg.name == "Tester"
        assert reg.capabilities == ["test"]
        assert reg.status == AgentStatus.ACTIVE

    def test_default_capabilities(self) -> None:
        reg = AgentRegistration(agent_id="a1", name="Tester")
        assert reg.capabilities == []


# ---------------------------------------------------------------------------
# AgentMesh — registration
# ---------------------------------------------------------------------------


class TestAgentMeshRegistration:
    """Agent registration and unregistration tests."""

    def test_register_agent(self) -> None:
        mesh = AgentMesh()
        reg = mesh.register("a1", "Researcher", ["search", "summarize"])
        assert reg.agent_id == "a1"
        assert reg.name == "Researcher"
        assert mesh.agent_count == 1

    def test_register_duplicate_raises(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Agent 1")
        with pytest.raises(ValueError, match="already registered"):
            mesh.register("a1", "Agent 1 Duplicate")

    def test_unregister_existing(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Agent 1")
        assert mesh.unregister("a1") is True
        assert mesh.agent_count == 0

    def test_unregister_nonexistent(self) -> None:
        mesh = AgentMesh()
        assert mesh.unregister("ghost") is False

    def test_get_agent(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Agent 1")
        assert mesh.get_agent("a1") is not None
        assert mesh.get_agent("a1").name == "Agent 1"

    def test_get_agent_missing(self) -> None:
        mesh = AgentMesh()
        assert mesh.get_agent("nope") is None


# ---------------------------------------------------------------------------
# AgentMesh — messaging
# ---------------------------------------------------------------------------


class TestAgentMeshMessaging:
    """Directed and broadcast messaging tests."""

    def test_send_message(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Sender")
        mesh.register("a2", "Receiver")
        msg = AgentMessage(sender="a1", recipient="a2", content="hello")
        assert mesh.send(msg) is True

    def test_send_to_nonexistent_fails(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Sender")
        msg = AgentMessage(sender="a1", recipient="ghost", content="hello")
        assert mesh.send(msg) is False

    def test_get_inbox(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Sender")
        mesh.register("a2", "Receiver")
        mesh.send(AgentMessage(sender="a1", recipient="a2", content="msg1"))
        mesh.send(AgentMessage(sender="a1", recipient="a2", content="msg2"))
        inbox = mesh.get_inbox("a2")
        assert len(inbox) == 2
        assert inbox[0].content == "msg1"

    def test_get_inbox_clears(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Sender")
        mesh.register("a2", "Receiver")
        mesh.send(AgentMessage(sender="a1", recipient="a2", content="msg"))
        mesh.get_inbox("a2")
        assert mesh.get_inbox("a2") == []

    def test_get_inbox_nonexistent(self) -> None:
        mesh = AgentMesh()
        assert mesh.get_inbox("ghost") == []

    def test_broadcast(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Broadcaster")
        mesh.register("a2", "Listener A")
        mesh.register("a3", "Listener B")
        count = mesh.broadcast("a1", "announcement")
        assert count == 2
        assert len(mesh.get_inbox("a2")) == 1
        assert len(mesh.get_inbox("a3")) == 1
        # Sender should not receive their own broadcast
        assert len(mesh.get_inbox("a1")) == 0

    def test_broadcast_message_type(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Broadcaster")
        mesh.register("a2", "Listener")
        mesh.broadcast("a1", "test")
        inbox = mesh.get_inbox("a2")
        assert inbox[0].message_type == MessageType.BROADCAST

    def test_broadcast_no_other_agents(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Solo")
        assert mesh.broadcast("a1", "echo") == 0


# ---------------------------------------------------------------------------
# AgentMesh — capability lookup
# ---------------------------------------------------------------------------


class TestAgentMeshCapabilities:
    """Capability-based agent lookup tests."""

    def test_get_by_capability(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Researcher", ["search", "summarize"])
        mesh.register("a2", "Writer", ["compose", "summarize"])
        mesh.register("a3", "Coder", ["code"])
        results = mesh.get_by_capability("summarize")
        assert len(results) == 2
        ids = {r.agent_id for r in results}
        assert ids == {"a1", "a2"}

    def test_get_by_capability_no_match(self) -> None:
        mesh = AgentMesh()
        mesh.register("a1", "Agent", ["search"])
        assert mesh.get_by_capability("fly") == []


# ---------------------------------------------------------------------------
# ConsensusResolver
# ---------------------------------------------------------------------------


class TestConsensusResolver:
    """Consensus voting and resolution tests."""

    def test_majority_vote(self) -> None:
        resolver = ConsensusResolver()
        resolver.collect_vote("a1", "yes")
        resolver.collect_vote("a2", "yes")
        resolver.collect_vote("a3", "no")
        result = resolver.resolve(method="majority")
        assert result.winner == "yes"
        assert result.vote_count == 3
        assert result.dissenting_count == 1

    def test_majority_confidence(self) -> None:
        resolver = ConsensusResolver()
        resolver.collect_vote("a1", "A")
        resolver.collect_vote("a2", "A")
        resolver.collect_vote("a3", "B")
        result = resolver.resolve(method="majority")
        assert abs(result.confidence - 2 / 3) < 0.01

    def test_weighted_vote(self) -> None:
        resolver = ConsensusResolver()
        resolver.collect_vote("a1", "A", confidence=0.9)
        resolver.collect_vote("a2", "B", confidence=0.3)
        resolver.collect_vote("a3", "B", confidence=0.2)
        result = resolver.resolve(method="weighted")
        # A has weight 0.9, B has 0.5 -> A wins
        assert result.winner == "A"

    def test_weighted_confidence_ratio(self) -> None:
        resolver = ConsensusResolver()
        resolver.collect_vote("a1", "X", confidence=0.8)
        resolver.collect_vote("a2", "Y", confidence=0.2)
        result = resolver.resolve(method="weighted")
        assert abs(result.confidence - 0.8) < 0.01

    def test_resolve_no_votes_raises(self) -> None:
        resolver = ConsensusResolver()
        with pytest.raises(ValueError, match="No votes"):
            resolver.resolve()

    def test_reset(self) -> None:
        resolver = ConsensusResolver()
        resolver.collect_vote("a1", "A")
        resolver.reset()
        assert resolver.vote_count == 0

    def test_vote_count_property(self) -> None:
        resolver = ConsensusResolver()
        resolver.collect_vote("a1", "A")
        resolver.collect_vote("a2", "B")
        assert resolver.vote_count == 2

    def test_confidence_clamped(self) -> None:
        resolver = ConsensusResolver()
        resolver.collect_vote("a1", "A", confidence=1.5)
        resolver.collect_vote("a2", "A", confidence=-0.5)
        result = resolver.resolve(method="weighted")
        # 1.5 clamped to 1.0, -0.5 clamped to 0.0 -> weight = 1.0
        assert result.winner == "A"
        assert result.confidence == 1.0

    def test_single_vote(self) -> None:
        resolver = ConsensusResolver()
        resolver.collect_vote("a1", "only")
        result = resolver.resolve()
        assert result.winner == "only"
        assert result.dissenting_count == 0
        assert result.confidence == 1.0


# ---------------------------------------------------------------------------
# HandoffProtocol
# ---------------------------------------------------------------------------


class TestHandoffProtocol:
    """Agent handoff evaluation tests."""

    def test_approve_above_threshold(self) -> None:
        protocol = HandoffProtocol(confidence_threshold=0.7)
        decision = protocol.evaluate_handoff("a1", "a2", "context", 0.85)
        assert decision.approved is True
        assert "Approved" in decision.reason

    def test_reject_below_threshold(self) -> None:
        protocol = HandoffProtocol(confidence_threshold=0.7)
        decision = protocol.evaluate_handoff("a1", "a2", "context", 0.5)
        assert decision.approved is False
        assert "Rejected" in decision.reason

    def test_approve_at_threshold(self) -> None:
        protocol = HandoffProtocol(confidence_threshold=0.7)
        decision = protocol.evaluate_handoff("a1", "a2", "context", 0.7)
        assert decision.approved is True

    def test_reject_self_handoff(self) -> None:
        protocol = HandoffProtocol()
        decision = protocol.evaluate_handoff("a1", "a1", "context", 1.0)
        assert decision.approved is False
        assert "same agent" in decision.reason.lower()

    def test_default_threshold(self) -> None:
        protocol = HandoffProtocol()
        assert protocol.confidence_threshold == 0.7

    def test_custom_threshold(self) -> None:
        protocol = HandoffProtocol(confidence_threshold=0.5)
        assert protocol.confidence_threshold == 0.5

    def test_set_threshold(self) -> None:
        protocol = HandoffProtocol()
        protocol.confidence_threshold = 0.9
        assert protocol.confidence_threshold == 0.9

    def test_threshold_clamped(self) -> None:
        protocol = HandoffProtocol()
        protocol.confidence_threshold = 1.5
        assert protocol.confidence_threshold == 1.0
        protocol.confidence_threshold = -0.5
        assert protocol.confidence_threshold == 0.0

    def test_confidence_threshold_in_decision(self) -> None:
        protocol = HandoffProtocol(confidence_threshold=0.8)
        decision = protocol.evaluate_handoff("a1", "a2", "ctx", 0.9)
        assert decision.confidence_threshold == 0.8

    def test_confidence_clamped_in_evaluation(self) -> None:
        protocol = HandoffProtocol(confidence_threshold=0.7)
        decision = protocol.evaluate_handoff("a1", "a2", "ctx", 1.5)
        assert decision.approved is True
        # Confidence was clamped to 1.0
        assert "1.00" in decision.reason
