"""AgentForge Flow Visualizer -- Streamlit demo for AI orchestration."""

from __future__ import annotations

import streamlit as st

from agentforge.tracing import EventCollector, TraceEvent, TraceSpan

st.set_page_config(
    page_title="AgentForge Flow Visualizer",
    page_icon="\U0001f504",
    layout="wide",
)


def generate_mock_trace() -> TraceSpan:
    """Generate a mock trace for demo purposes."""
    span = TraceSpan(trace_id="demo-trace-001")
    span.events = [
        TraceEvent(
            event_type="request",
            provider="anthropic",
            model="claude-sonnet-4-5-20250929",
            elapsed_ms=0,
            metadata={"prompt_tokens": 150},
        ),
        TraceEvent(
            event_type="tool_call",
            provider="anthropic",
            model="claude-sonnet-4-5-20250929",
            elapsed_ms=120,
            metadata={"tool": "search", "status": "success"},
        ),
        TraceEvent(
            event_type="response",
            provider="anthropic",
            model="claude-sonnet-4-5-20250929",
            elapsed_ms=350,
            metadata={"completion_tokens": 200},
        ),
        TraceEvent(
            event_type="request",
            provider="openai",
            model="gpt-4o",
            elapsed_ms=0,
            metadata={"prompt_tokens": 100},
        ),
        TraceEvent(
            event_type="response",
            provider="openai",
            model="gpt-4o",
            elapsed_ms=280,
            metadata={"completion_tokens": 150},
        ),
    ]
    return span


def render_flow_diagram(span: TraceSpan) -> str:
    """Render a Mermaid flow diagram from trace events."""
    lines = ["graph LR"]
    for i, event in enumerate(span.events):
        node_id = f"E{i}"
        label = f"{event.event_type}\\n{event.provider}\\n{event.model}"
        lines.append(f'    {node_id}["{label}"]')
        if i > 0:
            lines.append(f"    E{i - 1} --> {node_id}")
    return "\n".join(lines)


def render_metrics(span: TraceSpan) -> None:
    """Render latency and event metrics."""
    cols = st.columns(3)
    cols[0].metric("Total Latency", f"{span.total_ms:.0f} ms")
    cols[1].metric("Events", str(span.event_count))
    providers = {e.provider for e in span.events if e.provider}
    cols[2].metric("Providers", str(len(providers)))


def main() -> None:
    """Application entry point."""
    st.title("AgentForge Flow Visualizer")
    st.markdown(
        "Visualize AI orchestration traces, provider chains, and latency metrics."
    )

    # Sidebar
    st.sidebar.header("Configuration")
    data_source = st.sidebar.radio("Data Source", ["Mock Data", "Live Collector"])

    if data_source == "Mock Data":
        span = generate_mock_trace()
    else:
        if "collector" not in st.session_state:
            st.session_state.collector = EventCollector()
        collector: EventCollector = st.session_state.collector
        traces = collector.get_all_traces()
        if traces:
            span = traces[-1]
        else:
            span = generate_mock_trace()
            st.info("No live traces yet. Showing mock data.")

    # Metrics
    st.subheader("Trace Metrics")
    render_metrics(span)

    # Flow diagram
    st.subheader("Execution Flow")
    mermaid_code = render_flow_diagram(span)
    st.code(mermaid_code, language="mermaid")

    # Event table
    st.subheader("Event Details")
    event_data = []
    for i, event in enumerate(span.events):
        event_data.append(
            {
                "#": i + 1,
                "Type": event.event_type,
                "Provider": event.provider,
                "Model": event.model,
                "Latency (ms)": f"{event.elapsed_ms:.1f}",
            }
        )
    st.table(event_data)


if __name__ == "__main__":
    main()
