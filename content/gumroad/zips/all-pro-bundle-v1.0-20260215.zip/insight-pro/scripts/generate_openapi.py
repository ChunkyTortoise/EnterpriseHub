#!/usr/bin/env python3
"""Generate OpenAPI specification for Insight Engine API."""

import json
import sys
from pathlib import Path

import yaml


def generate_openapi_spec(output_format: str = "json") -> None:
    """Generate and save OpenAPI specification."""
    # Create a minimal FastAPI app for schema generation
    from fastapi import FastAPI
    from pydantic import BaseModel, Field
    from typing import Any, Dict, List, Optional
    
    app = FastAPI(
        title="Insight Engine API",
        version="0.1.0",
        description=(
            "REST API for Insight Engine - Business intelligence and predictive analytics.\n\n"
            "## Authentication\n\n"
            "All endpoints require an API key via the `X-API-Key` header.\n\n"
            "## Features\n\n"
            "- CSV/Excel data upload and analysis\n"
            "- Predictive modeling with scikit-learn\n"
            "- Interactive dashboards and visualizations\n"
            "- PDF report generation\n"
        ),
    )
    
    # Define request/response models for OpenAPI generation
    class UploadRequest(BaseModel):
        file_name: str
        sheet_name: Optional[str] = None
        
    class UploadResponse(BaseModel):
        dataset_id: str
        rows: int
        columns: int
        message: str = "Upload successful"
        
    class AnalyzeRequest(BaseModel):
        dataset_id: str
        analysis_type: str = Field(..., description="Type of analysis: 'summary', 'correlation', 'forecast'")
        column: Optional[str] = None
        
    class AnalyzeResponse(BaseModel):
        results: Dict[str, Any]
        charts: List[Dict[str, Any]]
        insights: List[str]
        
    class ReportRequest(BaseModel):
        dataset_id: str
        title: str = "Analysis Report"
        include_charts: bool = True
        
    class ReportResponse(BaseModel):
        report_id: str
        pdf_url: str
        generated_at: str
    
    # Define endpoints
    @app.post("/api/upload", response_model=UploadResponse)
    async def upload_data(req: UploadRequest) -> UploadResponse:
        """Upload CSV/Excel data for analysis."""
        return UploadResponse(dataset_id="demo-id", rows=100, columns=10)
    
    @app.post("/api/analyze", response_model=AnalyzeResponse)
    async def analyze_data(req: AnalyzeRequest) -> AnalyzeResponse:
        """Run analysis on uploaded dataset."""
        return AnalyzeResponse(
            results={},
            charts=[],
            insights=["Sample insight"]
        )
    
    @app.post("/api/report", response_model=ReportResponse)
    async def generate_report(req: ReportRequest) -> ReportResponse:
        """Generate PDF report from analysis."""
        return ReportResponse(
            report_id="demo-report",
            pdf_url="/reports/demo.pdf",
            generated_at="2026-02-12T00:00:00Z"
        )
    
    @app.get("/health")
    async def health_check() -> Dict[str, str]:
        """Health check endpoint."""
        return {"status": "healthy"}
    
    # Get OpenAPI schema
    openapi_schema = app.openapi()
    
    # Add metadata
    openapi_schema["info"]["contact"] = {
        "name": "Cayman Roden",
        "email": "cayman.roden@gmail.com",
        "url": "https://chunkytortoise.github.io",
    }
    openapi_schema["info"]["license"] = {
        "name": "MIT",
        "url": "https://opensource.org/licenses/MIT",
    }
    openapi_schema["externalDocs"] = {
        "description": "Documentation",
        "url": "https://github.com/ChunkyTortoise/insight-engine/blob/main/README.md",
    }
    
    # Add servers
    openapi_schema["servers"] = [
        {"url": "http://localhost:8000", "description": "Local development"},
        {"url": "https://api.insight.example.com", "description": "Production"},
    ]
    
    # Output directory
    output_dir = Path(__file__).parent.parent / "api"
    output_dir.mkdir(exist_ok=True)
    
    if output_format == "json":
        output_file = output_dir / "openapi.json"
        with open(output_file, "w") as f:
            json.dump(openapi_schema, f, indent=2)
    else:
        output_file = output_dir / "openapi.yaml"
        with open(output_file, "w") as f:
            yaml.dump(openapi_schema, f, default_flow_style=False, sort_keys=False)
    
    print(f"OpenAPI spec generated: {output_file}")
    print(f"Endpoints: {len(openapi_schema['paths'])}")
    print(f"Schemas: {len(openapi_schema.get('components', {}).get('schemas', {}))}")


if __name__ == "__main__":
    format_arg = sys.argv[1] if len(sys.argv) > 1 else "json"
    generate_openapi_spec(format_arg)
