"""Database connectors for insight-engine.

This module provides database connectivity for loading data directly from
various database systems into insight-engine for analysis.

Supported Connectors:
- PostgreSQL (via psycopg2)
- BigQuery (via google-cloud-bigquery)

Example:
    >>> from insight_engine.connectors import ConnectorRegistry, ConnectionConfig, ConnectorType
    >>> 
    >>> # Create a PostgreSQL connection
    >>> config = ConnectionConfig(
    ...     connector_type=ConnectorType.POSTGRES,
    ...     host="localhost",
    ...     port=5432,
    ...     database="mydb",
    ...     username="user",
    ...     password="pass",
    ... )
    >>> 
    >>> # Use the connector
    >>> with ConnectorRegistry.create(config) as conn:
    ...     df = conn.query_to_dataframe("SELECT * FROM users LIMIT 100")
    ...     profile = profile_dataframe(df)
"""

from insight_engine.connectors.base import (
    ConnectionConfig,
    ConnectorRegistry,
    ConnectorType,
    DataConnector,
    QueryResult,
    TableInfo,
)
from insight_engine.connectors.bigquery import BigQueryConnector
from insight_engine.connectors.postgres import PostgresConnector

__all__ = [
    # Base classes and types
    "ConnectionConfig",
    "ConnectorRegistry",
    "ConnectorType",
    "DataConnector",
    "QueryResult",
    "TableInfo",
    # Concrete implementations
    "PostgresConnector",
    "BigQueryConnector",
]
