"""Profile endpoint: POST /profile - Dataset profiling."""

from __future__ import annotations

from typing import Any

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, status

from insight_engine.api.dependencies import common_dependencies
from insight_engine.api.models import (
    ColumnProfileResponse,
    DataQualityScoreResponse,
    ProfileRequest,
    ProfileResponse,
)
from insight_engine.profiler import (
    ColumnProfile,
    DataQualityScore,
    DataProfile,
    profile_dataframe,
)

router = APIRouter(prefix="/profile", tags=["profiling"])


def _column_profile_to_response(col: ColumnProfile) -> ColumnProfileResponse:
    """Convert internal ColumnProfile to API response model."""
    return ColumnProfileResponse(
        name=col.name,
        dtype=col.dtype,
        non_null_count=col.non_null_count,
        null_count=col.null_count,
        null_pct=col.null_pct,
        unique_count=col.unique_count,
        top_values=col.top_values,
        mean=col.mean,
        median=col.median,
        std=col.std,
        min_val=col.min_val,
        max_val=col.max_val,
        q25=col.q25,
        q75=col.q75,
        skewness=col.skewness,
        outlier_count=col.outlier_count,
    )


def _quality_score_to_response(quality: DataQualityScore | None) -> DataQualityScoreResponse | None:
    """Convert internal DataQualityScore to API response model."""
    if quality is None:
        return None
    return DataQualityScoreResponse(
        overall_score=quality.overall_score,
        completeness=quality.completeness,
        uniqueness=quality.uniqueness,
        validity=quality.validity,
    )


@router.post(
    "",
    response_model=ProfileResponse,
    summary="Profile a dataset",
    description="Analyze a dataset and return comprehensive profiling statistics including column types, distributions, outliers, and data quality scores.",
    responses={
        200: {
            "description": "Successfully profiled dataset",
            "content": {
                "application/json": {
                    "example": {
                        "row_count": 1000,
                        "column_count": 5,
                        "columns": [
                            {
                                "name": "age",
                                "dtype": "integer",
                                "non_null_count": 1000,
                                "null_count": 0,
                                "null_pct": 0.0,
                                "unique_count": 67,
                                "mean": 42.5,
                                "median": 41.0,
                                "std": 15.3,
                            }
                        ],
                        "duplicate_rows": 5,
                        "memory_usage_mb": 0.5,
                        "quality": {
                            "overall_score": 95.5,
                            "completeness": 100.0,
                            "uniqueness": 85.2,
                            "validity": 98.0,
                        },
                    }
                }
            },
        },
        400: {"description": "Invalid request data"},
        422: {"description": "Validation error"},
    },
)
async def profile(
    request: ProfileRequest,
    deps: dict = Depends(common_dependencies),
) -> ProfileResponse:
    """Profile a dataset and return comprehensive statistics.

    This endpoint analyzes the provided dataset and returns:
    - Column-level statistics (type detection, distributions, outliers)
    - Data quality scores (completeness, uniqueness, validity)
    - Overall dataset metrics (row count, memory usage, duplicates)

    The data should be provided as a list of dictionaries (records format).
    """
    try:
        # Convert list of dicts to DataFrame
        if not request.data:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Empty dataset provided",
            )

        df = pd.DataFrame(request.data)

        if df.empty:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Empty dataset provided",
            )

        # Profile the dataframe
        profile_result: DataProfile = profile_dataframe(df)

        # Convert to response model
        column_responses = [_column_profile_to_response(col) for col in profile_result.columns]

        quality_response = _quality_score_to_response(profile_result.quality)

        return ProfileResponse(
            row_count=profile_result.row_count,
            column_count=profile_result.column_count,
            columns=column_responses,
            duplicate_rows=profile_result.duplicate_rows,
            memory_usage_mb=profile_result.memory_usage_mb,
            quality=quality_response,
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error profiling dataset: {str(e)}",
        )
