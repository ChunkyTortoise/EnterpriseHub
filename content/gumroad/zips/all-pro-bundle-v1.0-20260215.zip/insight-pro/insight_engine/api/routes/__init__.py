"""API routes for insight-engine."""

from insight_engine.api.routes.profile import router as profile_router
from insight_engine.api.routes.predict import router as predict_router
from insight_engine.api.routes.forecast import router as forecast_router
from insight_engine.api.routes.attribution import router as attribution_router

__all__ = [
    "profile_router",
    "predict_router",
    "forecast_router",
    "attribution_router",
]
