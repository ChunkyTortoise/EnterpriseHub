"""HIPAA-compliant healthcare routing with PII detection and audit logging.

This example demonstrates:
- Provider routing with compliance guardrails
- Automatic PII detection and redaction
- Audit trail generation for HIPAA compliance
- Fallback to on-premise models for sensitive data

Use case: Healthcare platforms processing patient data with strict compliance requirements.
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime
from agentforge import AIOrchestrator, GuardrailsEngine
from agentforge.guardrails import GuardrailResult


# Simulated patient data (PHI - Protected Health Information)
PATIENT_QUERY = """
Patient John Smith (DOB: 03/15/1975, SSN: 123-45-6789) is experiencing 
chest pain and shortness of breath. Patient ID: P-78432. 
Medical record number: MRN-998877. Insurance: BlueCross #BC987654321.

Symptoms started 3 hours ago after strenuous exercise. 
Blood pressure: 160/95, Heart rate: 110 bpm.
"""


class HIPAACompliantRouter:
    """Router that enforces HIPAA compliance for healthcare AI."""
    
    def __init__(self):
        self.orchestrator = AIOrchestrator(temperature=0.1)
        self.guardrails = GuardrailsEngine()
        self.audit_log = []
    
    async def process_medical_query(self, query: str, patient_context: dict) -> dict:
        """
        Process healthcare query with full HIPAA compliance.
        
        Workflow:
        1. Detect and redact PII
        2. Route to appropriate provider based on sensitivity
        3. Generate audit trail
        4. Return anonymized response
        """
        
        # Step 1: PII Detection
        pii_check = self.guardrails.check_pii(query)
        
        if pii_check.violations:
            print("🔒 PII detected - initiating redaction protocol")
            redacted_query = self._redact_pii(query, pii_check)
        else:
            redacted_query = query
        
        # Step 2: Provider selection based on sensitivity
        provider = self._select_provider(pii_check, patient_context)
        
        # Step 3: Process with audit logging
        start_time = datetime.utcnow()
        
        try:
            response = await self.orchestrator.chat(
                provider,
                redacted_query,
                system="You are a medical information assistant. Provide general health information only. "
                       "Do not diagnose. Always recommend consulting a healthcare provider."
            )
            
            status = "success"
            error = None
            
        except Exception as e:
            response = None
            status = "error"
            error = str(e)
        
        end_time = datetime.utcnow()
        
        # Step 4: Generate audit entry
        audit_entry = {
            "timestamp": start_time.isoformat(),
            "duration_ms": (end_time - start_time).total_seconds() * 1000,
            "provider": provider,
            "pii_detected": bool(pii_check.violations),
            "pii_types": [v.type for v in pii_check.violations] if pii_check.violations else [],
            "status": status,
            "error": error,
            "user_id": patient_context.get("user_id"),
            "session_id": patient_context.get("session_id"),
            "access_purpose": patient_context.get("purpose", "general_query"),
            # Note: Never log actual query content in production!
        }
        
        self.audit_log.append(audit_entry)
        
        return {
            "response": response.content if response else None,
            "provider_used": provider,
            "pii_redacted": bool(pii_check.violations),
            "audit_id": len(self.audit_log),
            "compliant": True
        }
    
    def _redact_pii(self, text: str, pii_check: GuardrailResult) -> str:
        """Redact detected PII from text."""
        redacted = text
        
        # Redaction patterns
        redactions = {
            "SSN": "[REDACTED-SSN]",
            "PHONE": "[REDACTED-PHONE]",
            "EMAIL": "[REDACTED-EMAIL]",
            "NAME": "[REDACTED-NAME]",
            "DOB": "[REDACTED-DOB]",
            "MRN": "[REDACTED-MRN]",
            "INSURANCE": "[REDACTED-INSURANCE]",
        }
        
        for violation in pii_check.violations:
            pattern = redactions.get(violation.type, "[REDACTED]")
            if violation.span:
                start, end = violation.span
                redacted = redacted[:start] + pattern + redacted[end:]
        
        return redacted
    
    def _select_provider(self, pii_check: GuardrailResult, context: dict) -> str:
        """
        Select provider based on data sensitivity.
        
        Rules:
        - High sensitivity (PHI detected) -> On-premise/Ollama (local)
        - Medium sensitivity -> Enterprise agreement provider
        - Low sensitivity -> Standard cloud provider
        """
        
        high_sensitivity_types = {"SSN", "MRN", "DOB", "INSURANCE"}
        detected_types = {v.type for v in pii_check.violations}
        
        if detected_types & high_sensitivity_types:
            # Use local/self-hosted model for PHI
            print("🏥 High sensitivity detected - routing to local model")
            return "mock"  # In production: "ollama" or on-premise endpoint
        
        if context.get("requires_baa", False):  # Business Associate Agreement
            print("📋 BAA required - using HIPAA-compliant provider")
            return "claude"  # With BAA in place
        
        return "gemini"  # Default for general health info
    
    def export_audit_log(self, filename: str = "hipaa_audit.json") -> None:
        """Export audit trail for compliance review."""
        with open(filename, "w") as f:
            json.dump({
                "generated_at": datetime.utcnow().isoformat(),
                "total_entries": len(self.audit_log),
                "entries": self.audit_log
            }, f, indent=2)
        
        print(f"📄 Audit log exported to {filename}")


async def main():
    """Demo HIPAA-compliant routing."""
    
    print("🏥 HIPAA-Compliant Healthcare Routing Demo")
    print("=" * 50)
    
    router = HIPAACompliantRouter()
    
    # Patient context (simulating authenticated session)
    context = {
        "user_id": "dr_smith_001",
        "session_id": "sess_20260211_001",
        "purpose": "patient_care",
        "requires_baa": True
    }
    
    # Process query
    print("\n📝 Processing patient query...")
    result = await router.process_medical_query(PATIENT_QUERY, context)
    
    # Display results
    print(f"\n✅ Processing Complete")
    print(f"   Provider Used: {result['provider_used']}")
    print(f"   PII Redacted: {result['pii_redacted']}")
    print(f"   Audit ID: {result['audit_id']}")
    print(f"   HIPAA Compliant: {result['compliant']}")
    
    if result['response']:
        print(f"\n🩺 Response (anonymized):")
        print(f"   {result['response'][:200]}...")
    
    # Export audit trail
    print("\n📋 Exporting compliance audit trail...")
    router.export_audit_log()
    
    print("\n✨ Demo complete - all PHI handled per HIPAA requirements")


if __name__ == "__main__":
    asyncio.run(main())
