"""Workflow DAG: multi-step agent workflows with conditional routing.

Provides a directed acyclic graph of agent nodes connected by conditional
edges, with topological execution, memoization, and trace integration.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from .tracing import EventCollector, TraceEvent

logger = logging.getLogger("agentforge.workflow_dag")


@dataclass
class RetryPolicy:
    """Retry configuration for a workflow node."""

    max_retries: int = 3
    backoff_seconds: float = 1.0


@dataclass
class WorkflowNode:
    """A single node in a workflow DAG representing an agent step."""

    agent_id: str
    input_schema: dict[str, Any] = field(default_factory=dict)
    output_schema: dict[str, Any] = field(default_factory=dict)
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)


@dataclass
class WorkflowEdge:
    """A directed edge connecting two workflow nodes."""

    source: str
    target: str
    condition: Callable[[dict[str, Any]], bool] | None = None
    priority: int = 0


class WorkflowDAG:
    """Directed acyclic graph of workflow nodes and edges.

    Supports topological sorting, cycle detection, and schema
    compatibility validation between connected nodes.

    Usage:
        dag = WorkflowDAG()
        dag.add_node(WorkflowNode(agent_id="classifier"))
        dag.add_node(WorkflowNode(agent_id="summarizer"))
        dag.add_edge(WorkflowEdge(source="classifier", target="summarizer"))
        order = dag.topological_sort()
    """

    def __init__(self) -> None:
        self._nodes: dict[str, WorkflowNode] = {}
        self._edges: list[WorkflowEdge] = []

    def add_node(self, node: WorkflowNode) -> None:
        """Add a node to the DAG.

        Raises:
            ValueError: If a node with the same agent_id already exists.
        """
        if node.agent_id in self._nodes:
            raise ValueError(f"Node already exists: {node.agent_id}")
        self._nodes[node.agent_id] = node
        logger.debug("added node=%s", node.agent_id)

    def add_edge(self, edge: WorkflowEdge) -> None:
        """Add an edge to the DAG.

        Raises:
            ValueError: If source or target node does not exist.
        """
        if edge.source not in self._nodes:
            raise ValueError(f"Source node not found: {edge.source}")
        if edge.target not in self._nodes:
            raise ValueError(f"Target node not found: {edge.target}")
        self._edges.append(edge)
        logger.debug("added edge %s -> %s", edge.source, edge.target)

    def get_node(self, agent_id: str) -> WorkflowNode | None:
        """Get a node by agent_id."""
        return self._nodes.get(agent_id)

    @property
    def nodes(self) -> list[WorkflowNode]:
        """All nodes in the DAG."""
        return list(self._nodes.values())

    @property
    def edges(self) -> list[WorkflowEdge]:
        """All edges in the DAG."""
        return list(self._edges)

    def get_outgoing_edges(self, agent_id: str) -> list[WorkflowEdge]:
        """Get all edges originating from a given node, sorted by priority (desc)."""
        edges = [e for e in self._edges if e.source == agent_id]
        return sorted(edges, key=lambda e: e.priority, reverse=True)

    def topological_sort(self) -> list[str]:
        """Return nodes in topological order using Kahn's algorithm.

        Returns:
            List of agent_ids in execution order.

        Raises:
            ValueError: If the graph contains a cycle.
        """
        in_degree: dict[str, int] = {nid: 0 for nid in self._nodes}
        for edge in self._edges:
            in_degree[edge.target] += 1

        queue = sorted(
            [nid for nid, deg in in_degree.items() if deg == 0]
        )
        result: list[str] = []

        while queue:
            node_id = queue.pop(0)
            result.append(node_id)
            for edge in self._edges:
                if edge.source == node_id:
                    in_degree[edge.target] -= 1
                    if in_degree[edge.target] == 0:
                        queue.append(edge.target)
            queue.sort()

        if len(result) != len(self._nodes):
            raise ValueError("Cycle detected in workflow DAG")

        return result

    def validate(self) -> list[str]:
        """Validate the DAG structure.

        Checks for:
        - Cycles (via topological sort)
        - Schema compatibility between connected nodes

        Returns:
            List of validation error strings (empty if valid).
        """
        errors: list[str] = []

        # Cycle detection
        try:
            self.topological_sort()
        except ValueError as exc:
            errors.append(str(exc))

        # Schema compatibility: source output_schema keys should overlap
        # with target input_schema keys for connected nodes
        for edge in self._edges:
            source_node = self._nodes[edge.source]
            target_node = self._nodes[edge.target]

            source_props = set(
                source_node.output_schema.get("properties", {}).keys()
            )
            target_required = set(
                target_node.input_schema.get("required", [])
            )

            if target_required and source_props:
                missing = target_required - source_props
                if missing:
                    errors.append(
                        f"Edge {edge.source} -> {edge.target}: "
                        f"target requires {missing} not in source output"
                    )

        return errors


@dataclass
class ExecutionContext:
    """Holds state during DAG execution."""

    results: dict[str, Any] = field(default_factory=dict)
    traces: list[dict[str, Any]] = field(default_factory=list)
    errors: dict[str, str] = field(default_factory=dict)


class DAGExecutor:
    """Executes a WorkflowDAG asynchronously with memoization and tracing.

    Args:
        dag: The workflow DAG to execute.
        agent_fn: Async callable (agent_id, input_data) -> output_data.
        event_collector: Optional EventCollector for tracing integration.
    """

    def __init__(
        self,
        dag: WorkflowDAG,
        agent_fn: Callable[..., Any],
        event_collector: EventCollector | None = None,
    ) -> None:
        self._dag = dag
        self._agent_fn = agent_fn
        self._collector = event_collector

    def _emit_event(
        self, event_type: str, metadata: dict[str, Any] | None = None
    ) -> None:
        """Emit a trace event if collector is available."""
        if self._collector is not None:
            self._collector.collect(
                TraceEvent(event_type=event_type, metadata=metadata or {})
            )

    async def execute(
        self, initial_input: dict[str, Any] | None = None
    ) -> ExecutionContext:
        """Execute the DAG in topological order.

        Each node receives the merged outputs of its predecessors.
        Memoized results are reused if a node has already been executed.

        Args:
            initial_input: Input data for root nodes (no predecessors).

        Returns:
            ExecutionContext with results, traces, and errors.
        """
        ctx = ExecutionContext()
        initial_input = initial_input or {}

        try:
            order = self._dag.topological_sort()
        except ValueError as exc:
            ctx.errors["_dag"] = str(exc)
            return ctx

        self._emit_event("dag_start", {"order": order})

        for agent_id in order:
            # Skip if already memoized
            if agent_id in ctx.results:
                continue

            node = self._dag.get_node(agent_id)
            if node is None:
                continue

            # Gather input from predecessors
            node_input = dict(initial_input)
            incoming_edges = [e for e in self._dag.edges if e.target == agent_id]

            for edge in incoming_edges:
                if edge.source in ctx.results:
                    source_result = ctx.results[edge.source]
                    if isinstance(source_result, dict):
                        node_input.update(source_result)
                    else:
                        node_input[edge.source] = source_result

            # Evaluate conditional edges from predecessors
            skip = False
            for edge in incoming_edges:
                if edge.condition is not None:
                    if edge.source in ctx.results:
                        result_data = ctx.results[edge.source]
                        if isinstance(result_data, dict):
                            if not edge.condition(result_data):
                                skip = True
                                break

            if skip:
                self._emit_event(
                    "dag_node_skipped",
                    {"agent_id": agent_id, "reason": "condition_not_met"},
                )
                continue

            # Execute with retry
            start_ms = time.monotonic()
            last_error: str | None = None
            result: Any = None

            for attempt in range(node.retry_policy.max_retries + 1):
                try:
                    if inspect.iscoroutinefunction(self._agent_fn):
                        result = await self._agent_fn(agent_id, node_input)
                    else:
                        result = self._agent_fn(agent_id, node_input)
                    last_error = None
                    break
                except Exception as exc:
                    last_error = str(exc)
                    if attempt < node.retry_policy.max_retries:
                        await asyncio.sleep(node.retry_policy.backoff_seconds)

            elapsed_ms = (time.monotonic() - start_ms) * 1000

            trace_entry = {
                "agent_id": agent_id,
                "elapsed_ms": elapsed_ms,
                "success": last_error is None,
            }
            ctx.traces.append(trace_entry)

            if last_error is not None:
                ctx.errors[agent_id] = last_error
                self._emit_event(
                    "dag_node_error",
                    {"agent_id": agent_id, "error": last_error},
                )
                # Check for fallback edges
                outgoing = self._dag.get_outgoing_edges(agent_id)
                for edge in outgoing:
                    if edge.condition is not None:
                        try:
                            if edge.condition({"error": last_error}):
                                # Route to fallback
                                self._emit_event(
                                    "dag_fallback",
                                    {
                                        "from": agent_id,
                                        "to": edge.target,
                                    },
                                )
                        except Exception:
                            pass
            else:
                ctx.results[agent_id] = result
                self._emit_event(
                    "dag_node_complete",
                    {"agent_id": agent_id, "elapsed_ms": elapsed_ms},
                )

        self._emit_event(
            "dag_end",
            {
                "completed": len(ctx.results),
                "errors": len(ctx.errors),
            },
        )
        return ctx
