"""AgentForge - Lightweight Async Multi-Provider LLM Orchestrator."""

from __future__ import annotations

import asyncio
import logging
import os
from time import time
from typing import AsyncGenerator, Optional

import httpx

from .client_types import AIResponse
from .exceptions import (
    AgentForgeError,
    AuthenticationError,
    ProviderError,
    RateLimitError,
)
from .providers import (
    ClaudeProvider,
    GeminiProvider,
    MockProvider,
    OpenAIProvider,
    PerplexityProvider,
)

logger = logging.getLogger("agentforge")


class AIOrchestrator:
    """Async multi-provider LLM orchestrator."""

    DEFAULT_MODELS = {
        "gemini": GeminiProvider.default_model,
        "perplexity": PerplexityProvider.default_model,
        "claude": ClaudeProvider.default_model,
        "openai": OpenAIProvider.default_model,
        "mock": MockProvider.default_model,
    }

    def __init__(
        self,
        temperature: float = 0.2,
        max_tokens: int = 4096,
        max_retries: int = 3,
        timeout: float = 60.0,
        fallback_chain: Optional[list[str]] = None,
        verbose: bool = False,
    ) -> None:
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.max_retries = max_retries
        self.timeout = timeout
        self.fallback_chain = fallback_chain or []

        self._configure_logging(verbose)

        self._providers = {
            "gemini": GeminiProvider(self),
            "perplexity": PerplexityProvider(self),
            "claude": ClaudeProvider(self),
            "openai": OpenAIProvider(self),
            "mock": MockProvider(self),
        }

    def _configure_logging(self, verbose: bool) -> None:
        level = None
        env_level = os.getenv("LOG_LEVEL")
        if env_level:
            candidate = getattr(logging, env_level.upper(), None)
            if isinstance(candidate, int):
                level = candidate
        if verbose:
            level = logging.DEBUG
        if level is not None:
            logging.basicConfig(level=level)
            logger.setLevel(level)

    async def chat(
        self,
        provider: str,
        prompt: str,
        system: str = "You are a helpful assistant.",
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
    ) -> AIResponse:
        """Route a prompt to the specified LLM provider."""
        response = None
        try:
            response = await self._call_provider(
                provider, prompt, system, model, max_tokens, temperature
            )
            return response
        except (AuthenticationError, RateLimitError):
            raise
        except ProviderError as exc:
            if not self.fallback_chain:
                raise
            last_error: ProviderError = exc
            for fallback_provider in self._fallback_providers(provider):
                try:
                    response = await self._call_provider(
                        fallback_provider,
                        prompt,
                        system,
                        model,
                        max_tokens,
                        temperature,
                    )
                    return response
                except ProviderError as fallback_exc:
                    last_error = fallback_exc
                    continue
            raise last_error

    async def stream(
        self,
        provider: str,
        prompt: str,
        system: str = "You are a helpful assistant.",
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
    ) -> AsyncGenerator[str, None]:
        """Stream response tokens from the specified provider."""
        providers_to_try = [provider] + self._fallback_providers(provider)
        last_error: Optional[ProviderError] = None
        for candidate in providers_to_try:
            started = False
            start = time()
            try:
                async for chunk in self._stream_provider(
                    candidate, prompt, system, model, max_tokens, temperature
                ):
                    started = True
                    yield chunk
                elapsed_ms = (time() - start) * 1000
                logger.debug(
                    "provider=%s stream_complete elapsed=%.0fms",
                    candidate,
                    elapsed_ms,
                )
                return
            except (AuthenticationError, RateLimitError):
                raise
            except ProviderError as exc:
                last_error = exc
                if started:
                    raise
                continue
        if last_error:
            raise last_error

    async def health(self) -> dict[str, bool]:
        """Check connectivity to all configured providers."""
        results: dict[str, bool] = {}
        for name, provider in self._providers.items():
            if not provider.is_configured():
                results[name] = False
                continue
            try:
                await self._call_provider(
                    name,
                    "ping",
                    "You are a helpful assistant.",
                    None,
                    5,
                    0.0,
                )
                results[name] = True
            except AgentForgeError:
                results[name] = False
        return results

    def _fallback_providers(self, primary: str) -> list[str]:
        seen = {primary}
        ordered: list[str] = []
        for provider in self.fallback_chain:
            if provider in seen:
                continue
            if provider not in self._providers:
                continue
            seen.add(provider)
            ordered.append(provider)
        return ordered

    async def _call_provider(
        self,
        provider: str,
        prompt: str,
        system: str,
        model: Optional[str],
        max_tokens: Optional[int],
        temperature: Optional[float],
    ) -> AIResponse:
        if provider not in self._providers:
            raise ValueError(
                f"Unknown provider: {provider}. Choose from: {list(self._providers.keys())}"
            )
        resolved_model = model or self.DEFAULT_MODELS[provider]
        resolved_max_tokens = max_tokens or self.max_tokens
        resolved_temperature = (
            temperature if temperature is not None else self.temperature
        )
        response = await self._providers[provider].chat(
            prompt, system, resolved_model, resolved_temperature, resolved_max_tokens
        )
        logger.debug(
            "provider=%s model=%s prompt_len=%d response_len=%d elapsed=%.0fms",
            provider,
            response.model,
            len(prompt),
            len(response.content),
            response.elapsed_ms,
        )
        return response

    async def _stream_provider(
        self,
        provider: str,
        prompt: str,
        system: str,
        model: Optional[str],
        max_tokens: Optional[int],
        temperature: Optional[float],
    ) -> AsyncGenerator[str, None]:
        if provider not in self._providers:
            raise ValueError(
                f"Unknown provider: {provider}. Choose from: {list(self._providers.keys())}"
            )
        resolved_model = model or self.DEFAULT_MODELS[provider]
        resolved_max_tokens = max_tokens or self.max_tokens
        resolved_temperature = (
            temperature if temperature is not None else self.temperature
        )
        async for chunk in self._providers[provider].stream(
            prompt, system, resolved_model, resolved_temperature, resolved_max_tokens
        ):
            yield chunk

    async def _request_json(
        self,
        provider: str,
        url: str,
        payload: dict,
        headers: Optional[dict] = None,
    ) -> tuple[dict, float, int]:
        """Execute an HTTP POST with retry and exponential backoff."""
        last_error: Optional[Exception] = None

        for attempt in range(1, self.max_retries + 1):
            start = time()
            try:
                async with httpx.AsyncClient() as client:
                    response = await client.post(
                        url, json=payload, headers=headers, timeout=self.timeout
                    )
                elapsed = (time() - start) * 1000
                logger.debug(
                    "provider=%s attempt=%d status=%d elapsed=%.0fms",
                    provider,
                    attempt,
                    response.status_code,
                    elapsed,
                )
                if response.status_code in (401, 403):
                    raise AuthenticationError(
                        provider,
                        f"Authentication failed (HTTP {response.status_code})",
                        status_code=response.status_code,
                    )
                if response.status_code == 429:
                    raise RateLimitError(
                        provider, "Rate limit exceeded (HTTP 429)", status_code=429
                    )
                response.raise_for_status()
                return response.json(), elapsed, response.status_code
            except (AuthenticationError, RateLimitError):
                raise
            except (
                httpx.TimeoutException,
                httpx.ConnectError,
                httpx.HTTPStatusError,
            ) as exc:
                last_error = exc
                if attempt < self.max_retries:
                    delay = 2 ** (attempt - 1)
                    logger.warning(
                        "provider=%s attempt=%d/%d failed, retrying in %ds: %s",
                        provider,
                        attempt,
                        self.max_retries,
                        delay,
                        exc,
                    )
                    await asyncio.sleep(delay)

        raise ProviderError(
            provider, f"Request failed after {self.max_retries} attempts: {last_error}"
        )

    async def _stream_lines(
        self,
        provider: str,
        url: str,
        payload: dict,
        headers: Optional[dict] = None,
    ) -> AsyncGenerator[str, None]:
        """Stream SSE lines with retry on pre-data failures."""
        last_error: Optional[Exception] = None
        for attempt in range(1, self.max_retries + 1):
            received_any = False
            try:
                async with httpx.AsyncClient() as client:
                    async with client.stream(
                        "POST", url, json=payload, headers=headers, timeout=self.timeout
                    ) as response:
                        if response.status_code in (401, 403):
                            raise AuthenticationError(
                                provider,
                                f"Authentication failed (HTTP {response.status_code})",
                                status_code=response.status_code,
                            )
                        if response.status_code == 429:
                            raise RateLimitError(
                                provider,
                                "Rate limit exceeded (HTTP 429)",
                                status_code=429,
                            )
                        response.raise_for_status()
                        async for line in response.aiter_lines():
                            if line:
                                received_any = True
                            yield line
                return
            except (AuthenticationError, RateLimitError):
                raise
            except (
                httpx.TimeoutException,
                httpx.ConnectError,
                httpx.HTTPStatusError,
            ) as exc:
                last_error = exc
                if received_any:
                    break
                if attempt < self.max_retries:
                    delay = 2 ** (attempt - 1)
                    logger.warning(
                        "provider=%s attempt=%d/%d stream failed, retrying in %ds: %s",
                        provider,
                        attempt,
                        self.max_retries,
                        delay,
                        exc,
                    )
                    await asyncio.sleep(delay)
                else:
                    break

        raise ProviderError(
            provider, f"Stream failed after {self.max_retries} attempts: {last_error}"
        )
