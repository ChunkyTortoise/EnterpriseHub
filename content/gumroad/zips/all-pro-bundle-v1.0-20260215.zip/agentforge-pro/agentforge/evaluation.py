"""Agent evaluation framework for scoring quality, latency, cost, and tool accuracy."""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("agentforge.evaluation")


@dataclass
class EvalCase:
    """A single evaluation test case."""

    input_text: str
    expected_output: str
    expected_tools: list[str] = field(default_factory=list)
    max_latency_ms: float = 5000.0
    metadata: dict[str, Any] = field(default_factory=dict)
    case_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])


@dataclass
class EvalResult:
    """Result of evaluating a single case."""

    case_id: str
    quality_score: float  # 0.0 - 1.0
    latency_ms: float
    cost_usd: float
    tool_accuracy: float  # 0.0 - 1.0
    passed: bool


@dataclass
class EvalReport:
    """Aggregate report from evaluating a batch of cases."""

    results: list[EvalResult] = field(default_factory=list)
    mean_quality: float = 0.0
    mean_latency: float = 0.0
    mean_cost: float = 0.0
    pass_rate: float = 0.0
    p50_latency: float = 0.0
    p95_latency: float = 0.0
    p99_latency: float = 0.0


class AgentEvaluator:
    """Evaluates agent performance across quality, latency, cost, and tool accuracy.

    Uses Jaccard similarity for quality scoring and set overlap for tool accuracy.
    """

    @staticmethod
    def _jaccard_similarity(text_a: str, text_b: str) -> float:
        """Compute Jaccard similarity between keyword sets of two texts."""
        if not text_a and not text_b:
            return 1.0
        if not text_a or not text_b:
            return 0.0
        set_a = set(text_a.lower().split())
        set_b = set(text_b.lower().split())
        if not set_a and not set_b:
            return 1.0
        if not set_a or not set_b:
            return 0.0
        intersection = set_a & set_b
        union = set_a | set_b
        return len(intersection) / len(union)

    @staticmethod
    def _tool_accuracy(expected: list[str], actual: list[str]) -> float:
        """Compute tool accuracy as set overlap ratio."""
        if not expected and not actual:
            return 1.0
        if not expected or not actual:
            return 0.0
        set_expected = set(expected)
        set_actual = set(actual)
        intersection = set_expected & set_actual
        union = set_expected | set_actual
        return len(intersection) / len(union)

    def evaluate_case(
        self,
        case: EvalCase,
        actual_output: str,
        actual_tools: list[str],
        latency_ms: float,
        cost_usd: float,
    ) -> EvalResult:
        """Evaluate a single case against actual results.

        Args:
            case: The evaluation case with expected values.
            actual_output: The actual output text produced.
            actual_tools: List of tool names actually invoked.
            latency_ms: Actual latency in milliseconds.
            cost_usd: Actual cost in USD.

        Returns:
            EvalResult with computed scores.
        """
        quality = self._jaccard_similarity(case.expected_output, actual_output)
        tool_acc = self._tool_accuracy(case.expected_tools, actual_tools)
        passed = (
            quality >= 0.5 and latency_ms <= case.max_latency_ms and tool_acc >= 0.5
        )

        return EvalResult(
            case_id=case.case_id,
            quality_score=round(quality, 4),
            latency_ms=latency_ms,
            cost_usd=cost_usd,
            tool_accuracy=round(tool_acc, 4),
            passed=passed,
        )

    def evaluate_batch(
        self,
        cases_with_results: list[tuple[EvalCase, str, list[str], float, float]],
    ) -> EvalReport:
        """Evaluate a batch of cases and produce an aggregate report.

        Args:
            cases_with_results: List of tuples, each containing:
                (case, actual_output, actual_tools, latency_ms, cost_usd)

        Returns:
            EvalReport with aggregate statistics.
        """
        if not cases_with_results:
            return EvalReport()

        results = [
            self.evaluate_case(case, output, tools, latency, cost)
            for case, output, tools, latency, cost in cases_with_results
        ]

        latencies = sorted(r.latency_ms for r in results)
        n = len(latencies)

        def percentile(sorted_vals: list[float], pct: float) -> float:
            if not sorted_vals:
                return 0.0
            idx = int(pct / 100.0 * (len(sorted_vals) - 1))
            return sorted_vals[idx]

        return EvalReport(
            results=results,
            mean_quality=round(sum(r.quality_score for r in results) / n, 4),
            mean_latency=round(sum(r.latency_ms for r in results) / n, 4),
            mean_cost=round(sum(r.cost_usd for r in results) / n, 8),
            pass_rate=round(sum(1 for r in results if r.passed) / n, 4),
            p50_latency=percentile(latencies, 50),
            p95_latency=percentile(latencies, 95),
            p99_latency=percentile(latencies, 99),
        )

    @staticmethod
    def compare_reports(report_a: EvalReport, report_b: EvalReport) -> dict[str, Any]:
        """Compare two evaluation reports.

        Returns dict with differences (b - a) for key metrics.
        """
        return {
            "quality_diff": round(report_b.mean_quality - report_a.mean_quality, 4),
            "latency_diff": round(report_b.mean_latency - report_a.mean_latency, 4),
            "cost_diff": round(report_b.mean_cost - report_a.mean_cost, 8),
            "pass_rate_diff": round(report_b.pass_rate - report_a.pass_rate, 4),
        }
