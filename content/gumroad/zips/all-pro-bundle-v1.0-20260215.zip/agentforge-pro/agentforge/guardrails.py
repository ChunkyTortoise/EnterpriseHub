"""Guardrails engine: input/output validation, PII masking, injection detection.

Provides safety checks for LLM inputs and outputs including token limits,
prompt injection detection, PII masking, and content policy enforcement.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class Violation:
    """A single guardrail violation."""

    rule: str
    severity: str  # "low", "medium", "high", "critical"
    detail: str


@dataclass
class GuardrailResult:
    """Result of a guardrail check."""

    passed: bool
    violations: list[Violation] = field(default_factory=list)
    sanitized_text: str = ""


# Common PII patterns
_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
_PHONE_RE = re.compile(r"(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}")
_SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")

# Prompt injection patterns
_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(all\s+)?previous\s+instructions", re.IGNORECASE),
    re.compile(r"disregard\s+(all\s+)?(prior|previous|above)\s+", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+", re.IGNORECASE),
    re.compile(r"system\s*:\s*", re.IGNORECASE),
    re.compile(r"<\|?system\|?>", re.IGNORECASE),
    re.compile(r"pretend\s+you\s+are\s+", re.IGNORECASE),
    re.compile(r"forget\s+(all\s+)?(your\s+)?instructions", re.IGNORECASE),
    re.compile(r"override\s+(your\s+)?(rules|instructions|guidelines)", re.IGNORECASE),
]

# Hallucination signals in output
_HALLUCINATION_SIGNALS = [
    re.compile(r"as\s+an?\s+ai\s+(language\s+)?model", re.IGNORECASE),
    re.compile(
        r"i\s+(?:don'?t|do\s+not)\s+have\s+(?:access|the\s+ability)", re.IGNORECASE
    ),
    re.compile(
        r"i\s+cannot\s+(?:browse|access|search)\s+the\s+internet", re.IGNORECASE
    ),
]


class GuardrailsEngine:
    """Input/output validation engine with PII masking and injection detection.

    Provides composable safety checks for LLM pipelines.
    """

    def check_input(self, text: str, max_tokens: int = 4000) -> GuardrailResult:
        """Validate input text for safety.

        Checks: token length, prompt injection, PII presence.
        """
        violations: list[Violation] = []
        sanitized = text

        # Token length check
        estimated_tokens = max(1, len(text) // 4)
        if estimated_tokens > max_tokens:
            violations.append(
                Violation(
                    rule="token_limit",
                    severity="medium",
                    detail=f"Input exceeds token limit: ~{estimated_tokens} > {max_tokens}",
                )
            )
            sanitized = self.enforce_token_limit(text, max_tokens)

        # Injection check
        if self.detect_injection(text):
            violations.append(
                Violation(
                    rule="prompt_injection",
                    severity="critical",
                    detail="Potential prompt injection detected",
                )
            )

        # PII check
        pii_types = self._detect_pii_types(text)
        if pii_types:
            violations.append(
                Violation(
                    rule="pii_detected",
                    severity="high",
                    detail=f"PII found: {', '.join(pii_types)}",
                )
            )
            sanitized = self.mask_pii(sanitized)

        passed = not any(v.severity in ("critical", "high") for v in violations)
        return GuardrailResult(
            passed=passed, violations=violations, sanitized_text=sanitized
        )

    def check_output(self, text: str, max_tokens: int = 4000) -> GuardrailResult:
        """Validate output text for safety.

        Checks: token length, hallucination signals, PII leaks.
        """
        violations: list[Violation] = []
        sanitized = text

        # Token length
        estimated_tokens = max(1, len(text) // 4)
        if estimated_tokens > max_tokens:
            violations.append(
                Violation(
                    rule="token_limit",
                    severity="low",
                    detail=f"Output exceeds token limit: ~{estimated_tokens} > {max_tokens}",
                )
            )
            sanitized = self.enforce_token_limit(text, max_tokens)

        # Hallucination signals
        for pattern in _HALLUCINATION_SIGNALS:
            if pattern.search(text):
                violations.append(
                    Violation(
                        rule="hallucination_signal",
                        severity="medium",
                        detail=f"Hallucination signal: {pattern.pattern}",
                    )
                )
                break

        # PII leak
        pii_types = self._detect_pii_types(text)
        if pii_types:
            violations.append(
                Violation(
                    rule="pii_leak",
                    severity="high",
                    detail=f"PII in output: {', '.join(pii_types)}",
                )
            )
            sanitized = self.mask_pii(sanitized)

        passed = not any(v.severity in ("critical", "high") for v in violations)
        return GuardrailResult(
            passed=passed, violations=violations, sanitized_text=sanitized
        )

    def mask_pii(self, text: str) -> str:
        """Replace emails, phone numbers, and SSNs with [REDACTED]."""
        result = _SSN_RE.sub("[REDACTED]", text)
        result = _EMAIL_RE.sub("[REDACTED]", result)
        result = _PHONE_RE.sub("[REDACTED]", result)
        return result

    def detect_injection(self, text: str) -> bool:
        """Detect common prompt injection patterns."""
        for pattern in _INJECTION_PATTERNS:
            if pattern.search(text):
                return True
        return False

    def enforce_token_limit(self, text: str, max_tokens: int = 4000) -> str:
        """Truncate text to fit within token limit.

        Uses a rough estimate of 4 characters per token. Adds a truncation
        indicator if the text was shortened.
        """
        max_chars = max_tokens * 4
        if len(text) <= max_chars:
            return text
        return text[:max_chars] + "... [truncated]"

    def _detect_pii_types(self, text: str) -> list[str]:
        """Detect which types of PII are present in text."""
        found: list[str] = []
        if _EMAIL_RE.search(text):
            found.append("email")
        if _SSN_RE.search(text):
            found.append("ssn")
        if _PHONE_RE.search(text):
            found.append("phone")
        return found
