"""AgentForge exception hierarchy."""

from __future__ import annotations

from typing import Optional


class AgentForgeError(Exception):
    """Base exception for AgentForge errors."""


class ProviderError(AgentForgeError):
    """Raised when a provider API call fails after all retries."""

    def __init__(self, provider: str, message: str, status_code: Optional[int] = None):
        self.provider = provider
        self.status_code = status_code
        super().__init__(f"[{provider}] {message}")


class AuthenticationError(ProviderError):
    """Raised when API authentication fails (401/403 or missing key)."""


class RateLimitError(ProviderError):
    """Raised when a provider returns a rate limit response (429)."""
