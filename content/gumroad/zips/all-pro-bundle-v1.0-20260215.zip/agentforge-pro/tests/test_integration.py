"""Integration tests for AgentForge.

These tests call real provider APIs and are skipped if API keys are missing.
Run with: pytest test_integration.py -m integration -v
"""

import os

import pytest

from agentforge import AIOrchestrator


@pytest.mark.integration
@pytest.mark.asyncio
@pytest.mark.skipif(not os.getenv("GOOGLE_API_KEY"), reason="No GOOGLE_API_KEY")
async def test_gemini_real_request():
    orc = AIOrchestrator(max_tokens=50)
    response = await orc.chat("gemini", "Say 'hello' and nothing else")
    assert "hello" in response.content.lower()
    assert response.provider == "gemini"
    assert response.elapsed_ms > 0


@pytest.mark.integration
@pytest.mark.asyncio
@pytest.mark.skipif(not os.getenv("PERPLEXITY_API_KEY"), reason="No PERPLEXITY_API_KEY")
async def test_perplexity_real_request():
    orc = AIOrchestrator(max_tokens=50)
    response = await orc.chat("perplexity", "Say 'hello' and nothing else")
    assert "hello" in response.content.lower()
    assert response.provider == "perplexity"
    assert response.elapsed_ms > 0


@pytest.mark.integration
@pytest.mark.asyncio
@pytest.mark.skipif(not os.getenv("ANTHROPIC_API_KEY"), reason="No ANTHROPIC_API_KEY")
async def test_claude_real_request():
    orc = AIOrchestrator(max_tokens=50)
    response = await orc.chat("claude", "Say 'hello' and nothing else")
    assert "hello" in response.content.lower()
    assert response.provider == "claude"
    assert response.elapsed_ms > 0


@pytest.mark.integration
@pytest.mark.asyncio
@pytest.mark.skipif(not os.getenv("OPENAI_API_KEY"), reason="No OPENAI_API_KEY")
async def test_openai_real_request():
    orc = AIOrchestrator(max_tokens=50)
    response = await orc.chat("openai", "Say 'hello' and nothing else")
    assert "hello" in response.content.lower()
    assert response.provider == "openai"
    assert response.elapsed_ms > 0


@pytest.mark.integration
@pytest.mark.asyncio
@pytest.mark.skipif(not os.getenv("OPENAI_API_KEY"), reason="No OPENAI_API_KEY")
async def test_openai_streaming_real_request():
    orc = AIOrchestrator(max_tokens=50)
    chunks = []
    async for chunk in orc.stream("openai", "Say 'hello' and nothing else"):
        chunks.append(chunk)
    text = "".join(chunks)
    assert "hello" in text.lower()
