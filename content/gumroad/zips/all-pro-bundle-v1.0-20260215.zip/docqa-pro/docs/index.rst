docqa-engine Documentation
==========================

**RAG document Q&A with prompt engineering lab**

Upload documents, ask questions — production-ready RAG pipeline with hybrid retrieval, prompt engineering lab, and comprehensive evaluation tools.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   quickstart
   api
   modules
   COMPARISON

Quick Links
-----------

* :doc:`quickstart` — Get started in 5 minutes
* :doc:`api` — REST API reference
* :doc:`modules` — Python API reference
* :doc:`COMPARISON` — vs LlamaIndex vs Haystack
* `Benchmarks <../BENCHMARKS.md>`_ — Performance & citation scoring benchmarks
* `Live Demo <https://ct-document-engine.streamlit.app>`_ — Try it online
* `GitHub Repository <https://github.com/ChunkyTortoise/docqa-engine>`_ — Source code

Features
--------

* **Hybrid Retrieval**: Combines BM25 + TF-IDF vectors + RRF for optimal recall
* **Compliance & Intelligence**: Citation verification, audit trails, regulatory mapping
* **Context Compression**: Reduces token usage by 40-60% while preserving answer quality
* **Multi-hop Queries**: Handles complex questions requiring multiple document lookups
* **Citation Scoring**: Verifies answers against source documents with confidence scores
* **Prompt Engineering Lab**: A/B test prompts, compare models, optimize parameters
* **Zero External Dependencies**: Local TF-IDF embeddings, no vendor lock-in
* **On-Premise Ready**: Full deployment support for air-gapped environments

Installation
------------

.. code-block:: bash

   pip install docqa-engine

Or install from source:

.. code-block:: bash

   git clone https://github.com/ChunkyTortoise/docqa-engine.git
   cd docqa-engine
   pip install -e ".[dev]"

Quick Example
-------------

.. code-block:: python

   from docqa_engine import DocumentQA

   # Initialize the pipeline
   qa = DocumentQA()

   # Ingest documents
   qa.ingest("path/to/your/documents/")

   # Ask questions
   answer = qa.query("What are the key findings in the report?")
   print(answer.text)
   print(answer.citations)  # Source references

Architecture
------------

The docqa-engine consists of modular components:

* **Ingest**: Document loading, chunking, and embedding
* **Retrieve**: Vector search + keyword retrieval + reranking
* **Answer**: LLM generation with context compression
* **Evaluate**: Quality scoring, benchmarks, comparison tools
* **Export**: Multiple output formats (JSON, CSV, PDF)

Indices and Tables
================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
