REST API Reference
==================

docqa-engine provides a FastAPI-based REST API for integration with other services.

Running the API Server
----------------------

.. code-block:: bash

   # Development
   uvicorn docqa_engine.api:app --reload
   
   # Production
   uvicorn docqa_engine.api:app --host 0.0.0.0 --port 8000

API Documentation
-----------------

Interactive API docs are available at:

* **Swagger UI**: ``http://localhost:8000/docs``
* **ReDoc**: ``http://localhost:8000/redoc``
* **OpenAPI Schema**: ``http://localhost:8000/openapi.json``

Endpoints
---------

Documents
~~~~~~~~~

**POST** ``/api/documents/upload``
   Upload a document for indexing.
   
   Request: multipart/form-data with file
   
   Response:
   
   .. code-block:: json

      {
        "document_id": "uuid",
        "filename": "report.pdf",
        "chunks_created": 12,
        "status": "indexed"
      }

**GET** ``/api/documents``
   List all indexed documents.
   
   Response:
   
   .. code-block:: json

      {
        "documents": [
          {
            "id": "uuid",
            "filename": "report.pdf",
            "uploaded_at": "2026-02-12T10:00:00Z",
            "chunk_count": 12
          }
        ],
        "total": 1
      }

**DELETE** ``/api/documents/{document_id}``
   Remove a document from the index.

Query
~~~~~

**POST** ``/api/query``
   Ask a question against indexed documents.
   
   Request:
   
   .. code-block:: json

      {
        "query": "What are the key findings?",
        "top_k": 5,
        "include_citations": true
      }
   
   Response:
   
   .. code-block:: json

      {
        "answer": "The key findings are...",
        "citations": [
          {
            "document_id": "uuid",
            "chunk_id": "uuid",
            "text": "relevant passage",
            "score": 0.95
          }
        ],
        "confidence": 0.92,
        "processing_time_ms": 1250
      }

Batch Processing
~~~~~~~~~~~~~~~~

**POST** ``/api/batch/query``
   Process multiple queries in batch.
   
   Request:
   
   .. code-block:: json

      {
        "queries": [
          "What is the budget?",
          "Who are the stakeholders?"
        ],
        "config": {
          "top_k": 5
        }
      }

Evaluation
~~~~~~~~~~

**POST** ``/api/evaluate``
   Run evaluation on a test dataset.
   
   Request:
   
   .. code-block:: json

      {
        "test_file": "test_questions.json",
        "metrics": ["accuracy", "citation_score", "latency"]
      }

Health Check
~~~~~~~~~~~~

**GET** ``/health``
   Check API health status.
   
   Response:
   
   .. code-block:: json

      {
        "status": "healthy",
        "version": "0.1.0",
        "timestamp": "2026-02-12T10:00:00Z"
      }

Error Handling
--------------

All errors follow this format:

.. code-block:: json

   {
     "error": "Error type",
     "message": "Human-readable description",
     "code": "ERROR_CODE"
   }

Common HTTP status codes:

* ``200`` — Success
* ``400`` — Bad Request (invalid input)
* ``404`` — Document not found
* ``422`` — Validation error
* ``500`` — Internal server error

Authentication
--------------

API authentication can be configured via environment variables:

.. code-block:: bash

   API_KEY=your_secret_key  # If API key protection is enabled

Pass the API key in the ``X-API-Key`` header:

.. code-block:: bash

   curl -H "X-API-Key: your_secret_key" http://localhost:8000/api/documents

Rate Limiting
-------------

Default rate limits:

* 100 requests per minute per IP
* 1000 requests per hour per IP

Configure via environment variables:

.. code-block:: bash

   RATE_LIMIT_PER_MINUTE=100
   RATE_LIMIT_PER_HOUR=1000
