#!/usr/bin/env python3
"""Generate OpenAPI specification for DocQA Engine API."""

import json
import sys
from pathlib import Path

import yaml

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from docqa_engine.api import create_app


def generate_openapi_spec(output_format: str = "json") -> None:
    """Generate and save OpenAPI specification."""
    app = create_app()
    
    # Get OpenAPI schema
    openapi_schema = app.openapi()
    
    # Add metadata
    openapi_schema["info"]["description"] = (
        "REST API for DocQA Engine - RAG document Q&A with prompt engineering lab.\n\n"
        "## Authentication\n\n"
        "All endpoints require an API key via the `X-API-Key` header.\n\n"
        "## Features\n\n"
        "- Document ingestion with automatic chunking\n"
        "- Question answering with source citations\n"
        "- Usage tracking and rate limiting\n"
    )
    openapi_schema["info"]["contact"] = {
        "name": "Cayman Roden",
        "email": "cayman.roden@gmail.com",
        "url": "https://chunkytortoise.github.io",
    }
    openapi_schema["info"]["license"] = {
        "name": "MIT",
        "url": "https://opensource.org/licenses/MIT",
    }
    openapi_schema["externalDocs"] = {
        "description": "Documentation",
        "url": "https://github.com/ChunkyTortoise/docqa-engine/blob/main/README.md",
    }
    
    # Add servers
    openapi_schema["servers"] = [
        {"url": "http://localhost:8000", "description": "Local development"},
        {"url": "https://api.docqa.example.com", "description": "Production"},
    ]
    
    # Output directory
    output_dir = Path(__file__).parent.parent / "api"
    output_dir.mkdir(exist_ok=True)
    
    if output_format == "json":
        output_file = output_dir / "openapi.json"
        with open(output_file, "w") as f:
            json.dump(openapi_schema, f, indent=2)
    else:
        output_file = output_dir / "openapi.yaml"
        with open(output_file, "w") as f:
            yaml.dump(openapi_schema, f, default_flow_style=False, sort_keys=False)
    
    print(f"OpenAPI spec generated: {output_file}")
    print(f"Endpoints: {len(openapi_schema['paths'])}")
    print(f"Schemas: {len(openapi_schema.get('components', {}).get('schemas', {}))}")


if __name__ == "__main__":
    format_arg = sys.argv[1] if len(sys.argv) > 1 else "json"
    generate_openapi_spec(format_arg)
