"""Tests for ToolRegistry, tool formatting, execution, and parsing."""

import json

import pytest

from agentforge.tools import ToolCall, ToolRegistry

# ── Registration ───────────────────────────────────────────────────────────


class TestToolRegistry:
    def test_register_tool(self) -> None:
        """Register and retrieve a tool by name."""
        registry = ToolRegistry()
        params = {"type": "object", "properties": {"query": {"type": "string"}}}
        tool = registry.register("search", "Search the web", params)

        assert tool.name == "search"
        assert tool.description == "Search the web"
        assert tool.parameters == params
        retrieved = registry.get("search")
        assert retrieved is not None
        assert retrieved.name == "search"

    def test_register_function(self) -> None:
        """Auto-registers from callable with name and parameter schema."""

        def greet(name: str, greeting: str = "Hello") -> str:
            """Greet someone."""
            return f"{greeting}, {name}!"

        registry = ToolRegistry()
        tool = registry.register_function(greet)

        assert tool.name == "greet"
        assert tool.description == "Greet someone."
        assert "name" in tool.parameters["properties"]
        assert "greeting" in tool.parameters["properties"]
        assert "name" in tool.parameters["required"]
        # greeting has a default so should not be required
        assert "greeting" not in tool.parameters["required"]
        assert tool.handler is greet

    def test_list_tools(self) -> None:
        """Lists all registered tools."""
        registry = ToolRegistry()
        registry.register("a", "Tool A", {"type": "object"})
        registry.register("b", "Tool B", {"type": "object"})
        tools = registry.list_tools()
        assert len(tools) == 2
        names = {t.name for t in tools}
        assert names == {"a", "b"}

    def test_get_nonexistent(self) -> None:
        """Returns None for unregistered tool."""
        registry = ToolRegistry()
        assert registry.get("nonexistent") is None


class TestRegistration:
    def test_duplicate_overwrites(self) -> None:
        """Registering same name overwrites previous tool."""
        registry = ToolRegistry()
        registry.register("tool", "Version 1", {"type": "object"})
        registry.register("tool", "Version 2", {"type": "object"})
        tool = registry.get("tool")
        assert tool is not None
        assert tool.description == "Version 2"
        assert len(registry.list_tools()) == 1


# ── Format Conversion ─────────────────────────────────────────────────────


class TestFormatConversion:
    def test_claude_format(self) -> None:
        """Correct Claude API structure with input_schema."""
        registry = ToolRegistry()
        params = {"type": "object", "properties": {"q": {"type": "string"}}}
        registry.register("search", "Search", params)
        result = registry.to_claude_format()

        assert len(result) == 1
        assert result[0]["name"] == "search"
        assert result[0]["description"] == "Search"
        assert result[0]["input_schema"] == params

    def test_openai_format(self) -> None:
        """Correct OpenAI API structure with type/function wrapper."""
        registry = ToolRegistry()
        params = {"type": "object", "properties": {"q": {"type": "string"}}}
        registry.register("search", "Search", params)
        result = registry.to_openai_format()

        assert len(result) == 1
        assert result[0]["type"] == "function"
        assert result[0]["function"]["name"] == "search"
        assert result[0]["function"]["description"] == "Search"
        assert result[0]["function"]["parameters"] == params

    def test_empty_registry(self) -> None:
        """Empty registry returns empty list for both formats."""
        registry = ToolRegistry()
        assert registry.to_claude_format() == []
        assert registry.to_openai_format() == []


# ── Execution ──────────────────────────────────────────────────────────────


class TestExecution:
    def test_execute_with_handler(self) -> None:
        """Handler called with correct arguments and result returned."""

        def add(a: int, b: int) -> int:
            return a + b

        registry = ToolRegistry()
        registry.register(
            "add",
            "Add numbers",
            {"type": "object", "properties": {}},
            handler=add,
        )
        call = ToolCall(name="add", arguments={"a": 3, "b": 5}, call_id="c1")
        result = registry.execute(call)

        assert result.call_id == "c1"
        assert result.name == "add"
        assert result.result == 8
        assert result.error is None

    def test_execute_no_handler(self) -> None:
        """Returns error result when no handler registered."""
        registry = ToolRegistry()
        registry.register("noop", "No handler", {"type": "object"})
        call = ToolCall(name="noop", arguments={}, call_id="c2")
        result = registry.execute(call)

        assert result.error is not None
        assert "No handler" in result.error
        assert result.result is None

    def test_execute_handler_error(self) -> None:
        """Handler exception captured in error field."""

        def bad_func() -> None:
            raise RuntimeError("something broke")

        registry = ToolRegistry()
        registry.register("bad", "Broken tool", {"type": "object"}, handler=bad_func)
        call = ToolCall(name="bad", arguments={}, call_id="c3")
        result = registry.execute(call)

        assert result.error is not None
        assert "something broke" in result.error
        assert result.result is None

    def test_execute_all(self) -> None:
        """Multiple tool calls executed and results returned."""

        def double(x: int) -> int:
            return x * 2

        registry = ToolRegistry()
        registry.register(
            "double", "Double a number", {"type": "object"}, handler=double
        )
        calls = [
            ToolCall(name="double", arguments={"x": 3}, call_id="a"),
            ToolCall(name="double", arguments={"x": 7}, call_id="b"),
        ]
        results = registry.execute_all(calls)

        assert len(results) == 2
        assert results[0].result == 6
        assert results[1].result == 14


# ── Parsing ────────────────────────────────────────────────────────────────


class TestParsing:
    def test_parse_claude_response(self) -> None:
        """Parses Claude tool_use format from content blocks."""
        registry = ToolRegistry()
        response = {
            "content": [
                {"type": "text", "text": "Let me search for that."},
                {
                    "type": "tool_use",
                    "id": "toolu_123",
                    "name": "search",
                    "input": {"query": "weather"},
                },
            ]
        }
        calls = registry.parse_tool_calls(response)

        assert len(calls) == 1
        assert calls[0].name == "search"
        assert calls[0].arguments == {"query": "weather"}
        assert calls[0].call_id == "toolu_123"

    def test_parse_openai_response(self) -> None:
        """Parses OpenAI tool_calls format."""
        registry = ToolRegistry()
        response = {
            "tool_calls": [
                {
                    "id": "call_abc",
                    "type": "function",
                    "function": {
                        "name": "get_weather",
                        "arguments": json.dumps({"city": "LA"}),
                    },
                }
            ]
        }
        calls = registry.parse_tool_calls(response)

        assert len(calls) == 1
        assert calls[0].name == "get_weather"
        assert calls[0].arguments == {"city": "LA"}
        assert calls[0].call_id == "call_abc"

    def test_parse_no_tools(self) -> None:
        """Empty response returns empty list."""
        registry = ToolRegistry()
        calls = registry.parse_tool_calls({"content": [{"type": "text", "text": "Hi"}]})
        assert calls == []

    def test_parse_invalid(self) -> None:
        """Malformed response returns empty list."""
        registry = ToolRegistry()
        # Completely wrong structure
        calls = registry.parse_tool_calls({"garbage": True})
        assert calls == []


# ── Validation ─────────────────────────────────────────────────────────────


class TestToolValidation:
    def test_validate_valid_params(self) -> None:
        """Valid params pass validation."""
        registry = ToolRegistry()
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "number"},
            },
            "required": ["name"],
        }
        registry.register("user", "User info", schema)

        # Should not raise
        assert registry.validate_params("user", {"name": "Alice", "age": 30}) is True

    def test_validate_missing_required(self) -> None:
        """Missing required field raises ValueError."""
        registry = ToolRegistry()
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        registry.register("user", "User info", schema)

        try:
            registry.validate_params("user", {})
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "Missing required field: name" in str(e)

    def test_validate_wrong_type(self) -> None:
        """Wrong type raises ValueError."""
        registry = ToolRegistry()
        schema = {
            "type": "object",
            "properties": {"age": {"type": "number"}},
        }
        registry.register("user", "User info", schema)

        try:
            registry.validate_params("user", {"age": "not a number"})
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "expected type number" in str(e)

    def test_validate_no_schema(self) -> None:
        """Tool without schema always passes."""
        registry = ToolRegistry()
        registry.register("noop", "No schema", {})

        # Should pass with any params
        assert registry.validate_params("noop", {"anything": "goes"}) is True


# ── Tool Chaining ──────────────────────────────────────────────────────────


class TestToolChaining:
    def test_chain_two_tools(self) -> None:
        """Output of first tool feeds into second."""

        def double(value: int) -> dict[str, int]:
            return {"value": value * 2}

        def add_ten(value: int) -> int:
            return value + 10

        registry = ToolRegistry()
        registry.register("double", "Double", {"type": "object"}, handler=double)
        registry.register("add_ten", "Add 10", {"type": "object"}, handler=add_ten)

        results = registry.chain(["double", "add_ten"], {"value": 5})

        assert len(results) == 2
        assert results[0].result == {"value": 10}
        assert results[1].result == 20

    def test_chain_error_stops(self) -> None:
        """Error in first tool stops chain."""

        def fail() -> None:
            raise RuntimeError("failure")

        def noop() -> str:
            return "should not run"

        registry = ToolRegistry()
        registry.register("fail", "Fails", {"type": "object"}, handler=fail)
        registry.register("noop", "No-op", {"type": "object"}, handler=noop)

        results = registry.chain(["fail", "noop"], {})

        assert len(results) == 1
        assert results[0].error is not None
        assert "failure" in results[0].error

    def test_chain_empty_list(self) -> None:
        """Empty tool list returns empty results."""
        registry = ToolRegistry()
        results = registry.chain([], {})
        assert results == []


# ── Async Execution ────────────────────────────────────────────────────────


class TestAsyncExecution:
    @pytest.mark.asyncio
    async def test_async_execute_single(self) -> None:
        """async_execute works like execute."""

        def greet(name: str) -> str:
            return f"Hello, {name}!"

        registry = ToolRegistry()
        registry.register("greet", "Greet", {"type": "object"}, handler=greet)

        result = await registry.async_execute("greet", {"name": "World"})

        assert result.name == "greet"
        assert result.result == "Hello, World!"
        assert result.error is None

    @pytest.mark.asyncio
    async def test_async_execute_all(self) -> None:
        """Multiple tools executed asynchronously."""

        def double(x: int) -> int:
            return x * 2

        registry = ToolRegistry()
        registry.register("double", "Double", {"type": "object"}, handler=double)

        calls = [
            ToolCall(name="double", arguments={"x": 3}, call_id="a"),
            ToolCall(name="double", arguments={"x": 7}, call_id="b"),
        ]
        results = await registry.async_execute_all(calls)

        assert len(results) == 2
        assert results[0].result == 6
        assert results[1].result == 14

    @pytest.mark.asyncio
    async def test_async_execute_no_handler(self) -> None:
        """Returns error result when no handler."""
        registry = ToolRegistry()
        registry.register("noop", "No handler", {"type": "object"})

        result = await registry.async_execute("noop", {})

        assert result.error is not None
        assert "No handler" in result.error


# ── Extended: Async Handler Execution ─────────────────────────────────────


class TestAsyncHandlerExecution:
    @pytest.mark.asyncio
    async def test_async_execute_captures_handler_error(self) -> None:
        """async_execute captures handler exception in error field."""

        def explode(x: int) -> None:
            raise ValueError(f"bad value: {x}")

        registry = ToolRegistry()
        registry.register("explode", "Explodes", {"type": "object"}, handler=explode)
        result = await registry.async_execute("explode", {"x": 42})

        assert result.error is not None
        assert "bad value: 42" in result.error
        assert result.result is None

    @pytest.mark.asyncio
    async def test_async_execute_all_mixed_results(self) -> None:
        """async_execute_all returns both successes and errors."""

        def good(x: int) -> int:
            return x + 1

        def bad() -> None:
            raise RuntimeError("oops")

        registry = ToolRegistry()
        registry.register("good", "Good", {"type": "object"}, handler=good)
        registry.register("bad", "Bad", {"type": "object"}, handler=bad)

        calls = [
            ToolCall(name="good", arguments={"x": 5}, call_id="ok"),
            ToolCall(name="bad", arguments={}, call_id="fail"),
        ]
        results = await registry.async_execute_all(calls)

        assert len(results) == 2
        assert results[0].result == 6
        assert results[0].error is None
        assert results[1].error is not None
        assert "oops" in results[1].error


# ── Extended: Parameter Validation ────────────────────────────────────────


class TestExtendedValidation:
    def test_validate_unknown_tool_raises(self) -> None:
        """Validating params for unknown tool raises ValueError."""
        registry = ToolRegistry()
        with pytest.raises(ValueError, match="Tool not found"):
            registry.validate_params("nonexistent", {"key": "val"})

    def test_validate_array_type(self) -> None:
        """Validates array type parameter."""
        registry = ToolRegistry()
        schema = {
            "type": "object",
            "properties": {"items": {"type": "array"}},
        }
        registry.register("t", "T", schema)
        assert registry.validate_params("t", {"items": [1, 2, 3]}) is True

    def test_validate_array_type_rejects_non_list(self) -> None:
        """Non-list value for array type raises ValueError."""
        registry = ToolRegistry()
        schema = {
            "type": "object",
            "properties": {"items": {"type": "array"}},
        }
        registry.register("t", "T", schema)
        with pytest.raises(ValueError, match="expected type array"):
            registry.validate_params("t", {"items": "not a list"})

    def test_validate_boolean_type(self) -> None:
        """Validates boolean type parameter."""
        registry = ToolRegistry()
        schema = {
            "type": "object",
            "properties": {"flag": {"type": "boolean"}},
        }
        registry.register("t", "T", schema)
        assert registry.validate_params("t", {"flag": True}) is True

    def test_validate_object_type(self) -> None:
        """Validates object (dict) type parameter."""
        registry = ToolRegistry()
        schema = {
            "type": "object",
            "properties": {"config": {"type": "object"}},
        }
        registry.register("t", "T", schema)
        assert registry.validate_params("t", {"config": {"key": "val"}}) is True

    def test_validate_extra_params_pass(self) -> None:
        """Extra params not in schema are silently ignored."""
        registry = ToolRegistry()
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}},
            "required": ["name"],
        }
        registry.register("t", "T", schema)
        assert registry.validate_params("t", {"name": "ok", "extra": 123}) is True


# ── Extended: Format Round-Trip ───────────────────────────────────────────


class TestFormatRoundTrip:
    def test_claude_format_multiple_tools(self) -> None:
        """Claude format includes all registered tools in order."""
        registry = ToolRegistry()
        registry.register("a", "Tool A", {"type": "object", "properties": {}})
        registry.register("b", "Tool B", {"type": "object", "properties": {}})
        result = registry.to_claude_format()

        assert len(result) == 2
        names = [r["name"] for r in result]
        assert "a" in names
        assert "b" in names

    def test_openai_format_multiple_tools(self) -> None:
        """OpenAI format wraps each tool in type/function structure."""
        registry = ToolRegistry()
        registry.register("x", "Tool X", {"type": "object", "properties": {}})
        registry.register("y", "Tool Y", {"type": "object", "properties": {}})
        result = registry.to_openai_format()

        assert len(result) == 2
        for item in result:
            assert item["type"] == "function"
            assert "name" in item["function"]
            assert "description" in item["function"]
            assert "parameters" in item["function"]


# ── Extended: Parsing Edge Cases ──────────────────────────────────────────


class TestParsingEdgeCases:
    def test_parse_openai_dict_arguments(self) -> None:
        """OpenAI response with arguments as dict (not JSON string)."""
        registry = ToolRegistry()
        response = {
            "tool_calls": [
                {
                    "id": "call_1",
                    "type": "function",
                    "function": {
                        "name": "search",
                        "arguments": {"query": "test"},
                    },
                }
            ]
        }
        calls = registry.parse_tool_calls(response)
        assert len(calls) == 1
        assert calls[0].arguments == {"query": "test"}

    def test_parse_multiple_claude_blocks(self) -> None:
        """Parses multiple tool_use blocks from a single Claude response."""
        registry = ToolRegistry()
        response = {
            "content": [
                {"type": "tool_use", "id": "t1", "name": "a", "input": {"x": 1}},
                {"type": "text", "text": "middle"},
                {"type": "tool_use", "id": "t2", "name": "b", "input": {"y": 2}},
            ]
        }
        calls = registry.parse_tool_calls(response)
        assert len(calls) == 2
        assert calls[0].name == "a"
        assert calls[1].name == "b"

    def test_parse_empty_content_list(self) -> None:
        """Empty content list returns empty tool calls."""
        registry = ToolRegistry()
        calls = registry.parse_tool_calls({"content": []})
        assert calls == []

    def test_parse_response_with_none_content(self) -> None:
        """Response with no content or tool_calls keys returns empty list."""
        registry = ToolRegistry()
        calls = registry.parse_tool_calls({})
        assert calls == []


# ── Extended: Registration ────────────────────────────────────────────────


class TestExtendedRegistration:
    def test_register_function_without_docstring(self) -> None:
        """Function without docstring uses fallback description."""

        def mystery(x: int) -> int:
            return x

        # Remove docstring
        mystery.__doc__ = None
        registry = ToolRegistry()
        tool = registry.register_function(mystery)
        assert tool.description == "Function mystery"

    def test_register_function_custom_description(self) -> None:
        """Custom description overrides function docstring."""

        def greet(name: str) -> str:
            """Original doc."""
            return f"Hi {name}"

        registry = ToolRegistry()
        tool = registry.register_function(greet, description="Custom desc")
        assert tool.description == "Custom desc"


# ── Extended: Chaining ────────────────────────────────────────────────────


class TestExtendedChaining:
    def test_chain_non_dict_result_wraps(self) -> None:
        """Non-dict result gets wrapped in {'value': result} for next tool."""

        def step_one(value: int) -> int:
            return value * 3

        def step_two(value: int) -> int:
            return value + 1

        registry = ToolRegistry()
        registry.register("step_one", "Step 1", {"type": "object"}, handler=step_one)
        registry.register("step_two", "Step 2", {"type": "object"}, handler=step_two)

        results = registry.chain(["step_one", "step_two"], {"value": 4})
        assert len(results) == 2
        assert results[0].result == 12  # 4 * 3
        # step_two receives {"value": 12} due to wrapping
        assert results[1].result == 13  # 12 + 1

    def test_chain_three_tools(self) -> None:
        """Chain of three tools passes results through."""

        def inc(value: int) -> dict[str, int]:
            return {"value": value + 1}

        registry = ToolRegistry()
        registry.register("inc", "Increment", {"type": "object"}, handler=inc)

        results = registry.chain(["inc", "inc", "inc"], {"value": 0})
        assert len(results) == 3
        assert results[0].result == {"value": 1}
        assert results[1].result == {"value": 2}
        assert results[2].result == {"value": 3}
