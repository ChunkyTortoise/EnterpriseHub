"""Tests for StructuredOutput."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from agentforge.client_types import AIResponse
from agentforge.structured import SchemaValidationError, StructuredOutput

# ── JSON Extraction ─────────────────────────────────────────────────────────


def test_extract_raw_json():
    """Extracts JSON from a raw JSON string."""
    parser = StructuredOutput()
    result = parser.extract_json('{"name": "Alice", "age": 30}')
    assert result == {"name": "Alice", "age": 30}


def test_extract_json_from_markdown_code_block():
    """Extracts JSON from markdown code blocks."""
    parser = StructuredOutput()
    text = """Here is the result:

```json
{"city": "Rancho Cucamonga", "state": "CA"}
```

Hope that helps!"""
    result = parser.extract_json(text)
    assert result == {"city": "Rancho Cucamonga", "state": "CA"}


def test_extract_json_from_unlabeled_code_block():
    """Extracts JSON from code blocks without 'json' label."""
    parser = StructuredOutput()
    text = """Result:

```
{"key": "value"}
```
"""
    result = parser.extract_json(text)
    assert result == {"key": "value"}


def test_extract_json_embedded_in_text():
    """Extracts JSON object embedded in surrounding text."""
    parser = StructuredOutput()
    text = 'The answer is {"score": 85, "grade": "B"} based on the rubric.'
    result = parser.extract_json(text)
    assert result == {"score": 85, "grade": "B"}


def test_extract_json_no_json_raises():
    """Raises ValueError when no JSON found."""
    parser = StructuredOutput()
    with pytest.raises(ValueError, match="No valid JSON found"):
        parser.extract_json("This is just plain text with no JSON.")


# ── Schema Validation ───────────────────────────────────────────────────────


def test_schema_validation_pass():
    """Valid data passes schema validation."""
    parser = StructuredOutput()
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
        },
        "required": ["name", "age"],
    }
    errors = parser.validate({"name": "Alice", "age": 30}, schema)
    assert errors == []


def test_schema_validation_missing_required():
    """Missing required field produces validation error."""
    parser = StructuredOutput()
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "email": {"type": "string"},
        },
        "required": ["name", "email"],
    }
    errors = parser.validate({"name": "Alice"}, schema)
    assert len(errors) == 1
    assert "email" in errors[0]


def test_schema_validation_wrong_type():
    """Wrong type produces validation error."""
    parser = StructuredOutput()
    schema = {
        "type": "object",
        "properties": {
            "count": {"type": "integer"},
        },
    }
    errors = parser.validate({"count": "not a number"}, schema)
    assert len(errors) == 1
    assert "integer" in errors[0]


def test_schema_validation_nested():
    """Nested object schemas are validated recursively."""
    parser = StructuredOutput()
    schema = {
        "type": "object",
        "properties": {
            "user": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "active": {"type": "boolean"},
                },
                "required": ["name"],
            },
        },
        "required": ["user"],
    }
    # Valid nested
    errors = parser.validate({"user": {"name": "Bob", "active": True}}, schema)
    assert errors == []

    # Invalid nested (missing name)
    errors = parser.validate({"user": {"active": True}}, schema)
    assert len(errors) == 1
    assert "name" in errors[0]


def test_schema_validation_array_items():
    """Array item schemas are validated for each element."""
    parser = StructuredOutput()
    schema = {
        "type": "array",
        "items": {"type": "string"},
        "minItems": 1,
    }
    errors = parser.validate(["hello", "world"], schema)
    assert errors == []

    errors = parser.validate(["hello", 42], schema)
    assert len(errors) == 1
    assert "string" in errors[0]


# ── Parse (Extract + Validate) ──────────────────────────────────────────────


def test_parse_valid():
    """parse() extracts and validates in one call."""
    parser = StructuredOutput()
    schema = {
        "type": "object",
        "properties": {"status": {"type": "string"}},
        "required": ["status"],
    }
    result = parser.parse('{"status": "ok"}', schema)
    assert result == {"status": "ok"}


def test_parse_validation_failure_raises():
    """parse() raises SchemaValidationError on invalid data."""
    parser = StructuredOutput()
    schema = {
        "type": "object",
        "required": ["missing_field"],
    }
    with pytest.raises(SchemaValidationError) as exc_info:
        parser.parse('{"other": "data"}', schema)
    assert len(exc_info.value.errors) == 1


# ── Parse with Retry ────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_parse_with_retry_succeeds_first_try():
    """parse_with_retry succeeds on first try with valid response."""
    parser = StructuredOutput()
    schema = {
        "type": "object",
        "properties": {"answer": {"type": "string"}},
        "required": ["answer"],
    }

    mock_orchestrator = MagicMock()
    mock_orchestrator.chat = AsyncMock(
        return_value=AIResponse(
            content='{"answer": "42"}',
            provider="mock",
            model="mock-instant",
        )
    )

    result = await parser.parse_with_retry(
        mock_orchestrator, "mock", "What is the answer?", schema
    )
    assert result == {"answer": "42"}
    assert mock_orchestrator.chat.await_count == 1


@pytest.mark.asyncio
async def test_parse_with_retry_recovers_on_second_try():
    """parse_with_retry recovers after first malformed response."""
    parser = StructuredOutput()
    schema = {
        "type": "object",
        "properties": {"value": {"type": "integer"}},
        "required": ["value"],
    }

    mock_orchestrator = MagicMock()
    mock_orchestrator.chat = AsyncMock(
        side_effect=[
            AIResponse(
                content="I think the answer is about 7",
                provider="mock",
                model="mock-instant",
            ),
            AIResponse(
                content='{"value": 7}',
                provider="mock",
                model="mock-instant",
            ),
        ]
    )

    result = await parser.parse_with_retry(
        mock_orchestrator, "mock", "Give me a number", schema, max_retries=2
    )
    assert result == {"value": 7}
    assert mock_orchestrator.chat.await_count == 2
