"""Tests for the agent evaluation framework."""

from __future__ import annotations

from agentforge.evaluation import AgentEvaluator, EvalCase, EvalReport, EvalResult


# ---- Helpers ----


def _make_evaluator() -> AgentEvaluator:
    return AgentEvaluator()


def _make_case(**kwargs) -> EvalCase:
    defaults = {
        "input_text": "What is AI?",
        "expected_output": "AI is artificial intelligence",
        "expected_tools": ["search", "summarize"],
        "max_latency_ms": 1000.0,
    }
    defaults.update(kwargs)
    return EvalCase(**defaults)


# ---- Quality Score Tests ----


class TestQualityScore:
    def test_perfect_match(self):
        ev = _make_evaluator()
        case = _make_case(expected_output="hello world")
        result = ev.evaluate_case(
            case, "hello world", ["search", "summarize"], 100, 0.01
        )
        assert result.quality_score == 1.0

    def test_partial_overlap(self):
        ev = _make_evaluator()
        case = _make_case(expected_output="the quick brown fox")
        result = ev.evaluate_case(case, "the slow brown dog", [], 100, 0.01)
        # "the" and "brown" overlap, 4 unique words in each, union is 6
        assert 0.0 < result.quality_score < 1.0

    def test_zero_overlap(self):
        ev = _make_evaluator()
        case = _make_case(expected_output="apple banana cherry")
        result = ev.evaluate_case(case, "dog elephant frog", [], 100, 0.01)
        assert result.quality_score == 0.0

    def test_empty_expected_empty_actual(self):
        ev = _make_evaluator()
        case = _make_case(expected_output="")
        result = ev.evaluate_case(case, "", [], 100, 0.0)
        assert result.quality_score == 1.0

    def test_empty_expected_nonempty_actual(self):
        ev = _make_evaluator()
        case = _make_case(expected_output="")
        result = ev.evaluate_case(case, "something", [], 100, 0.0)
        assert result.quality_score == 0.0

    def test_nonempty_expected_empty_actual(self):
        ev = _make_evaluator()
        case = _make_case(expected_output="something")
        result = ev.evaluate_case(case, "", [], 100, 0.0)
        assert result.quality_score == 0.0

    def test_case_insensitive(self):
        ev = _make_evaluator()
        case = _make_case(expected_output="Hello World")
        result = ev.evaluate_case(case, "hello world", [], 100, 0.0)
        assert result.quality_score == 1.0


# ---- Tool Accuracy Tests ----


class TestToolAccuracy:
    def test_perfect_tool_match(self):
        ev = _make_evaluator()
        case = _make_case(expected_tools=["search", "summarize"])
        result = ev.evaluate_case(case, "AI", ["search", "summarize"], 100, 0.01)
        assert result.tool_accuracy == 1.0

    def test_partial_tool_match(self):
        ev = _make_evaluator()
        case = _make_case(expected_tools=["search", "summarize"])
        result = ev.evaluate_case(case, "AI", ["search", "translate"], 100, 0.01)
        # intersection: {search}, union: {search, summarize, translate} -> 1/3
        assert abs(result.tool_accuracy - round(1 / 3, 4)) < 0.001

    def test_no_tool_overlap(self):
        ev = _make_evaluator()
        case = _make_case(expected_tools=["search"])
        result = ev.evaluate_case(case, "AI", ["translate"], 100, 0.01)
        assert result.tool_accuracy == 0.0

    def test_both_empty_tools(self):
        ev = _make_evaluator()
        case = _make_case(expected_tools=[])
        result = ev.evaluate_case(case, "AI", [], 100, 0.01)
        assert result.tool_accuracy == 1.0

    def test_expected_empty_actual_nonempty(self):
        ev = _make_evaluator()
        case = _make_case(expected_tools=[])
        result = ev.evaluate_case(case, "AI", ["search"], 100, 0.01)
        assert result.tool_accuracy == 0.0


# ---- Pass/Fail Logic ----


class TestPassFail:
    def test_passes_when_all_good(self):
        ev = _make_evaluator()
        case = _make_case(
            expected_output="hello world",
            expected_tools=["search"],
            max_latency_ms=500,
        )
        result = ev.evaluate_case(case, "hello world", ["search"], 200, 0.01)
        assert result.passed is True

    def test_fails_on_low_quality(self):
        ev = _make_evaluator()
        case = _make_case(expected_output="alpha beta gamma")
        result = ev.evaluate_case(case, "x y z", ["search", "summarize"], 100, 0.01)
        assert result.passed is False

    def test_fails_on_high_latency(self):
        ev = _make_evaluator()
        case = _make_case(max_latency_ms=100)
        result = ev.evaluate_case(
            case,
            "AI is artificial intelligence",
            ["search", "summarize"],
            500,
            0.01,
        )
        assert result.passed is False

    def test_fails_on_low_tool_accuracy(self):
        ev = _make_evaluator()
        case = _make_case(expected_tools=["a", "b", "c"])
        result = ev.evaluate_case(
            case, "AI is artificial intelligence", ["x"], 100, 0.01
        )
        assert result.passed is False


# ---- Batch Evaluation ----


class TestBatchEvaluation:
    def test_batch_report_metrics(self):
        ev = _make_evaluator()
        cases = [
            (
                _make_case(expected_output="hello world", case_id="c1"),
                "hello world",
                ["search", "summarize"],
                100,
                0.01,
            ),
            (
                _make_case(expected_output="foo bar", case_id="c2"),
                "foo bar",
                ["search", "summarize"],
                200,
                0.02,
            ),
        ]
        report = ev.evaluate_batch(cases)
        assert len(report.results) == 2
        assert report.mean_quality == 1.0
        assert report.mean_latency == 150.0
        assert report.pass_rate == 1.0

    def test_batch_percentiles(self):
        ev = _make_evaluator()
        cases = [
            (
                _make_case(case_id=f"c{i}"),
                "AI is artificial intelligence",
                ["search", "summarize"],
                latency,
                0.01,
            )
            for i, latency in enumerate(
                [50, 100, 150, 200, 250, 300, 350, 400, 450, 500]
            )
        ]
        report = ev.evaluate_batch(cases)
        assert report.p50_latency == 250  # index 4
        assert report.p95_latency == 450  # index 8
        assert report.p99_latency == 450  # index 8 (int(0.99 * 9))

    def test_batch_empty(self):
        ev = _make_evaluator()
        report = ev.evaluate_batch([])
        assert len(report.results) == 0
        assert report.mean_quality == 0.0
        assert report.pass_rate == 0.0

    def test_batch_single_case(self):
        ev = _make_evaluator()
        cases = [
            (_make_case(expected_output="test", case_id="c1"), "test", [], 100, 0.005),
        ]
        report = ev.evaluate_batch(cases)
        assert len(report.results) == 1
        assert report.p50_latency == 100
        assert report.p95_latency == 100


# ---- Report Comparison ----


class TestReportComparison:
    def test_compare_identical(self):
        report = EvalReport(
            mean_quality=0.8,
            mean_latency=200,
            mean_cost=0.01,
            pass_rate=0.9,
        )
        diff = AgentEvaluator.compare_reports(report, report)
        assert diff["quality_diff"] == 0.0
        assert diff["latency_diff"] == 0.0
        assert diff["cost_diff"] == 0.0
        assert diff["pass_rate_diff"] == 0.0

    def test_compare_improvement(self):
        report_a = EvalReport(
            mean_quality=0.6, mean_latency=300, mean_cost=0.05, pass_rate=0.5
        )
        report_b = EvalReport(
            mean_quality=0.9, mean_latency=100, mean_cost=0.02, pass_rate=0.9
        )
        diff = AgentEvaluator.compare_reports(report_a, report_b)
        assert diff["quality_diff"] > 0
        assert diff["latency_diff"] < 0  # lower is better
        assert diff["cost_diff"] < 0  # lower is better
        assert diff["pass_rate_diff"] > 0

    def test_compare_regression(self):
        report_a = EvalReport(
            mean_quality=0.9, mean_latency=100, mean_cost=0.01, pass_rate=0.95
        )
        report_b = EvalReport(
            mean_quality=0.5, mean_latency=500, mean_cost=0.10, pass_rate=0.3
        )
        diff = AgentEvaluator.compare_reports(report_a, report_b)
        assert diff["quality_diff"] < 0
        assert diff["latency_diff"] > 0
        assert diff["cost_diff"] > 0
        assert diff["pass_rate_diff"] < 0


# ---- Dataclass Tests ----


class TestDataclasses:
    def test_eval_case_defaults(self):
        case = EvalCase(input_text="hi", expected_output="hello")
        assert case.expected_tools == []
        assert case.max_latency_ms == 5000.0
        assert case.metadata == {}
        assert len(case.case_id) == 8

    def test_eval_result_fields(self):
        result = EvalResult(
            case_id="c1",
            quality_score=0.8,
            latency_ms=150,
            cost_usd=0.01,
            tool_accuracy=0.9,
            passed=True,
        )
        assert result.case_id == "c1"
        assert result.passed is True

    def test_eval_report_defaults(self):
        report = EvalReport()
        assert report.results == []
        assert report.mean_quality == 0.0
        assert report.p50_latency == 0.0
