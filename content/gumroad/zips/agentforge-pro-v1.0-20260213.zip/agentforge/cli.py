#!/usr/bin/env python3
"""CLI interface for AgentForge."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from typing import Any

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

from .client import AIOrchestrator

# Approximate cost per 1K tokens (input + output blend) by provider
_COST_PER_1K: dict[str, float] = {
    "claude": 0.008,
    "gemini": 0.002,
    "openai": 0.006,
    "perplexity": 0.003,
    "mock": 0.0,
}


def _parse_args(argv: list[str]) -> argparse.Namespace:
    if len(argv) > 1 and argv[1] == "health":
        parser = argparse.ArgumentParser(description="AgentForge CLI - health checks")
        parser.add_argument(
            "health",
            nargs="?",
            help="Health check subcommand",
        )
        parser.add_argument(
            "--verbose",
            action="store_true",
            help="Enable debug logging",
        )
        parser.add_argument(
            "--format",
            choices=["text", "json"],
            default="text",
            dest="output_format",
            help="Output format (default: text)",
        )
        return parser.parse_args(argv[1:])

    if len(argv) > 1 and argv[1] == "benchmark":
        parser = argparse.ArgumentParser(
            description="AgentForge CLI - provider benchmark"
        )
        parser.add_argument(
            "benchmark",
            nargs="?",
            help="Benchmark subcommand",
        )
        parser.add_argument(
            "--prompt",
            default="Explain the concept of dependency injection in 2-3 sentences.",
            help="Prompt to benchmark across providers",
        )
        parser.add_argument(
            "--verbose",
            action="store_true",
            help="Enable debug logging",
        )
        parser.add_argument(
            "--format",
            choices=["text", "json"],
            default="text",
            dest="output_format",
            help="Output format (default: text)",
        )
        return parser.parse_args(argv[1:])

    parser = argparse.ArgumentParser(
        description="AgentForge CLI - async multi-provider LLM orchestrator"
    )
    parser.add_argument("prompt", help="The prompt to send")
    parser.add_argument(
        "--provider",
        choices=["gemini", "perplexity", "claude", "openai", "mock"],
        default="gemini",
        help="LLM provider (default: gemini)",
    )
    parser.add_argument(
        "--system",
        default="You are a specialized subagent. Provide high-quality, concise output.",
    )
    parser.add_argument(
        "--model", help="Override the default model for the chosen provider"
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.2,
        help="Sampling temperature (default: 0.2)",
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=4096,
        help="Max response tokens (default: 4096)",
    )
    parser.add_argument(
        "--stream",
        action="store_true",
        help="Stream response tokens",
    )
    parser.add_argument(
        "--fallback",
        help="Comma-separated fallback provider list (e.g. claude,openai)",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable debug logging",
    )
    parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        dest="output_format",
        help="Output format: text (default) or json for machine-readable output",
    )
    return parser.parse_args(argv[1:])


async def _run_health(verbose: bool, output_format: str = "text") -> int:
    orchestrator = AIOrchestrator(verbose=verbose)
    results = await orchestrator.health()
    if output_format == "json":
        print(json.dumps(results, indent=2))
    else:
        for provider, ok in results.items():
            status = "ok" if ok else "unavailable"
            print(f"{provider}: {status}")
    return 0


async def _run_benchmark(args: argparse.Namespace) -> int:
    orchestrator = AIOrchestrator(verbose=args.verbose, max_tokens=256)
    providers = list(orchestrator._providers.keys())
    use_json = getattr(args, "output_format", "text") == "json"
    json_results: list[dict[str, Any]] = []

    if not use_json:
        print(f"\nBenchmarking {len(providers)} providers...")
        print(f"Prompt: {args.prompt[:60]}{'...' if len(args.prompt) > 60 else ''}\n")

        # Header
        print(
            f"{'Provider':<14}| {'Model':<28}| {'Time':>7} | {'Tokens':>6} | {'Est. Cost':>9}"
        )
        print(f"{'-' * 14}|{'-' * 29}|{'-' * 9}|{'-' * 8}|{'-' * 10}")

    for name in providers:
        provider = orchestrator._providers[name]
        if not provider.is_configured():
            if use_json:
                json_results.append({"provider": name, "status": "not_configured"})
            else:
                print(
                    f"{name:<14}| {'(not configured)':<28}| {'-':>7} | {'-':>6} | {'-':>9}"
                )
            continue
        try:
            response = await orchestrator.chat(
                provider=name,
                prompt=args.prompt,
                max_tokens=256,
                temperature=0.2,
            )
            tokens = len(response.content.split())
            cost = (tokens / 1000) * _COST_PER_1K.get(name, 0.005)
            if use_json:
                json_results.append(
                    {
                        "provider": name,
                        "status": "ok",
                        "model": response.model,
                        "elapsed_ms": round(response.elapsed_ms, 1),
                        "tokens": tokens,
                        "estimated_cost": round(cost, 6),
                    }
                )
            else:
                elapsed = f"{response.elapsed_ms:.0f}ms"
                print(
                    f"{name:<14}| {response.model:<28}| {elapsed:>7} | {tokens:>6} | ${cost:>8.4f}"
                )
        except Exception as exc:
            if use_json:
                json_results.append(
                    {"provider": name, "status": "error", "error": str(exc)}
                )
            else:
                print(
                    f"{name:<14}| {'error':<28}| {'-':>7} | {'-':>6} | {str(exc)[:20]}"
                )

    if use_json:
        print(json.dumps({"prompt": args.prompt, "results": json_results}, indent=2))
    else:
        print()
    return 0


async def _run_chat(args: argparse.Namespace) -> int:
    fallback_chain = None
    if args.fallback:
        fallback_chain = [p.strip() for p in args.fallback.split(",") if p.strip()]

    use_json = getattr(args, "output_format", "text") == "json"

    orchestrator = AIOrchestrator(
        temperature=args.temperature,
        max_tokens=args.max_tokens,
        fallback_chain=fallback_chain,
        verbose=args.verbose,
    )

    if args.stream:
        if use_json:
            print(
                json.dumps({"error": "--stream and --format json are incompatible"}),
                file=sys.stderr,
            )
            return 1
        try:
            async for chunk in orchestrator.stream(
                provider=args.provider,
                prompt=args.prompt,
                system=args.system,
                model=args.model,
                max_tokens=args.max_tokens,
                temperature=args.temperature,
            ):
                print(chunk, end="", flush=True)
            print("")
            return 0
        except Exception as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1

    try:
        response = await orchestrator.chat(
            provider=args.provider,
            prompt=args.prompt,
            system=args.system,
            model=args.model,
            max_tokens=args.max_tokens,
            temperature=args.temperature,
        )
        if use_json:
            print(
                json.dumps(
                    {
                        "content": response.content,
                        "provider": response.provider,
                        "model": response.model,
                        "elapsed_ms": round(response.elapsed_ms, 1),
                        "metadata": response.metadata,
                    },
                    indent=2,
                )
            )
        else:
            print(response.content)
        return 0
    except Exception as exc:
        if use_json:
            print(json.dumps({"error": str(exc)}), file=sys.stderr)
        else:
            print(f"Error: {exc}", file=sys.stderr)
        return 1


async def _main_async() -> None:
    args = _parse_args(sys.argv)
    if hasattr(args, "health"):
        raise SystemExit(
            await _run_health(args.verbose, getattr(args, "output_format", "text"))
        )
    if hasattr(args, "benchmark"):
        raise SystemExit(await _run_benchmark(args))
    raise SystemExit(await _run_chat(args))


def main() -> None:
    asyncio.run(_main_async())


if __name__ == "__main__":
    main()
