"""Metrics dashboard and message inspector components."""

from __future__ import annotations

from typing import Any

from agentforge.tracing import EventCollector, TraceSpan


class MetricsDashboard:
    """Aggregates and displays trace metrics."""

    def __init__(self, collector: EventCollector) -> None:
        self.collector = collector

    def get_summary(self) -> dict[str, Any]:
        """Get summary metrics across all traces."""
        traces = self.collector.get_all_traces()
        total_events = sum(t.event_count for t in traces)
        total_ms = sum(t.total_ms for t in traces)
        providers: set[str] = set()
        models: set[str] = set()
        for trace in traces:
            for event in trace.events:
                if event.provider:
                    providers.add(event.provider)
                if event.model:
                    models.add(event.model)
        return {
            "total_traces": len(traces),
            "total_events": total_events,
            "total_latency_ms": total_ms,
            "avg_latency_ms": total_ms / max(len(traces), 1),
            "unique_providers": sorted(providers),
            "unique_models": sorted(models),
        }

    def get_trace_table(self) -> list[dict[str, Any]]:
        """Get tabular data for all traces."""
        rows = []
        for trace in self.collector.get_all_traces():
            providers = {e.provider for e in trace.events if e.provider}
            rows.append(
                {
                    "trace_id": trace.trace_id,
                    "events": trace.event_count,
                    "total_ms": trace.total_ms,
                    "providers": sorted(providers),
                }
            )
        return rows


class MessageInspector:
    """Inspect individual messages and events in a trace."""

    def __init__(self, span: TraceSpan) -> None:
        self.span = span

    def get_event_details(self, index: int) -> dict[str, Any] | None:
        """Get detailed info for a specific event by index."""
        if 0 <= index < len(self.span.events):
            event = self.span.events[index]
            return {
                **event.to_dict(),
                "index": index,
                "pct_of_total": (event.elapsed_ms / max(self.span.total_ms, 0.001))
                * 100,
            }
        return None

    def filter_by_type(self, event_type: str) -> list[dict[str, Any]]:
        """Filter events by type."""
        return [e.to_dict() for e in self.span.events if e.event_type == event_type]

    def filter_by_provider(self, provider: str) -> list[dict[str, Any]]:
        """Filter events by provider."""
        return [e.to_dict() for e in self.span.events if e.provider == provider]

    def get_timeline(self) -> list[dict[str, Any]]:
        """Get chronological timeline of events."""
        return [
            {
                "index": i,
                "type": e.event_type,
                "provider": e.provider,
                "ms": e.elapsed_ms,
            }
            for i, e in enumerate(self.span.events)
        ]
