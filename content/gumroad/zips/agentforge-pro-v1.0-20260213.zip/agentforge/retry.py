"""Retry with exponential backoff for transient API failures."""

from __future__ import annotations

import asyncio
import functools
import inspect
import logging
import random
from typing import Any, Callable, Optional, Sequence, Type

logger = logging.getLogger("agentforge.retry")

# Default retryable exception types
RETRYABLE_EXCEPTIONS: tuple[Type[Exception], ...] = (
    TimeoutError,
    ConnectionError,
    OSError,
)


def retry_with_backoff(
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    jitter: bool = True,
    retryable_exceptions: Optional[Sequence[Type[Exception]]] = None,
) -> Callable:
    """Decorator that retries a function with exponential backoff on transient failures.

    Args:
        max_retries: Maximum number of retry attempts (default 3).
        base_delay: Initial delay in seconds before first retry (default 1.0).
        max_delay: Maximum delay cap in seconds (default 60.0).
        jitter: Whether to add random jitter to delay (default True).
        retryable_exceptions: Exception types that trigger a retry. Defaults to
            TimeoutError, ConnectionError, OSError.

    Returns:
        Decorated function that retries on specified exceptions.

    Raises:
        The original exception after all retries are exhausted.
    """
    retry_on = (
        tuple(retryable_exceptions) if retryable_exceptions else RETRYABLE_EXCEPTIONS
    )

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception: Optional[Exception] = None

            for attempt in range(max_retries + 1):
                try:
                    return await func(*args, **kwargs)
                except Exception as exc:
                    if not isinstance(exc, retry_on):
                        raise

                    last_exception = exc

                    if attempt >= max_retries:
                        break

                    delay = min(base_delay * (2**attempt), max_delay)
                    if jitter:
                        delay += random.uniform(0, delay * 0.5)

                    logger.warning(
                        "attempt=%d/%d failed (%s), retrying in %.2fs",
                        attempt + 1,
                        max_retries + 1,
                        type(exc).__name__,
                        delay,
                    )
                    await asyncio.sleep(delay)

            raise last_exception  # type: ignore[misc]

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exception: Optional[Exception] = None

            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as exc:
                    if not isinstance(exc, retry_on):
                        raise

                    last_exception = exc

                    if attempt >= max_retries:
                        break

                    delay = min(base_delay * (2**attempt), max_delay)
                    if jitter:
                        delay += random.uniform(0, delay * 0.5)

                    logger.warning(
                        "attempt=%d/%d failed (%s), retrying in %.2fs",
                        attempt + 1,
                        max_retries + 1,
                        type(exc).__name__,
                        delay,
                    )
                    import time

                    time.sleep(delay)

            raise last_exception  # type: ignore[misc]

        if inspect.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper

    return decorator
