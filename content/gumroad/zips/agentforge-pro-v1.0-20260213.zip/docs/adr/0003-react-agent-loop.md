# ADR 0003: ReAct Agent Loop

## Status
Accepted

## Context
We need autonomous multi-step reasoning with tool use. Simple single-turn LLM calls cannot handle tasks that require gathering information, making decisions, and taking actions across multiple steps. The agent needs to reason about what to do, execute actions, observe results, and iterate until the task is complete.

## Decision
Implement the ReAct (Reasoning + Acting) loop pattern with configurable max iterations, a tool registry, and full observation history. Each iteration produces a structured Thought-Action-Observation triple. The agent reasons about the current state (Thought), selects and invokes a tool (Action), and incorporates the result (Observation) before deciding the next step. A configurable max-iteration guard prevents unbounded execution.

## Consequences
- **Positive**: Enables autonomous multi-step problem-solving. Full reasoning traces provide complete debuggability and auditability. Tool registry allows dynamic capability extension. Structured triples make behavior predictable and testable.
- **Negative**: Unbounded loops risk runaway costs if max-iteration guards are set too high. Each iteration consumes tokens, so complex tasks can be expensive. Requires careful prompt engineering to prevent reasoning loops or premature termination.
