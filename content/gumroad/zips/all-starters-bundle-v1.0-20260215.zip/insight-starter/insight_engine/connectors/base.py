"""Base connector interface for database connections."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterator, Optional


class ConnectorType(str, Enum):
    """Supported database connector types."""

    POSTGRES = "postgres"
    BIGQUERY = "bigquery"
    MYSQL = "mysql"
    SNOWFLAKE = "snowflake"
    REDSHIFT = "redshift"
    SQLITE = "sqlite"


@dataclass
class ConnectionConfig:
    """Configuration for database connection."""

    connector_type: ConnectorType
    host: Optional[str] = None
    port: Optional[int] = None
    database: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    # For cloud databases
    project_id: Optional[str] = None  # BigQuery, Snowflake
    credentials_path: Optional[str] = None  # Service account JSON
    # Connection options
    schema: Optional[str] = None
    timeout: int = 30
    pool_size: int = 5
    extra_params: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert config to dictionary."""
        return {
            "connector_type": self.connector_type.value,
            "host": self.host,
            "port": self.port,
            "database": self.database,
            "username": self.username,
            "password": "***" if self.password else None,
            "project_id": self.project_id,
            "credentials_path": self.credentials_path,
            "schema": self.schema,
            "timeout": self.timeout,
            "pool_size": self.pool_size,
            "extra_params": self.extra_params,
        }


@dataclass
class TableInfo:
    """Information about a database table."""

    name: str
    schema: Optional[str] = None
    row_count: Optional[int] = None
    column_count: Optional[int] = None
    size_mb: Optional[float] = None
    description: Optional[str] = None
    columns: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class QueryResult:
    """Result of a database query."""

    columns: list[str]
    rows: list[tuple[Any, ...]]
    row_count: int
    execution_time_ms: float
    query: str
    error: Optional[str] = None

    def to_dataframe(self) -> "pd.DataFrame":
        """Convert result to pandas DataFrame.

        Returns:
            pandas DataFrame with query results

        Raises:
            ImportError: If pandas is not installed
        """
        import pandas as pd

        return pd.DataFrame(self.rows, columns=self.columns)

    def to_dicts(self) -> list[dict[str, Any]]:
        """Convert result to list of dictionaries.

        Returns:
            List of dictionaries with column names as keys
        """
        return [dict(zip(self.columns, row)) for row in self.rows]


class DataConnector(ABC):
    """Abstract base class for database connectors.

    This class defines the interface for connecting to various databases
    and executing queries. Implementations should handle connection pooling,
    authentication, and error handling.
    """

    def __init__(self, config: ConnectionConfig) -> None:
        """Initialize the connector with configuration.

        Args:
            config: Connection configuration
        """
        self.config = config
        self._connection: Any = None
        self._is_connected: bool = False

    @property
    def is_connected(self) -> bool:
        """Check if the connector is currently connected."""
        return self._is_connected

    @abstractmethod
    def connect(self) -> None:
        """Establish connection to the database.

        Raises:
            ConnectionError: If connection fails
        """
        ...

    @abstractmethod
    def disconnect(self) -> None:
        """Close the database connection."""
        ...

    @abstractmethod
    def test_connection(self) -> bool:
        """Test if the connection is valid.

        Returns:
            True if connection is valid, False otherwise
        """
        ...

    @abstractmethod
    def execute(self, query: str, params: Optional[dict[str, Any]] = None) -> QueryResult:
        """Execute a SQL query and return results.

        Args:
            query: SQL query string
            params: Optional query parameters

        Returns:
            QueryResult with columns, rows, and metadata

        Raises:
            QueryError: If query execution fails
        """
        ...

    @abstractmethod
    def execute_many(self, query: str, params_list: list[dict[str, Any]]) -> int:
        """Execute a query multiple times with different parameters.

        Args:
            query: SQL query string
            params_list: List of parameter dictionaries

        Returns:
            Total number of affected rows

        Raises:
            QueryError: If query execution fails
        """
        ...

    @abstractmethod
    def get_tables(self, schema: Optional[str] = None) -> list[TableInfo]:
        """Get list of tables in the database.

        Args:
            schema: Optional schema name to filter tables

        Returns:
            List of TableInfo objects
        """
        ...

    @abstractmethod
    def get_table_schema(self, table_name: str, schema: Optional[str] = None) -> TableInfo:
        """Get detailed schema information for a table.

        Args:
            table_name: Name of the table
            schema: Optional schema name

        Returns:
            TableInfo with column details
        """
        ...

    @abstractmethod
    def get_table_preview(
        self,
        table_name: str,
        schema: Optional[str] = None,
        limit: int = 100,
    ) -> QueryResult:
        """Get a preview of table data.

        Args:
            table_name: Name of the table
            schema: Optional schema name
            limit: Maximum number of rows to return

        Returns:
            QueryResult with preview data
        """
        ...

    def query_to_dataframe(self, query: str, params: Optional[dict[str, Any]] = None) -> "pd.DataFrame":
        """Execute a query and return results as a pandas DataFrame.

        Args:
            query: SQL query string
            params: Optional query parameters

        Returns:
            pandas DataFrame with query results
        """
        result = self.execute(query, params)
        return result.to_dataframe()

    def stream_query(
        self,
        query: str,
        params: Optional[dict[str, Any]] = None,
        chunk_size: int = 1000,
    ) -> Iterator["pd.DataFrame"]:
        """Stream query results in chunks.

        Args:
            query: SQL query string
            params: Optional query parameters
            chunk_size: Number of rows per chunk

        Yields:
            pandas DataFrame chunks
        """
        # Default implementation - override for database-specific streaming
        result = self.execute(query, params)
        df = result.to_dataframe()

        for i in range(0, len(df), chunk_size):
            yield df.iloc[i : i + chunk_size]

    def __enter__(self) -> "DataConnector":
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit."""
        self.disconnect()

    def __repr__(self) -> str:
        """String representation of the connector."""
        return f"{self.__class__.__name__}(type={self.config.connector_type.value}, database={self.config.database})"


class ConnectorRegistry:
    """Registry for database connectors."""

    _connectors: dict[ConnectorType, type[DataConnector]] = {}

    @classmethod
    def register(cls, connector_type: ConnectorType, connector_class: type[DataConnector]) -> None:
        """Register a connector class for a given type.

        Args:
            connector_type: Type of connector
            connector_class: Connector class to register
        """
        cls._connectors[connector_type] = connector_class

    @classmethod
    def get(cls, connector_type: ConnectorType) -> type[DataConnector]:
        """Get a connector class by type.

        Args:
            connector_type: Type of connector

        Returns:
            Connector class

        Raises:
            ValueError: If connector type is not registered
        """
        if connector_type not in cls._connectors:
            raise ValueError(f"Connector type '{connector_type}' not registered")
        return cls._connectors[connector_type]

    @classmethod
    def create(cls, config: ConnectionConfig) -> DataConnector:
        """Create a connector instance from configuration.

        Args:
            config: Connection configuration

        Returns:
            Connector instance
        """
        connector_class = cls.get(config.connector_type)
        return connector_class(config)

    @classmethod
    def list_connectors(cls) -> list[ConnectorType]:
        """List all registered connector types.

        Returns:
            List of registered connector types
        """
        return list(cls._connectors.keys())
