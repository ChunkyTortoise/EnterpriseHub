"""Pydantic request/response models for the insight-engine API."""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


# ============================================================================
# Profile Endpoint Models
# ============================================================================


class ColumnProfileResponse(BaseModel):
    """Profile for a single column."""

    name: str = Field(..., description="Column name")
    dtype: str = Field(..., description="Detected data type")
    non_null_count: int = Field(..., description="Number of non-null values")
    null_count: int = Field(..., description="Number of null values")
    null_pct: float = Field(..., description="Percentage of null values")
    unique_count: int = Field(..., description="Number of unique values")
    top_values: list[tuple[Any, int]] = Field(default_factory=list, description="Top values with counts")
    mean: Optional[float] = Field(None, description="Mean value for numeric columns")
    median: Optional[float] = Field(None, description="Median value for numeric columns")
    std: Optional[float] = Field(None, description="Standard deviation for numeric columns")
    min_val: Optional[Any] = Field(None, description="Minimum value")
    max_val: Optional[Any] = Field(None, description="Maximum value")
    q25: Optional[float] = Field(None, description="25th percentile for numeric columns")
    q75: Optional[float] = Field(None, description="75th percentile for numeric columns")
    skewness: Optional[float] = Field(None, description="Skewness for numeric columns")
    outlier_count: int = Field(0, description="Number of outliers detected")


class DataQualityScoreResponse(BaseModel):
    """Data quality assessment."""

    overall_score: float = Field(..., description="Overall quality score (0-100)")
    completeness: float = Field(..., description="Average completeness (0-100)")
    uniqueness: float = Field(..., description="Average uniqueness (0-100)")
    validity: float = Field(..., description="Average validity (0-100)")


class ProfileRequest(BaseModel):
    """Request for profiling a dataset."""

    data: list[dict[str, Any]] = Field(..., description="Dataset as list of records")
    include_quality: bool = Field(True, description="Include data quality scoring")


class ProfileResponse(BaseModel):
    """Response from profiling a dataset."""

    row_count: int = Field(..., description="Number of rows")
    column_count: int = Field(..., description="Number of columns")
    columns: list[ColumnProfileResponse] = Field(..., description="Profile for each column")
    duplicate_rows: int = Field(0, description="Number of duplicate rows")
    memory_usage_mb: float = Field(0.0, description="Memory usage in MB")
    quality: Optional[DataQualityScoreResponse] = Field(None, description="Data quality assessment")


# ============================================================================
# Predict Endpoint Models
# ============================================================================


class PredictRequest(BaseModel):
    """Request for training a predictive model."""

    data: list[dict[str, Any]] = Field(..., description="Training dataset as list of records")
    target: str = Field(..., description="Target column name")
    test_size: float = Field(0.2, description="Fraction of data for testing", ge=0.0, le=0.5)
    random_state: int = Field(42, description="Random seed for reproducibility")


class PredictResponse(BaseModel):
    """Response from predictive modeling."""

    task_type: str = Field(..., description="Detected task type: 'classification' or 'regression'")
    target_column: str = Field(..., description="Target column name")
    metrics: dict[str, float] = Field(..., description="Model performance metrics")
    feature_importances: dict[str, float] = Field(..., description="Feature importance scores")
    feature_names: list[str] = Field(default_factory=list, description="Names of features used")


# ============================================================================
# Forecast Endpoint Models
# ============================================================================


class ForecastMethodResult(BaseModel):
    """Result from a single forecasting method."""

    method: str = Field(..., description="Forecasting method name")
    predictions: list[float] = Field(..., description="Forecasted values")
    mae: float = Field(..., description="Mean absolute error")
    rmse: float = Field(..., description="Root mean squared error")
    mape: float = Field(..., description="Mean absolute percentage error")


class ForecastRequest(BaseModel):
    """Request for time series forecasting."""

    data: list[float] = Field(..., description="Time series data points")
    horizon: int = Field(5, description="Number of periods to forecast", ge=1, le=52)
    window: int = Field(3, description="Window size for moving average", ge=1, le=12)
    methods: list[str] = Field(
        default_factory=lambda: ["moving_average", "exponential_smoothing", "linear_trend"],
        description="Forecasting methods to use",
    )


class ForecastResponse(BaseModel):
    """Response from time series forecasting."""

    results: list[ForecastMethodResult] = Field(..., description="Results from each method")
    best_method: str = Field(..., description="Best performing method")
    best_mae: float = Field(..., description="MAE of best method")
    horizon: int = Field(..., description="Forecast horizon used")


# ============================================================================
# Attribution Endpoint Models
# ============================================================================


class Touchpoint(BaseModel):
    """A single marketing touchpoint."""

    user_id: str = Field(..., description="User identifier")
    channel: str = Field(..., description="Marketing channel")
    timestamp: str = Field(..., description="ISO timestamp of touchpoint")


class AttributionRequest(BaseModel):
    """Request for marketing attribution analysis."""

    touchpoints: list[Touchpoint] = Field(..., description="List of marketing touchpoints")
    conversions: list[str] = Field(..., description="List of user IDs who converted")
    model: str = Field(
        "first_touch",
        description="Attribution model: 'first_touch', 'last_touch', 'linear', 'time_decay'",
    )


class ChannelAttribution(BaseModel):
    """Attribution result for a single channel."""

    channel: str = Field(..., description="Channel name")
    conversions: Optional[int] = Field(None, description="Number of attributed conversions")
    credit: Optional[float] = Field(None, description="Credit score")
    credit_pct: float = Field(..., description="Percentage of credit attributed")


class AttributionResponse(BaseModel):
    """Response from attribution analysis."""

    model: str = Field(..., description="Attribution model used")
    channel_credits: dict[str, float] = Field(..., description="Credit percentage by channel")
    total_conversions: int = Field(..., description="Total number of conversions")
    channels: list[ChannelAttribution] = Field(..., description="Detailed attribution by channel")


# ============================================================================
# Error Response Models
# ============================================================================


class ErrorResponse(BaseModel):
    """Standard error response."""

    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    detail: Optional[dict[str, Any]] = Field(None, description="Additional error details")


# ============================================================================
# Health Check Models
# ============================================================================


class HealthResponse(BaseModel):
    """Health check response."""

    status: str = Field(..., description="Service status")
    version: str = Field(..., description="API version")
    timestamp: str = Field(..., description="Current timestamp")
