"""Sphinx configuration for docqa-engine documentation."""

import os
import sys

# Add project root to path for autodoc
sys.path.insert(0, os.path.abspath(".."))

# Project information
project = "docqa-engine"
copyright = "2026, Cayman Roden"
author = "Cayman Roden"
version = "0.1.0"
release = "0.1.0"

# Extensions
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.viewcode",
    "sphinx.ext.napoleon",
    "sphinx.ext.intersphinx",
    "sphinx.ext.githubpages",
]

# Napoleon settings for Google/NumPy style docstrings
napoleon_google_docstring = True
napoleon_numpy_docstring = True
napoleon_include_init_with_doc = True
napoleon_include_private_with_doc = False
napoleon_include_special_with_doc = True

# Autodoc settings
autodoc_default_options = {
    "members": True,
    "member-order": "bysource",
    "special-members": "__init__",
    "undoc-members": True,
    "exclude-members": "__weakref__",
}

# Intersphinx mapping
intersphinx_mapping = {
    "python": ("https://docs.python.org/3", None),
}

# HTML theme
html_theme = "sphinx_rtd_theme"
html_static_path = ["_static"]
html_baseurl = "https://chunkytortoise.github.io/docqa-engine/"

# Output
html_title = "docqa-engine Documentation"
html_short_title = "docqa-engine"

# GitHub Pages
html_extra_path = [".nojekyll"]

# Source suffix
source_suffix = ".rst"
master_doc = "index"

# Language
language = "en"

# Exclude patterns
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]

# Pygments style
pygments_style = "sphinx"

# Todo extension (if needed)
todo_include_todos = True
