Quick Start
===========

Get up and running with docqa-engine in under 5 minutes.

Installation
------------

**From PyPI (recommended):**

.. code-block:: bash

   pip install docqa-engine

**From source:**

.. code-block:: bash

   git clone https://github.com/ChunkyTortoise/docqa-engine.git
   cd docqa-engine
   pip install -e ".[dev]"

Environment Setup
-----------------

Create a ``.env`` file:

.. code-block:: bash

   # Required: LLM API key
   ANTHROPIC_API_KEY=your_key_here
   # Or: OPENAI_API_KEY=your_key_here
   
   # Optional: For embeddings
   HUGGINGFACE_API_TOKEN=your_token_here

Basic Usage
-----------

**Command Line:**

.. code-block:: bash

   # Ingest documents
   docqa ingest ./my_documents/
   
   # Ask a question
   docqa query "What are the main points?"

**Python API:**

.. code-block:: python

   from docqa_engine import DocumentQA, PipelineConfig

   # Initialize with default config
   qa = DocumentQA()
   
   # Or customize the pipeline
   config = PipelineConfig(
       chunk_size=512,
       top_k=5,
       model="claude-3-5-sonnet-20241022"
   )
   qa = DocumentQA(config)
   
   # Ingest documents
   qa.ingest("./documents/")
   
   # Query
   result = qa.query("Summarize the key findings")
   print(result.answer)
   print(result.citations)

**Streamlit Demo:**

.. code-block:: bash

   streamlit run app.py

Next Steps
----------

* Read the :doc:`api` documentation for REST API usage
* Explore :doc:`modules` for detailed Python API reference
* Check ``CUSTOMIZATION.md`` for advanced configuration
* See ``BENCHMARKS.md`` for performance metrics
