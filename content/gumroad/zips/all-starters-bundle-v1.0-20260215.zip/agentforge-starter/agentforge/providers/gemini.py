"""Google Gemini provider."""

from __future__ import annotations

import json
from typing import AsyncGenerator

from ..client_types import AIResponse
from .base import ProviderBase, extract_sse_data


class GeminiProvider(ProviderBase):
    name = "gemini"
    default_model = "gemini-1.5-pro"
    env_key = "GOOGLE_API_KEY"

    async def chat(
        self,
        prompt: str,
        system: str,
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> AIResponse:
        key = self._require_key()
        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{model}:generateContent?key={key}"
        )
        payload = {
            "contents": [{"parts": [{"text": f"{system}\n\n{prompt}"}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        }
        data, elapsed_ms, status_code = await self.orchestrator._request_json(
            self.name, url, payload
        )
        content = data["candidates"][0]["content"]["parts"][0]["text"]
        metadata = {"usage": data.get("usageMetadata"), "status_code": status_code}
        return AIResponse(
            content=content,
            provider=self.name,
            model=model,
            elapsed_ms=elapsed_ms,
            metadata=metadata,
        )

    async def stream(
        self,
        prompt: str,
        system: str,
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> AsyncGenerator[str, None]:
        key = self._require_key()
        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{model}:streamGenerateContent?key={key}"
        )
        payload = {
            "contents": [{"parts": [{"text": f"{system}\n\n{prompt}"}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        }
        async for line in self.orchestrator._stream_lines(self.name, url, payload):
            data_line = extract_sse_data(line)
            if not data_line or data_line == "[DONE]":
                continue
            try:
                data = json.loads(data_line)
            except json.JSONDecodeError:
                continue
            candidates = data.get("candidates") or []
            if not candidates:
                continue
            parts = candidates[0].get("content", {}).get("parts", [])
            if not parts:
                continue
            text = parts[0].get("text")
            if text:
                yield text
