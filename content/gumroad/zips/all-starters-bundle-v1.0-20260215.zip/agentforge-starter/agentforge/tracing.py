"""Event collection and trace dataclasses for AI orchestration observability."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any


@dataclass
class TraceEvent:
    """Single event in an execution trace."""

    timestamp: float = field(default_factory=time.time)
    event_type: str = ""  # e.g. "request", "response", "tool_call", "error"
    provider: str = ""  # e.g. "anthropic", "openai"
    model: str = ""
    elapsed_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize this event to a plain dictionary."""
        return {
            "timestamp": self.timestamp,
            "event_type": self.event_type,
            "provider": self.provider,
            "model": self.model,
            "elapsed_ms": self.elapsed_ms,
            "metadata": self.metadata,
        }


@dataclass
class TraceSpan:
    """A collection of events forming a trace span."""

    trace_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    events: list[TraceEvent] = field(default_factory=list)

    @property
    def total_ms(self) -> float:
        """Sum of elapsed_ms across all events."""
        return sum(e.elapsed_ms for e in self.events)

    @property
    def event_count(self) -> int:
        """Number of events in this span."""
        return len(self.events)

    def to_dict(self) -> dict[str, Any]:
        """Serialize this span to a plain dictionary."""
        return {
            "trace_id": self.trace_id,
            "total_ms": self.total_ms,
            "event_count": self.event_count,
            "events": [e.to_dict() for e in self.events],
        }


class EventCollector:
    """Collects trace events during AI orchestration."""

    def __init__(self) -> None:
        self._spans: dict[str, TraceSpan] = {}
        self._active_span: TraceSpan | None = None

    def start_span(self, trace_id: str | None = None) -> TraceSpan:
        """Start a new trace span, optionally with a given trace_id."""
        span = TraceSpan(trace_id=trace_id or uuid.uuid4().hex[:12])
        self._spans[span.trace_id] = span
        self._active_span = span
        return span

    def collect(self, event: TraceEvent, trace_id: str | None = None) -> None:
        """Add an event to a specific span or the active span."""
        if trace_id and trace_id in self._spans:
            self._spans[trace_id].events.append(event)
        elif self._active_span:
            self._active_span.events.append(event)
        else:
            span = self.start_span()
            span.events.append(event)

    def get_trace(self, trace_id: str) -> TraceSpan | None:
        """Retrieve a span by its trace_id."""
        return self._spans.get(trace_id)

    def get_all_traces(self) -> list[TraceSpan]:
        """Return all collected spans."""
        return list(self._spans.values())

    def clear(self) -> None:
        """Reset all spans and the active span."""
        self._spans.clear()
        self._active_span = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize the full collector state to a dictionary."""
        return {
            "spans": {k: v.to_dict() for k, v in self._spans.items()},
            "total_spans": len(self._spans),
        }
