"""Model registry and versioning for tracking ML model lifecycle."""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("agentforge.model_registry")

# Valid status transitions
_VALID_TRANSITIONS: dict[str, str] = {
    "testing": "active",
    "active": "deprecated",
    "deprecated": "archived",
}


@dataclass
class ModelVersion:
    """A versioned model entry in the registry."""

    name: str
    version: str
    provider: str
    metrics: dict[str, float] = field(default_factory=dict)
    status: str = "testing"  # testing | active | deprecated | archived
    created_at: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ModelComparison:
    """Comparison result across multiple model versions."""

    versions: list[ModelVersion] = field(default_factory=list)
    best_by: dict[str, str] = field(default_factory=dict)  # metric -> "name@version"
    summary: str = ""


class ModelRegistry:
    """Thread-safe registry for model versions with lifecycle management.

    Supports registration, filtering, promotion/deprecation, and comparison.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._models: dict[str, ModelVersion] = {}  # key: "name@version"

    def _key(self, name: str, version: str) -> str:
        return f"{name}@{version}"

    def register(
        self,
        name: str,
        version: str,
        provider: str,
        metrics: dict[str, float] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ModelVersion:
        """Register a new model version.

        Args:
            name: Model name.
            version: Version string.
            provider: Provider name (e.g. "anthropic", "openai").
            metrics: Performance metrics dict.
            metadata: Additional metadata.

        Returns:
            The created ModelVersion.

        Raises:
            ValueError: If the name@version already exists.
        """
        key = self._key(name, version)
        with self._lock:
            if key in self._models:
                raise ValueError(f"Model {key} already registered")
            mv = ModelVersion(
                name=name,
                version=version,
                provider=provider,
                metrics=metrics or {},
                status="testing",
                metadata=metadata or {},
            )
            self._models[key] = mv
            logger.debug("registered model=%s", key)
            return mv

    def get(self, name: str, version: str) -> ModelVersion | None:
        """Get a model version by name and version."""
        with self._lock:
            return self._models.get(self._key(name, version))

    def list_versions(self, name: str) -> list[ModelVersion]:
        """List all versions of a model, sorted by version string."""
        with self._lock:
            versions = [mv for mv in self._models.values() if mv.name == name]
        return sorted(versions, key=lambda mv: mv.version)

    def filter(
        self,
        provider: str | None = None,
        status: str | None = None,
        min_metric: tuple[str, float] | None = None,
    ) -> list[ModelVersion]:
        """Filter models by provider, status, and/or minimum metric value.

        Args:
            provider: Filter by provider name.
            status: Filter by status.
            min_metric: Tuple of (metric_name, threshold) to filter by.

        Returns:
            List of matching ModelVersion objects.
        """
        with self._lock:
            results = list(self._models.values())

        if provider is not None:
            results = [mv for mv in results if mv.provider == provider]
        if status is not None:
            results = [mv for mv in results if mv.status == status]
        if min_metric is not None:
            metric_name, threshold = min_metric
            results = [
                mv for mv in results if mv.metrics.get(metric_name, 0.0) >= threshold
            ]
        return results

    def promote(self, name: str, version: str) -> ModelVersion:
        """Promote a model: testing -> active.

        Raises:
            ValueError: If model not found or invalid transition.
        """
        return self._transition(name, version, "active")

    def deprecate(self, name: str, version: str) -> ModelVersion:
        """Deprecate a model: active -> deprecated.

        Raises:
            ValueError: If model not found or invalid transition.
        """
        return self._transition(name, version, "deprecated")

    def archive(self, name: str, version: str) -> ModelVersion:
        """Archive a model: deprecated -> archived.

        Raises:
            ValueError: If model not found or invalid transition.
        """
        return self._transition(name, version, "archived")

    def _transition(self, name: str, version: str, target_status: str) -> ModelVersion:
        """Transition a model to a new status.

        Raises:
            ValueError: If model not found or transition is invalid.
        """
        key = self._key(name, version)
        with self._lock:
            mv = self._models.get(key)
            if mv is None:
                raise ValueError(f"Model {key} not found")
            expected_from = {v: k for k, v in _VALID_TRANSITIONS.items()}.get(
                target_status
            )
            if mv.status != expected_from:
                raise ValueError(
                    f"Cannot transition {key} from '{mv.status}' to '{target_status}'. "
                    f"Expected current status '{expected_from}'."
                )
            mv.status = target_status
            logger.debug("transitioned model=%s to status=%s", key, target_status)
            return mv

    def get_best(self, metric_name: str) -> ModelVersion | None:
        """Get the active model version with the highest value for a metric.

        Only considers models with status 'active'.
        """
        with self._lock:
            active = [
                mv
                for mv in self._models.values()
                if mv.status == "active" and metric_name in mv.metrics
            ]
        if not active:
            return None
        return max(active, key=lambda mv: mv.metrics[metric_name])

    def get_history(self, name: str) -> list[ModelVersion]:
        """Get all versions of a model sorted by created_at."""
        with self._lock:
            versions = [mv for mv in self._models.values() if mv.name == name]
        return sorted(versions, key=lambda mv: mv.created_at)

    def compare(self, versions: list[tuple[str, str]]) -> ModelComparison:
        """Compare specific model versions across all their metrics.

        Args:
            versions: List of (name, version) tuples to compare.

        Returns:
            ModelComparison with best_by metric mapping and summary.
        """
        found: list[ModelVersion] = []
        with self._lock:
            for name, version in versions:
                mv = self._models.get(self._key(name, version))
                if mv is not None:
                    found.append(mv)

        if not found:
            return ModelComparison(summary="No versions found.")

        # Collect all metric names
        all_metrics: set[str] = set()
        for mv in found:
            all_metrics.update(mv.metrics.keys())

        # Find best for each metric
        best_by: dict[str, str] = {}
        for metric in sorted(all_metrics):
            candidates = [mv for mv in found if metric in mv.metrics]
            if candidates:
                best = max(candidates, key=lambda mv: mv.metrics[metric])
                best_by[metric] = f"{best.name}@{best.version}"

        summary_parts = [f"{metric}: {winner}" for metric, winner in best_by.items()]
        summary = (
            "Best by metric: " + ", ".join(summary_parts)
            if summary_parts
            else "No metrics to compare."
        )

        return ModelComparison(
            versions=found,
            best_by=best_by,
            summary=summary,
        )
