"""Flow diagram component for visualizing AI orchestration traces."""

from __future__ import annotations

from agentforge.tracing import TraceEvent, TraceSpan


class FlowDiagram:
    """Generates flow diagram representations from trace data."""

    def __init__(self, span: TraceSpan) -> None:
        self.span = span

    def to_mermaid(self) -> str:
        """Generate Mermaid LR flow diagram."""
        lines = ["graph LR"]
        for i, event in enumerate(self.span.events):
            node_id = f"E{i}"
            label = f"{event.event_type}\\n{event.provider}\\n{event.model}"
            lines.append(f'    {node_id}["{label}"]')
            if i > 0:
                prev_id = f"E{i - 1}"
                lines.append(f"    {prev_id} --> {node_id}")
        return "\n".join(lines)

    def to_graphviz_dot(self) -> str:
        """Generate Graphviz DOT notation."""
        lines = [
            "digraph trace {",
            "    rankdir=LR;",
            "    node [shape=box, style=rounded];",
        ]
        for i, event in enumerate(self.span.events):
            label = f"{event.event_type}\\n{event.provider} ({event.elapsed_ms:.0f}ms)"
            lines.append(f'    E{i} [label="{label}"];')
        for i in range(1, len(self.span.events)):
            lines.append(f"    E{i - 1} -> E{i};")
        lines.append("}")
        return "\n".join(lines)

    def get_provider_groups(self) -> dict[str, list[TraceEvent]]:
        """Group events by provider."""
        groups: dict[str, list[TraceEvent]] = {}
        for event in self.span.events:
            if event.provider not in groups:
                groups[event.provider] = []
            groups[event.provider].append(event)
        return groups

    def get_latency_breakdown(self) -> dict[str, float]:
        """Get per-provider latency totals."""
        breakdown: dict[str, float] = {}
        for event in self.span.events:
            breakdown[event.provider] = (
                breakdown.get(event.provider, 0.0) + event.elapsed_ms
            )
        return breakdown
