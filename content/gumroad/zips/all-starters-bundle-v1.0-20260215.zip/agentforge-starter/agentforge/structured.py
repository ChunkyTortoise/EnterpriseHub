"""Structured output support — validate LLM responses against JSON schemas."""

from __future__ import annotations

import json
import logging
import re
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from .client import AIOrchestrator

logger = logging.getLogger("agentforge.structured")


class SchemaValidationError(Exception):
    """Raised when a response does not match the expected JSON schema."""

    def __init__(self, message: str, errors: Optional[list[str]] = None):
        self.errors = errors or []
        super().__init__(message)


class StructuredOutput:
    """Extract and validate JSON from LLM responses.

    Handles common LLM output patterns:
    - Raw JSON strings
    - JSON wrapped in markdown code blocks (```json ... ```)
    - JSON embedded in surrounding text

    Validates extracted JSON against a simple dict-based schema without
    requiring external dependencies like jsonschema.

    Usage:
        parser = StructuredOutput()
        schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
            "required": ["name", "age"],
        }
        result = parser.parse('{"name": "Alice", "age": 30}', schema)
    """

    # Pattern to extract JSON from markdown code blocks
    _CODE_BLOCK_PATTERN = re.compile(
        r"```(?:json)?\s*\n?(.*?)\n?\s*```",
        re.DOTALL,
    )

    # Pattern to find JSON objects/arrays in text
    _JSON_OBJECT_PATTERN = re.compile(r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", re.DOTALL)
    _JSON_ARRAY_PATTERN = re.compile(
        r"\[[^\[\]]*(?:\[[^\[\]]*\][^\[\]]*)*\]", re.DOTALL
    )

    def extract_json(self, text: str) -> Any:
        """Extract JSON from text, handling markdown code blocks.

        Args:
            text: Raw LLM response text.

        Returns:
            Parsed JSON value.

        Raises:
            ValueError: If no valid JSON can be extracted.
        """
        # 1. Try parsing the entire text as JSON
        stripped = text.strip()
        try:
            return json.loads(stripped)
        except (json.JSONDecodeError, ValueError):
            pass

        # 2. Try extracting from markdown code blocks
        code_blocks = self._CODE_BLOCK_PATTERN.findall(text)
        for block in code_blocks:
            try:
                return json.loads(block.strip())
            except (json.JSONDecodeError, ValueError):
                continue

        # 3. Try finding JSON objects in the text
        for pattern in (self._JSON_OBJECT_PATTERN, self._JSON_ARRAY_PATTERN):
            matches = pattern.findall(text)
            for match in matches:
                try:
                    return json.loads(match)
                except (json.JSONDecodeError, ValueError):
                    continue

        raise ValueError(f"No valid JSON found in response: {text[:200]}...")

    def validate(self, data: Any, schema: dict) -> list[str]:
        """Validate data against a JSON schema (subset implementation).

        Supports:
        - type checking (string, integer, number, boolean, array, object, null)
        - required fields
        - properties (recursive)
        - items (array element schema)
        - enum
        - minimum / maximum (for numbers)
        - minLength / maxLength (for strings)
        - minItems / maxItems (for arrays)

        Args:
            data: The parsed JSON data to validate.
            schema: A JSON Schema-like dict.

        Returns:
            List of validation error strings (empty if valid).
        """
        errors: list[str] = []
        self._validate_node(data, schema, path="$", errors=errors)
        return errors

    def _validate_node(
        self, data: Any, schema: dict, path: str, errors: list[str]
    ) -> None:
        """Recursively validate a data node against its schema."""
        # Type check
        if "type" in schema:
            expected_type = schema["type"]
            if not self._check_type(data, expected_type):
                errors.append(
                    f"{path}: expected type '{expected_type}', "
                    f"got '{type(data).__name__}'"
                )
                return  # Skip deeper validation if type doesn't match

        # Enum check
        if "enum" in schema:
            if data not in schema["enum"]:
                errors.append(f"{path}: value {data!r} not in enum {schema['enum']}")

        # Number constraints
        if isinstance(data, (int, float)) and not isinstance(data, bool):
            if "minimum" in schema and data < schema["minimum"]:
                errors.append(f"{path}: {data} < minimum {schema['minimum']}")
            if "maximum" in schema and data > schema["maximum"]:
                errors.append(f"{path}: {data} > maximum {schema['maximum']}")

        # String constraints
        if isinstance(data, str):
            if "minLength" in schema and len(data) < schema["minLength"]:
                errors.append(
                    f"{path}: string length {len(data)} < minLength {schema['minLength']}"
                )
            if "maxLength" in schema and len(data) > schema["maxLength"]:
                errors.append(
                    f"{path}: string length {len(data)} > maxLength {schema['maxLength']}"
                )

        # Object validation
        if isinstance(data, dict):
            # Required fields
            for req_field in schema.get("required", []):
                if req_field not in data:
                    errors.append(f"{path}: missing required field '{req_field}'")

            # Property validation
            properties = schema.get("properties", {})
            for key, value in data.items():
                if key in properties:
                    self._validate_node(
                        value, properties[key], path=f"{path}.{key}", errors=errors
                    )

        # Array validation
        if isinstance(data, list):
            if "minItems" in schema and len(data) < schema["minItems"]:
                errors.append(
                    f"{path}: array length {len(data)} < minItems {schema['minItems']}"
                )
            if "maxItems" in schema and len(data) > schema["maxItems"]:
                errors.append(
                    f"{path}: array length {len(data)} > maxItems {schema['maxItems']}"
                )
            if "items" in schema:
                for i, item in enumerate(data):
                    self._validate_node(
                        item, schema["items"], path=f"{path}[{i}]", errors=errors
                    )

    def _check_type(self, data: Any, expected: str) -> bool:
        """Check if data matches the expected JSON Schema type."""
        type_map = {
            "string": str,
            "integer": int,
            "number": (int, float),
            "boolean": bool,
            "array": list,
            "object": dict,
            "null": type(None),
        }
        if expected not in type_map:
            return True  # Unknown type, skip check

        expected_types = type_map[expected]

        # Special handling: booleans are ints in Python, so exclude them from int/number
        if expected in ("integer", "number") and isinstance(data, bool):
            return False

        if isinstance(expected_types, tuple):
            return isinstance(data, expected_types)
        return isinstance(data, expected_types)

    def parse(self, response_text: str, schema: dict) -> Any:
        """Extract JSON from response text and validate against schema.

        Args:
            response_text: Raw LLM response.
            schema: JSON Schema dict to validate against.

        Returns:
            Parsed and validated JSON data.

        Raises:
            ValueError: If no valid JSON can be extracted.
            SchemaValidationError: If extracted JSON does not match schema.
        """
        data = self.extract_json(response_text)
        errors = self.validate(data, schema)
        if errors:
            raise SchemaValidationError(
                f"Schema validation failed with {len(errors)} error(s): "
                + "; ".join(errors),
                errors=errors,
            )
        return data

    async def parse_with_retry(
        self,
        orchestrator: AIOrchestrator,
        provider: str,
        prompt: str,
        schema: dict,
        max_retries: int = 2,
        system: str = "You are a helpful assistant that responds in valid JSON.",
        model: Optional[str] = None,
    ) -> Any:
        """Parse structured output with automatic retry on failure.

        If the initial response cannot be parsed or fails validation,
        re-prompts the LLM with a corrected instruction up to max_retries times.

        Args:
            orchestrator: AIOrchestrator instance.
            provider: LLM provider name.
            prompt: The original prompt.
            schema: JSON Schema dict to validate against.
            max_retries: Number of retry attempts on parse/validation failure.
            system: System prompt (default asks for JSON).
            model: Optional model override.

        Returns:
            Parsed and validated JSON data.

        Raises:
            ValueError: If no valid JSON can be extracted after all retries.
            SchemaValidationError: If validation fails after all retries.
        """
        last_error: Optional[Exception] = None
        schema_description = json.dumps(schema, indent=2)

        for attempt in range(max_retries + 1):
            if attempt == 0:
                current_prompt = (
                    f"{prompt}\n\nRespond with valid JSON matching this schema:\n"
                    f"```json\n{schema_description}\n```"
                )
            else:
                error_msg = str(last_error)
                current_prompt = (
                    f"Your previous response was not valid JSON or did not match "
                    f"the required schema. Error: {error_msg}\n\n"
                    f"Please respond with ONLY valid JSON (no markdown, no explanation) "
                    f"matching this schema:\n"
                    f"```json\n{schema_description}\n```\n\n"
                    f"Original request: {prompt}"
                )

            try:
                response = await orchestrator.chat(
                    provider, current_prompt, system=system, model=model
                )
                return self.parse(response.content, schema)
            except (ValueError, SchemaValidationError) as exc:
                last_error = exc
                logger.warning(
                    "attempt=%d/%d parse failed: %s",
                    attempt + 1,
                    max_retries + 1,
                    exc,
                )

        raise last_error  # type: ignore[misc]
