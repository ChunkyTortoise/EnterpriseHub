# AgentForge vs LangChain Comparison

**Why AgentForge exists when LangChain is available.**

---

## Quick Summary

| Aspect | AgentForge | LangChain |
|--------|------------|-----------|
| **Architecture** | Mesh topology with governance | Chain-of-thought pipelines |
| **Agent Count** | 22 specialized agents | 1-3 general agents typical |
| **Handoff** | Native cross-agent orchestration | Manual chain construction |
| **Benchmarks** | 89% cost reduction validated | Variable by implementation |
| **Learning Curve** | Low (convention over config) | Moderate-High |
| **Token Cost** | Optimized (3-tier caching) | Raw API calls |
| **Setup Time** | `pip install` + 5 min config | 2-4 hours typical |
| **Core Dependencies** | 5 dependencies | 50+ dependencies |
| **Bundle Size** | ~2MB | ~150MB+ |

---

## Dependency Count Comparison

### AgentForge Dependencies (5 core)

```
httpx>=0.27.0
python-dotenv>=1.0.0
streamlit>=1.30.0
fastapi>=0.110.0
pydantic>=2.0.0
```

**Total transitive dependencies:** ~15 packages

### LangChain Dependencies (50+ core)

```
langchain-core
langchain-community
langchain-openai
langchain-anthropic
langchain-text-splitters
langchainhub
...plus 40+ community integrations
```

**Total transitive dependencies:** 200+ packages

### Why This Matters

| Impact | AgentForge | LangChain |
|--------|------------|-----------|
| **Docker image size** | ~200MB | ~1.5GB+ |
| **Cold start time** | <1s | 3-5s |
| **Security surface** | Minimal | Large |
| **CI/CD speed** | Fast | Slow |
| **Conflict risk** | Low | High |

---

## API Simplicity Comparison

### Basic Agent Creation

**AgentForge (3 lines):**
```python
from agentforge import Agent

agent = Agent("my-agent", provider="openai")
response = agent.run("Hello, world!")
```

**LangChain (8+ lines):**
```python
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

llm = ChatOpenAI(model="gpt-4")
prompt = ChatPromptTemplate.from_template("{input}")
parser = StrOutputParser()
chain = prompt | llm | parser
response = chain.invoke({"input": "Hello, world!"})
```

### Multi-Agent Orchestration

**AgentForge (5 lines):**
```python
from agentforge import AgentMesh

mesh = AgentMesh()
mesh.register("lead", lead_agent)
mesh.register("buyer", buyer_agent)
result = mesh.process("I want to buy", entry_point="lead")
```

**LangChain (30+ lines):**
```python
from langchain.agents import AgentExecutor, create_openai_functions_agent
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

# Define tools for routing
tools = [route_to_buyer, route_to_seller]

# Create each agent manually
llm = ChatOpenAI(model="gpt-4", temperature=0)
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant."),
    ("human", "{input}"),
    MessagesPlaceholder(variable_name="agent_scratchpad"),
])

agent = create_openai_functions_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools)

# Manual routing logic
def route_query(query):
    # Implement custom routing...
    pass

result = executor.invoke({"input": "I want to buy"})
```

### Cost Tracking

**AgentForge (built-in, 2 lines):**
```python
from agentforge import CostTracker
tracker = CostTracker()  # Automatic tracking enabled
```

**LangChain (manual wrapping):**
```python
from langchain.callbacks import get_openai_callback

with get_openai_callback() as cb:
    response = chain.invoke({"input": "query"})
    print(f"Cost: ${cb.total_cost}")
    # Must repeat for every call...
```

---

## When to Choose AgentForge

**Choose AgentForge when you need:**

- **Multi-agent orchestration** — 3+ agents working together with handoffs
- **Cost optimization** — Production workloads where token costs matter
- **Real-time systems** — Sub-second response requirements
- **Proven patterns** — Battle-tested workflows for common use cases
- **Fast deployment** — Production-ready in hours, not weeks

**Example use cases:**
- Real estate lead qualification (Lead → Buyer → Seller handoffs)
- Document processing pipelines (Ingest → Chunk → Embed → Query)
- Customer support triage (Intent → Queue → Resolution)

---

## When to Choose LangChain

**Choose LangChain when you need:**

- **Maximum flexibility** — Custom chains with exotic components
- **Research/experimentation** — Prototyping novel AI patterns
- **Specific integrations** — Niche vector stores or models
- **Full control** — Every component configurable

**Example use cases:**
- Academic research on LLM chains
- Custom RAG with non-standard components
- Novel agent architectures

---

## Architecture Comparison

### AgentForge: Mesh Topology

```
┌─────────────────────────────────────────┐
│         AgentForge Mesh                 │
│                                         │
│   ┌─────────┐    ┌─────────┐           │
│   │  Agent  │◄──►│  Agent  │           │
│   │    A    │    │    B    │           │
│   └────┬────┘    └────┬────┘           │
│        │              │                 │
│        ▼              ▼                 │
│   ┌─────────────────────────┐          │
│   │    Governance Layer     │          │
│   │  (Routing, Caching,     │          │
│   │   Cost Tracking)        │          │
│   └─────────────────────────┘          │
│        │                                │
│        ▼                                │
│   ┌─────────┐                          │
│   │  Agent  │                          │
│   │    C    │                          │
│   └─────────┘                          │
└─────────────────────────────────────────┘
```

**Key features:**
- Agents communicate through governance layer
- Automatic handoff detection
- Shared context across agents
- Circuit breakers prevent runaway costs

### LangChain: Chain Topology

```
┌─────────────────────────────────────────┐
│         LangChain Pipeline              │
│                                         │
│   Input ──► [Prompt] ──► [LLM] ──►     │
│                  │                      │
│                  ▼                      │
│            [Output Parser]              │
│                  │                      │
│                  ▼                      │
│            [Tool/API]                  │
│                  │                      │
│                  ▼                      │
│               Output                    │
└─────────────────────────────────────────┘
```

**Key features:**
- Linear data flow
- Explicit component wiring
- Highly customizable
- Rich ecosystem of integrations

---

## Performance Benchmarks

### Token Cost (per 1000 requests)

| Scenario | AgentForge | LangChain* | Savings |
|----------|-----------|------------|---------|
| Simple Q&A | 7.8K tokens | 93K tokens | **89%** |
| Multi-step workflow | 12K tokens | 145K tokens | **92%** |
| Document RAG | 15K tokens | 89K tokens | **83%** |

*LangChain figures based on default chain configurations without optimization

### Response Latency (P95)

| Operation | AgentForge | LangChain |
|-----------|-----------|-----------|
| Cache hit (L1/L2) | 50ms | N/A |
| Cache hit (L3) | 200ms | N/A |
| Fresh API call | 800ms | 800-1200ms |
| Multi-agent handoff | 150ms overhead | 400-600ms |

---

## Code Comparison

### Multi-Agent Handoff

**AgentForge (5 lines):**

```python
from agentforge import AgentMesh

mesh = AgentMesh()
mesh.register("lead_bot", lead_agent)
mesh.register("buyer_bot", buyer_agent)

# Automatic handoff based on intent
result = mesh.process("I'm looking to buy a home", 
                      entry_point="lead_bot")
```

**LangChain equivalent (25+ lines):**

```python
from langchain.agents import AgentExecutor
from langchain_core.runnables import RunnablePassthrough

# Manual chain construction
lead_chain = lead_prompt | lead_llm | lead_parser
handoff_detector = intent_classifier | router_logic

# Wiring components
def handoff_chain(input):
    result = lead_chain.invoke(input)
    if handoff_detector.invoke(result) == "buyer":
        return buyer_chain.invoke(result)
    return result

executor = AgentExecutor(agent=..., tools=[...])
```

### Cost Tracking

**AgentForge (built-in):**

```python
from agentforge import CostTracker

tracker = CostTracker()
tracker.enable()  # All calls tracked automatically

report = tracker.report()
print(f"Total cost: ${report.total_cost:.2f}")
print(f"Cache hit rate: {report.cache_hit_rate}%")
```

**LangChain (manual implementation):**

```python
from langchain.callbacks import get_openai_callback

# Must wrap every call manually
costs = []
with get_openai_callback() as cb:
    result = chain.invoke(input)
    costs.append(cb.total_cost)

# Aggregate manually
total = sum(costs)
```

---

## Feature Matrix

| Feature | AgentForge | LangChain |
|---------|-----------|-----------|
| Multi-agent orchestration | ✅ Native | ⚠️ Complex |
| Cost optimization | ✅ Built-in | ❌ Manual |
| Response caching | ✅ 3-tier (L1/L2/L3) | ❌ External |
| Handoff detection | ✅ Automatic | ❌ Manual |
| Circuit breakers | ✅ Built-in | ❌ Custom code |
| Benchmark suite | ✅ Included | ❌ External |
| Token compression | ✅ Context optimizer | ❌ Manual |
| Streaming responses | ✅ Native | ✅ Native |
| Tool integration | ✅ 50+ tools | ✅ 100+ tools |
| Vector stores | ✅ 5+ backends | ✅ 20+ backends |
| Custom agents | ✅ Template-based | ✅ Flexible |
| Async/await | ✅ First-class | ✅ Supported |

---

## Migration Path

### From LangChain to AgentForge

```python
# Step 1: Wrap existing LangChain components
from agentforge.adapters import LangChainAdapter

adapter = LangChainAdapter()
my_chain = adapter.wrap(langchain_chain)

# Step 2: Register in mesh
mesh.register("my_chain", my_chain)

# Step 3: Enable cost tracking
mesh.enable_cost_tracking()
```

### Hybrid Approach

```python
# Use LangChain for specific integrations
from langchain_community.tools import SomeTool

# Use AgentForge for orchestration
from agentforge import AgentMesh

mesh = AgentMesh()
mesh.register_tool("special_tool", SomeTool())
```

---

## Bottom Line

**AgentForge wins when:**
- You need production multi-agent systems quickly
- Cost optimization is a priority
- You want convention over configuration
- You're building on proven patterns

**LangChain wins when:**
- You need maximum architectural flexibility
- You're researching novel patterns
- You need specific niche integrations
- You have time to build custom optimizations

---

## FAQ

**Q: Can I use both?**
A: Yes. AgentForge can wrap LangChain components via adapters.

**Q: Is AgentForge just LangChain with caching?**
A: No. It's a fundamentally different architecture (mesh vs chain) with governance, handoffs, and cost optimization as core features.

**Q: What about LlamaIndex?**
A: LlamaIndex specializes in RAG. AgentForge's RAG is competitive but the real difference is multi-agent orchestration.

**Q: Enterprise support?**
A: AgentForge offers consulting packages. LangChain has commercial offerings through LangChain Inc.

---

## See Also

- [BENCHMARKS.md](./BENCHMARKS.md) — Detailed performance comparisons
- [ROI.md](./ROI.md) — Cost savings analysis
- [AGENT_SPEC.md](./AGENT_SPEC.md) — Agent architecture details
