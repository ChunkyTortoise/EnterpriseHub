"""Tests for CLI --format json output."""

import json
from unittest.mock import AsyncMock, patch

import pytest

from agentforge import AIResponse
from agentforge.cli import _parse_args, _run_chat, _run_health

# ── Argument Parsing ─────────────────────────────────────────────────────────


class TestParseArgsFormat:
    def test_default_format_is_text(self):
        args = _parse_args(["prog", "hello"])
        assert args.output_format == "text"

    def test_format_json(self):
        args = _parse_args(["prog", "hello", "--format", "json"])
        assert args.output_format == "json"

    def test_format_text_explicit(self):
        args = _parse_args(["prog", "hello", "--format", "text"])
        assert args.output_format == "text"

    def test_health_format_json(self):
        args = _parse_args(["prog", "health", "--format", "json"])
        assert args.output_format == "json"

    def test_benchmark_format_json(self):
        args = _parse_args(["prog", "benchmark", "--format", "json"])
        assert args.output_format == "json"


# ── JSON Output ──────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_chat_json_output(capsys):
    """--format json produces valid JSON with expected fields."""
    mock_response = AIResponse(
        content="Hello world",
        provider="mock",
        model="mock-v1",
        elapsed_ms=42.5,
        metadata={"test": True},
    )
    args = _parse_args(
        ["prog", "test prompt", "--provider", "mock", "--format", "json"]
    )

    with patch(
        "agentforge.cli.AIOrchestrator.chat",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        code = await _run_chat(args)

    assert code == 0
    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["content"] == "Hello world"
    assert data["provider"] == "mock"
    assert data["model"] == "mock-v1"
    assert data["elapsed_ms"] == 42.5
    assert data["metadata"] == {"test": True}


@pytest.mark.asyncio
async def test_chat_text_output_unchanged(capsys):
    """Default text format still prints plain content."""
    mock_response = AIResponse(
        content="Hello world",
        provider="mock",
        model="mock-v1",
    )
    args = _parse_args(["prog", "test prompt", "--provider", "mock"])

    with patch(
        "agentforge.cli.AIOrchestrator.chat",
        new_callable=AsyncMock,
        return_value=mock_response,
    ):
        code = await _run_chat(args)

    assert code == 0
    captured = capsys.readouterr()
    assert captured.out.strip() == "Hello world"


@pytest.mark.asyncio
async def test_chat_json_error(capsys):
    """--format json outputs error as JSON on failure."""
    args = _parse_args(["prog", "test", "--provider", "mock", "--format", "json"])

    with patch(
        "agentforge.cli.AIOrchestrator.chat",
        new_callable=AsyncMock,
        side_effect=RuntimeError("provider failed"),
    ):
        code = await _run_chat(args)

    assert code == 1
    captured = capsys.readouterr()
    data = json.loads(captured.err)
    assert "provider failed" in data["error"]


@pytest.mark.asyncio
async def test_health_json_output(capsys):
    """health --format json produces valid JSON."""
    mock_results = {"gemini": False, "mock": True, "claude": False}

    with patch(
        "agentforge.cli.AIOrchestrator.health",
        new_callable=AsyncMock,
        return_value=mock_results,
    ):
        code = await _run_health(verbose=False, output_format="json")

    assert code == 0
    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["mock"] is True
    assert data["gemini"] is False


@pytest.mark.asyncio
async def test_stream_json_incompatible(capsys):
    """--stream and --format json returns error."""
    args = _parse_args(
        ["prog", "test", "--provider", "mock", "--format", "json", "--stream"]
    )
    code = await _run_chat(args)
    assert code == 1
    captured = capsys.readouterr()
    data = json.loads(captured.err)
    assert "incompatible" in data["error"]
