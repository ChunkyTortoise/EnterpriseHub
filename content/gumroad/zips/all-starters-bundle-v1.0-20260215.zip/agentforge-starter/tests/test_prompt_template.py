"""Tests for PromptTemplate and PromptRegistry."""

import pytest

from agentforge.prompt_template import PromptRegistry, PromptTemplate

# ── PromptTemplate ─────────────────────────────────────────────────────────


class TestPromptTemplate:
    def test_variable_extraction(self) -> None:
        """Extracts {{var}} names from template."""
        tpl = PromptTemplate(
            name="test",
            template="Hello {{name}}, welcome to {{city}}!",
        )
        assert tpl.variables == ["city", "name"]

    def test_render(self) -> None:
        """Renders with provided values."""
        tpl = PromptTemplate(
            name="test",
            template="Hello {{name}}, you are {{age}} years old.",
        )
        result = tpl.render(name="Alice", age="30")
        assert result == "Hello Alice, you are 30 years old."

    def test_render_missing_var(self) -> None:
        """Raises ValueError when required variable is missing."""
        tpl = PromptTemplate(
            name="test",
            template="Hello {{name}}!",
        )
        with pytest.raises(ValueError, match="Missing variables"):
            tpl.render()

    def test_partial(self) -> None:
        """Creates new template with some variables filled in."""
        tpl = PromptTemplate(
            name="test",
            template="{{greeting}}, {{name}}!",
        )
        partial = tpl.partial(greeting="Hi")
        assert "{{name}}" in partial.template
        assert "Hi" in partial.template
        assert "{{greeting}}" not in partial.template
        assert partial.name == "test_partial"
        # Remaining variable should be extracted
        assert partial.variables == ["name"]

    def test_no_variables(self) -> None:
        """Template without variables renders as-is."""
        tpl = PromptTemplate(
            name="static",
            template="No variables here.",
        )
        assert tpl.variables == []
        assert tpl.render() == "No variables here."

    def test_duplicate_variables(self) -> None:
        """Duplicate variable references are deduplicated."""
        tpl = PromptTemplate(
            name="test",
            template="{{x}} and {{x}} and {{y}}",
        )
        assert tpl.variables == ["x", "y"]


# ── PromptRegistry ─────────────────────────────────────────────────────────


class TestPromptRegistry:
    def test_builtin_count(self) -> None:
        """5 built-in templates are registered."""
        registry = PromptRegistry()
        assert len(registry.list_templates()) == 5

    def test_get_classify(self) -> None:
        """Classify template exists and has correct variables."""
        registry = PromptRegistry()
        tpl = registry.get("classify")
        assert tpl is not None
        assert "categories" in tpl.variables
        assert "text" in tpl.variables

    def test_get_nonexistent(self) -> None:
        """Returns None for unregistered template."""
        registry = PromptRegistry()
        assert registry.get("nonexistent") is None

    def test_register_custom(self) -> None:
        """Custom template added to registry."""
        registry = PromptRegistry()
        custom = PromptTemplate(
            name="custom",
            template="Translate {{text}} to {{language}}",
            description="Translation",
        )
        registry.register(custom)
        assert registry.get("custom") is not None
        assert len(registry.list_templates()) == 6

    def test_render_qa(self) -> None:
        """Renders qa template successfully."""
        registry = PromptRegistry()
        result = registry.render(
            "qa",
            context="The sky is blue.",
            question="What color is the sky?",
        )
        assert "The sky is blue." in result
        assert "What color is the sky?" in result

    def test_render_nonexistent(self) -> None:
        """Raises KeyError for nonexistent template."""
        registry = PromptRegistry()
        with pytest.raises(KeyError, match="Template not found"):
            registry.render("nonexistent")


# ── Extended: Variable Rendering ──────────────────────────────────────────


class TestExtendedRendering:
    def test_render_coerces_int_to_str(self) -> None:
        """render() converts non-string values via str()."""
        tpl = PromptTemplate(
            name="test",
            template="Count: {{n}}",
        )
        result = tpl.render(n=42)
        assert result == "Count: 42"

    def test_render_coerces_float(self) -> None:
        """render() converts float to string."""
        tpl = PromptTemplate(
            name="test",
            template="Price: {{price}}",
        )
        result = tpl.render(price=9.99)
        assert result == "Price: 9.99"

    def test_render_coerces_bool(self) -> None:
        """render() converts bool to string."""
        tpl = PromptTemplate(
            name="test",
            template="Active: {{active}}",
        )
        result = tpl.render(active=True)
        assert result == "Active: True"

    def test_adjacent_variables(self) -> None:
        """Variables placed right next to each other render correctly."""
        tpl = PromptTemplate(
            name="test",
            template="{{first}}{{last}}",
        )
        result = tpl.render(first="John", last="Doe")
        assert result == "JohnDoe"

    def test_extra_kwargs_ignored(self) -> None:
        """Extra keyword arguments not in template are silently ignored."""
        tpl = PromptTemplate(
            name="test",
            template="Hello {{name}}!",
        )
        # "extra" is not a template variable but should not cause error
        result = tpl.render(name="Alice", extra="ignored")
        assert result == "Hello Alice!"

    def test_large_template(self) -> None:
        """Renders a large template without issue."""
        body = "Line {{n}}\n" * 500
        tpl = PromptTemplate(name="large", template=body)
        assert "n" in tpl.variables
        result = tpl.render(n="X")
        assert result.count("Line X") == 500


# ── Extended: Partial Composition ─────────────────────────────────────────


class TestExtendedPartial:
    def test_partial_then_render(self) -> None:
        """Partial fills some vars, render fills the rest."""
        tpl = PromptTemplate(
            name="test",
            template="{{greeting}}, {{name}}! Welcome to {{place}}.",
        )
        partial = tpl.partial(greeting="Hello")
        result = partial.render(name="Bob", place="NYC")
        assert result == "Hello, Bob! Welcome to NYC."

    def test_partial_preserves_description(self) -> None:
        """Partial template keeps the original description."""
        tpl = PromptTemplate(
            name="test",
            template="{{x}} + {{y}}",
            description="Math template",
        )
        partial = tpl.partial(x="1")
        assert partial.description == "Math template"

    def test_multiple_partials(self) -> None:
        """Successive partial calls fill variables incrementally."""
        tpl = PromptTemplate(
            name="test",
            template="{{a}} {{b}} {{c}}",
        )
        p1 = tpl.partial(a="X")
        p2 = p1.partial(b="Y")
        result = p2.render(c="Z")
        assert result == "X Y Z"

    def test_partial_all_variables(self) -> None:
        """Partial filling all variables leaves no variables."""
        tpl = PromptTemplate(
            name="test",
            template="{{x}}",
        )
        partial = tpl.partial(x="done")
        assert partial.variables == []
        assert partial.render() == "done"


# ── Extended: Registry Operations ─────────────────────────────────────────


class TestExtendedRegistry:
    def test_overwrite_builtin(self) -> None:
        """Custom template can overwrite a built-in."""
        registry = PromptRegistry()
        custom = PromptTemplate(
            name="classify",
            template="Custom classify: {{text}}",
            description="Overwritten",
        )
        registry.register(custom)
        tpl = registry.get("classify")
        assert tpl is not None
        assert tpl.description == "Overwritten"
        # Still 5 total since we overwrote one
        assert len(registry.list_templates()) == 5

    def test_builtin_names(self) -> None:
        """All 5 built-in templates have expected names."""
        registry = PromptRegistry()
        names = {t.name for t in registry.list_templates()}
        assert names == {"classify", "extract", "summarize", "qa", "code_review"}

    def test_render_extract_template(self) -> None:
        """Renders built-in extract template."""
        registry = PromptRegistry()
        result = registry.render(
            "extract", fields="name, email", text="Contact John at john@example.com"
        )
        assert "name, email" in result
        assert "john@example.com" in result

    def test_render_summarize_template(self) -> None:
        """Renders built-in summarize template."""
        registry = PromptRegistry()
        result = registry.render(
            "summarize",
            content_type="article",
            length="3",
            text="This is a long article about AI.",
        )
        assert "article" in result
        assert "3" in result

    def test_register_and_render_custom(self) -> None:
        """Register a custom template and render it via registry."""
        registry = PromptRegistry()
        tpl = PromptTemplate(
            name="translate",
            template="Translate '{{text}}' to {{language}}.",
        )
        registry.register(tpl)
        result = registry.render("translate", text="hello", language="Spanish")
        assert result == "Translate 'hello' to Spanish."
