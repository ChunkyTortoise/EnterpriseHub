"""Forecast endpoint: POST /forecast - Time series forecasting."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from insight_engine.api.dependencies import common_dependencies
from insight_engine.api.models import (
    ForecastMethodResult,
    ForecastRequest,
    ForecastResponse,
)
from insight_engine.forecaster import Forecaster, ForecastResult

router = APIRouter(prefix="/forecast", tags=["forecasting"])


def _result_to_response(result: ForecastResult) -> ForecastMethodResult:
    """Convert internal ForecastResult to API response model."""
    return ForecastMethodResult(
        method=result.method,
        predictions=result.predictions,
        mae=result.mae,
        rmse=result.rmse,
        mape=result.mape,
    )


@router.post(
    "",
    response_model=ForecastResponse,
    summary="Forecast time series data",
    description="Apply multiple forecasting methods to time series data and return predictions with error metrics.",
    responses={
        200: {
            "description": "Forecast generated successfully",
            "content": {
                "application/json": {
                    "example": {
                        "results": [
                            {
                                "method": "moving_average",
                                "predictions": [100.5, 101.2, 102.0, 102.5, 103.0],
                                "mae": 5.2,
                                "rmse": 6.1,
                                "mape": 3.5,
                            }
                        ],
                        "best_method": "exponential_smoothing",
                        "best_mae": 4.8,
                        "horizon": 5,
                    }
                }
            },
        },
        400: {"description": "Invalid request data"},
        422: {"description": "Validation error"},
    },
)
async def forecast(
    request: ForecastRequest,
    deps: dict = Depends(common_dependencies),
) -> ForecastResponse:
    """Generate time series forecasts using multiple methods.

    This endpoint:
    - Applies multiple forecasting methods (moving average, exponential smoothing, linear trend, ensemble)
    - Computes error metrics for each method
    - Returns the best performing method based on MAE

    The data should be provided as a list of numeric values representing a time series.
    """
    try:
        # Validate data
        if not request.data:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Empty time series provided",
            )

        if len(request.data) < 3:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Time series must have at least 3 data points",
            )

        # Validate all values are numeric
        try:
            data = [float(v) for v in request.data]
        except (ValueError, TypeError):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="All time series values must be numeric",
            )

        # Initialize forecaster
        forecaster = Forecaster()

        # Run requested methods
        results: list[ForecastResult] = []
        method_map = {
            "moving_average": lambda: forecaster.moving_average(data, window=request.window, horizon=request.horizon),
            "exponential_smoothing": lambda: forecaster.exponential_smoothing(data, horizon=request.horizon),
            "linear_trend": lambda: forecaster.linear_trend(data, horizon=request.horizon),
            "ensemble": lambda: forecaster.ensemble(data, horizon=request.horizon),
        }

        for method in request.methods:
            if method in method_map:
                results.append(method_map[method]())

        if not results:
            # Default to all methods if none specified or invalid
            results = [
                forecaster.moving_average(data, window=request.window, horizon=request.horizon),
                forecaster.exponential_smoothing(data, horizon=request.horizon),
                forecaster.linear_trend(data, horizon=request.horizon),
                forecaster.ensemble(data, horizon=request.horizon),
            ]

        # Find best method by MAE
        best_result = min(results, key=lambda r: r.mae)

        # Convert to response
        return ForecastResponse(
            results=[_result_to_response(r) for r in results],
            best_method=best_result.method,
            best_mae=best_result.mae,
            horizon=request.horizon,
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating forecast: {str(e)}",
        )
