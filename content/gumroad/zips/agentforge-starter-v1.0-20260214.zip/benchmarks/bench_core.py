"""AgentForge Core Performance Benchmarks (no API keys required)."""
import time
import statistics
import json
import random
from pathlib import Path

random.seed(42)


def percentile(data, p):
    k = (len(data) - 1) * p / 100
    f = int(k)
    c = min(f + 1, len(data) - 1)
    return data[f] + (k - f) * (data[c] - data[f])


def benchmark_tool_dispatch():
    """Tool registry lookup and dispatch simulation."""
    tools = {f"tool_{i}": {"name": f"tool_{i}", "fn": lambda x: x} for i in range(50)}
    times = []
    for _ in range(10000):
        name = f"tool_{random.randint(0, 49)}"
        start = time.perf_counter()
        tool = tools[name]
        _ = tool["fn"]({"input": "test"})
        elapsed = (time.perf_counter() - start) * 1000
        times.append(elapsed)
    times.sort()
    return {
        "op": "Tool Dispatch (50 tools)",
        "n": 10000,
        "p50": round(percentile(times, 50), 4),
        "p95": round(percentile(times, 95), 4),
        "p99": round(percentile(times, 99), 4),
        "ops_sec": round(10000 / (sum(times) / 1000), 1),
    }


def benchmark_react_loop():
    """ReAct loop iteration (Thought-Action-Observation cycle)."""
    times = []
    for _ in range(2000):
        start = time.perf_counter()
        history = []
        for step in range(5):
            thought = f"Step {step}: analyzing input data"
            action = {"tool": "search", "args": {"query": f"term_{step}"}}
            observation = f"Found {random.randint(1, 10)} results"
            history.append({"thought": thought, "action": action, "observation": observation})
            # Check termination condition
            if "final" in observation:
                break
        elapsed = (time.perf_counter() - start) * 1000
        times.append(elapsed)
    times.sort()
    return {
        "op": "ReAct Loop (5 steps)",
        "n": 2000,
        "p50": round(percentile(times, 50), 4),
        "p95": round(percentile(times, 95), 4),
        "p99": round(percentile(times, 99), 4),
        "ops_sec": round(2000 / (sum(times) / 1000), 1),
    }


def benchmark_message_passing():
    """Multi-agent message routing simulation."""
    agents = [f"agent_{i}" for i in range(10)]
    times = []
    for _ in range(5000):
        src = random.choice(agents)
        dst = random.choice(agents)
        msg = {"from": src, "to": dst, "content": "task update", "priority": random.randint(1, 5)}
        start = time.perf_counter()
        serialized = json.dumps(msg)
        parsed = json.loads(serialized)
        routed = parsed["to"]
        _ = routed in agents
        elapsed = (time.perf_counter() - start) * 1000
        times.append(elapsed)
    times.sort()
    return {
        "op": "Agent Message Routing (10 agents)",
        "n": 5000,
        "p50": round(percentile(times, 50), 4),
        "p95": round(percentile(times, 95), 4),
        "p99": round(percentile(times, 99), 4),
        "ops_sec": round(5000 / (sum(times) / 1000), 1),
    }


def benchmark_token_counting():
    """Token count estimation (char-based approximation)."""
    prompts = [
        "Explain quantum computing in simple terms" * random.randint(1, 20)
        for _ in range(100)
    ]
    times = []
    for _ in range(5000):
        prompt = random.choice(prompts)
        start = time.perf_counter()
        char_count = len(prompt)
        word_count = len(prompt.split())
        estimated_tokens = int(word_count * 1.3)
        cost = estimated_tokens * 0.000015  # Claude pricing
        elapsed = (time.perf_counter() - start) * 1000
        times.append(elapsed)
    times.sort()
    return {
        "op": "Token Estimation + Cost Calc",
        "n": 5000,
        "p50": round(percentile(times, 50), 4),
        "p95": round(percentile(times, 95), 4),
        "p99": round(percentile(times, 99), 4),
        "ops_sec": round(5000 / (sum(times) / 1000), 1),
    }


def benchmark_rate_limiter():
    """Token-bucket rate limiter throughput."""
    bucket = {"tokens": 100, "max": 100, "refill_rate": 10, "last_refill": time.time()}
    times = []
    for _ in range(10000):
        start = time.perf_counter()
        now = time.time()
        elapsed_since = now - bucket["last_refill"]
        bucket["tokens"] = min(bucket["max"], bucket["tokens"] + elapsed_since * bucket["refill_rate"])
        bucket["last_refill"] = now
        allowed = bucket["tokens"] >= 1
        if allowed:
            bucket["tokens"] -= 1
        elapsed = (time.perf_counter() - start) * 1000
        times.append(elapsed)
    times.sort()
    return {
        "op": "Rate Limiter Check",
        "n": 10000,
        "p50": round(percentile(times, 50), 4),
        "p95": round(percentile(times, 95), 4),
        "p99": round(percentile(times, 99), 4),
        "ops_sec": round(10000 / (sum(times) / 1000), 1),
    }


def main():
    print("=" * 60)
    print("AgentForge Core Performance Benchmarks")
    print("=" * 60)
    benchmarks = [
        benchmark_tool_dispatch,
        benchmark_react_loop,
        benchmark_message_passing,
        benchmark_token_counting,
        benchmark_rate_limiter,
    ]
    results = []
    for bench in benchmarks:
        print(f"\nRunning {bench.__doc__.strip()}...")
        r = bench()
        results.append(r)
        print(f"  P50: {r['p50']}ms | P95: {r['p95']}ms | P99: {r['p99']}ms | {r['ops_sec']:,.0f} ops/sec")

    out = Path(__file__).parent / "RESULTS.md"
    with open(out, "w") as f:
        f.write("# AgentForge Benchmark Results\n\n")
        f.write(f"**Date**: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write("| Operation | Iterations | P50 (ms) | P95 (ms) | P99 (ms) | Throughput |\n")
        f.write("|-----------|-----------|----------|----------|----------|------------|\n")
        for r in results:
            f.write(f"| {r['op']} | {r['n']:,} | {r['p50']} | {r['p95']} | {r['p99']} | {r['ops_sec']:,.0f} ops/sec |\n")
        f.write("\n> All benchmarks use mock data. No external API keys required.\n")
    print(f"\nResults written to {out}")


if __name__ == "__main__":
    main()
