"""Streaming ReAct agent: real-time thoughts, actions, and observations.

Yields AgentStreamEvent objects as an async generator, enabling
consumers to process agent reasoning in real-time.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, AsyncIterator, Callable

from .tools import ToolRegistry, ToolResult
from .tracing import EventCollector, TraceEvent

logger = logging.getLogger("agentforge.streaming_agent")


class StreamEventType(str, Enum):
    """Type of streaming event from the agent."""

    THOUGHT = "thought"
    ACTION = "action"
    OBSERVATION = "observation"
    FINAL = "final"
    ERROR = "error"


@dataclass
class AgentStreamEvent:
    """A single event emitted during streaming agent execution."""

    event_type: StreamEventType
    content: str
    step_number: int = 0
    timestamp: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)


class StreamingReActAgent:
    """ReAct agent that streams events as an async generator.

    Yields AgentStreamEvent objects for each thought, action, observation,
    and final answer produced during the reasoning loop.

    Args:
        tool_registry: Registry of available tools.
        reason_fn: Async or sync callable (goal, history) -> (thought, action, final).
            thought: str, action: ToolCall | None, final: str | None.
        max_steps: Maximum reasoning steps (default 10).
        event_collector: Optional EventCollector for tracing integration.
    """

    def __init__(
        self,
        tool_registry: ToolRegistry,
        reason_fn: Callable[..., Any],
        max_steps: int = 10,
        event_collector: EventCollector | None = None,
    ) -> None:
        self._registry = tool_registry
        self._reason_fn = reason_fn
        self._max_steps = max_steps
        self._collector = event_collector

    def _emit_event(
        self, event_type: str, metadata: dict[str, Any] | None = None
    ) -> None:
        """Emit a trace event if collector is available."""
        if self._collector is not None:
            self._collector.collect(
                TraceEvent(event_type=event_type, metadata=metadata or {})
            )

    async def stream(self, goal: str) -> AsyncIterator[AgentStreamEvent]:
        """Execute the ReAct loop, yielding events in real-time.

        Args:
            goal: The objective for the agent to accomplish.

        Yields:
            AgentStreamEvent for each reasoning step.
        """
        if not goal or not goal.strip():
            yield AgentStreamEvent(
                event_type=StreamEventType.ERROR,
                content="Empty goal provided",
                step_number=0,
            )
            return

        self._emit_event("stream_start", {"goal": goal})
        history: list[dict[str, Any]] = []

        for step in range(1, self._max_steps + 1):
            # Think
            try:
                import inspect as _inspect

                if _inspect.iscoroutinefunction(self._reason_fn):
                    thought, action, final_answer = await self._reason_fn(
                        goal, history
                    )
                else:
                    thought, action, final_answer = self._reason_fn(goal, history)
            except Exception as exc:
                yield AgentStreamEvent(
                    event_type=StreamEventType.ERROR,
                    content=f"Reasoning error: {exc}",
                    step_number=step,
                )
                self._emit_event(
                    "stream_error", {"step": step, "error": str(exc)}
                )
                return

            # Yield thought
            yield AgentStreamEvent(
                event_type=StreamEventType.THOUGHT,
                content=thought,
                step_number=step,
            )
            self._emit_event("stream_thought", {"step": step, "thought": thought})

            # Check final answer
            if final_answer is not None:
                yield AgentStreamEvent(
                    event_type=StreamEventType.FINAL,
                    content=final_answer,
                    step_number=step,
                )
                self._emit_event(
                    "stream_final", {"step": step, "answer": final_answer}
                )
                return

            # Execute action
            observation = ""
            if action is not None:
                yield AgentStreamEvent(
                    event_type=StreamEventType.ACTION,
                    content=f"Calling tool: {action.name}",
                    step_number=step,
                    metadata={"tool": action.name, "arguments": action.arguments},
                )
                self._emit_event(
                    "stream_action", {"step": step, "tool": action.name}
                )

                result: ToolResult = self._registry.execute(action)
                if result.error:
                    observation = f"Tool error: {result.error}"
                else:
                    observation = str(result.result)

                yield AgentStreamEvent(
                    event_type=StreamEventType.OBSERVATION,
                    content=observation,
                    step_number=step,
                )
                self._emit_event(
                    "stream_observation",
                    {"step": step, "observation": observation},
                )
            else:
                observation = "No action taken."
                yield AgentStreamEvent(
                    event_type=StreamEventType.OBSERVATION,
                    content=observation,
                    step_number=step,
                )

            history.append(
                {
                    "step": step,
                    "thought": thought,
                    "action": action,
                    "observation": observation,
                }
            )

        # Max steps reached without final answer
        yield AgentStreamEvent(
            event_type=StreamEventType.ERROR,
            content=f"Max steps ({self._max_steps}) reached without final answer",
            step_number=self._max_steps,
        )
        self._emit_event(
            "stream_max_steps", {"max_steps": self._max_steps}
        )


class StreamAggregator:
    """Buffers and assembles streaming events into complete results.

    Collects partial chunks, reassembles complete events, and can
    parse partial JSON from tool calls.

    Usage:
        agg = StreamAggregator()
        async for event in agent.stream("goal"):
            agg.add_event(event)
        print(agg.final_answer)
        print(agg.thoughts)
    """

    def __init__(self) -> None:
        self._events: list[AgentStreamEvent] = []
        self._partial_json_buffer: str = ""

    def add_event(self, event: AgentStreamEvent) -> None:
        """Add a streaming event to the aggregator."""
        self._events.append(event)

    @property
    def events(self) -> list[AgentStreamEvent]:
        """All collected events."""
        return list(self._events)

    @property
    def thoughts(self) -> list[str]:
        """All thought contents in order."""
        return [
            e.content
            for e in self._events
            if e.event_type == StreamEventType.THOUGHT
        ]

    @property
    def actions(self) -> list[AgentStreamEvent]:
        """All action events."""
        return [
            e for e in self._events if e.event_type == StreamEventType.ACTION
        ]

    @property
    def observations(self) -> list[str]:
        """All observation contents in order."""
        return [
            e.content
            for e in self._events
            if e.event_type == StreamEventType.OBSERVATION
        ]

    @property
    def final_answer(self) -> str | None:
        """The final answer, if one was produced."""
        for e in reversed(self._events):
            if e.event_type == StreamEventType.FINAL:
                return e.content
        return None

    @property
    def errors(self) -> list[str]:
        """All error messages."""
        return [
            e.content
            for e in self._events
            if e.event_type == StreamEventType.ERROR
        ]

    @property
    def step_count(self) -> int:
        """Number of distinct reasoning steps."""
        steps = {e.step_number for e in self._events if e.step_number > 0}
        return len(steps)

    def clear(self) -> None:
        """Reset the aggregator."""
        self._events.clear()
        self._partial_json_buffer = ""

    def feed_partial_json(self, chunk: str) -> dict[str, Any] | None:
        """Feed a partial JSON chunk and attempt to parse a complete object.

        Buffers incoming chunks until a valid JSON object can be parsed.

        Args:
            chunk: A partial JSON string chunk.

        Returns:
            Parsed dict if a complete JSON object is assembled, None otherwise.
        """
        self._partial_json_buffer += chunk
        stripped = self._partial_json_buffer.strip()

        if not stripped:
            return None

        # Try to parse as complete JSON
        try:
            result = json.loads(stripped)
            if isinstance(result, dict):
                self._partial_json_buffer = ""
                return result
        except json.JSONDecodeError:
            pass

        # Try bracket matching to find complete object
        if stripped.startswith("{"):
            depth = 0
            in_string = False
            escape_next = False
            for i, ch in enumerate(stripped):
                if escape_next:
                    escape_next = False
                    continue
                if ch == "\\":
                    escape_next = True
                    continue
                if ch == '"' and not escape_next:
                    in_string = not in_string
                    continue
                if in_string:
                    continue
                if ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        candidate = stripped[: i + 1]
                        try:
                            result = json.loads(candidate)
                            self._partial_json_buffer = stripped[i + 1 :]
                            return result
                        except json.JSONDecodeError:
                            pass

        return None

    def to_dict(self) -> dict[str, Any]:
        """Serialize aggregator state to a dictionary."""
        return {
            "events": [
                {
                    "event_type": e.event_type.value,
                    "content": e.content,
                    "step_number": e.step_number,
                    "timestamp": e.timestamp,
                }
                for e in self._events
            ],
            "thoughts": self.thoughts,
            "final_answer": self.final_answer,
            "step_count": self.step_count,
            "error_count": len(self.errors),
        }
