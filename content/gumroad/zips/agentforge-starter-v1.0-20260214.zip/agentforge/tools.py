"""Function calling abstraction: define, register, format, and execute tool calls."""

from __future__ import annotations

import inspect
import json
import logging
from dataclasses import dataclass
from typing import Any, Callable

logger = logging.getLogger("agentforge.tools")


@dataclass
class ToolDefinition:
    """Definition of a callable tool/function."""

    name: str
    description: str
    parameters: dict[str, Any]  # JSON Schema for parameters
    handler: Callable[..., Any] | None = None  # Local execution handler


@dataclass
class ToolCall:
    """A tool call extracted from LLM response."""

    name: str
    arguments: dict[str, Any]
    call_id: str = ""


@dataclass
class ToolResult:
    """Result of executing a tool call."""

    call_id: str
    name: str
    result: Any
    error: str | None = None


class ToolRegistry:
    """Register and manage tools for LLM function calling.

    Supports conversion to Claude and OpenAI formats, local execution,
    and parsing tool calls from LLM responses.
    """

    def __init__(self) -> None:
        self._tools: dict[str, ToolDefinition] = {}

    def register(
        self,
        name: str,
        description: str,
        parameters: dict[str, Any],
        handler: Callable[..., Any] | None = None,
    ) -> ToolDefinition:
        """Register a tool. Optionally provide a handler for local execution."""
        tool = ToolDefinition(
            name=name,
            description=description,
            parameters=parameters,
            handler=handler,
        )
        self._tools[name] = tool
        logger.debug("registered tool=%s", name)
        return tool

    def register_function(
        self, func: Callable[..., Any], description: str | None = None
    ) -> ToolDefinition:
        """Register a Python function as a tool.

        Auto-extracts name and creates basic parameter schema from function signature.
        """
        name = func.__name__
        desc = description or func.__doc__ or f"Function {name}"
        sig = inspect.signature(func)
        properties: dict[str, Any] = {}
        required: list[str] = []
        for param_name, param in sig.parameters.items():
            properties[param_name] = {"type": "string"}
            if param.default is inspect.Parameter.empty:
                required.append(param_name)
        parameters: dict[str, Any] = {
            "type": "object",
            "properties": properties,
            "required": required,
        }
        return self.register(name, desc, parameters, handler=func)

    def get(self, name: str) -> ToolDefinition | None:
        """Get a tool by name."""
        return self._tools.get(name)

    def list_tools(self) -> list[ToolDefinition]:
        """List all registered tools."""
        return list(self._tools.values())

    def to_claude_format(self) -> list[dict[str, Any]]:
        """Convert all tools to Claude/Anthropic API format.

        Format: [{"name": ..., "description": ..., "input_schema": ...}]
        """
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "input_schema": tool.parameters,
            }
            for tool in self._tools.values()
        ]

    def to_openai_format(self) -> list[dict[str, Any]]:
        """Convert all tools to OpenAI API format.

        Format: [{"type": "function", "function": {"name": ..., "description": ..., "parameters": ...}}]
        """
        return [
            {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                },
            }
            for tool in self._tools.values()
        ]

    def execute(self, tool_call: ToolCall) -> ToolResult:
        """Execute a tool call locally using its registered handler.

        Returns ToolResult with error if handler not found or execution fails.
        """
        tool = self._tools.get(tool_call.name)
        if tool is None or tool.handler is None:
            return ToolResult(
                call_id=tool_call.call_id,
                name=tool_call.name,
                result=None,
                error=f"No handler for tool: {tool_call.name}",
            )
        try:
            result = tool.handler(**tool_call.arguments)
            return ToolResult(
                call_id=tool_call.call_id,
                name=tool_call.name,
                result=result,
            )
        except Exception as exc:
            logger.warning("tool=%s execution error: %s", tool_call.name, exc)
            return ToolResult(
                call_id=tool_call.call_id,
                name=tool_call.name,
                result=None,
                error=str(exc),
            )

    def parse_tool_calls(self, response: dict[str, Any]) -> list[ToolCall]:
        """Parse tool calls from an LLM response dict.

        Supports both Claude format (content[].type=="tool_use") and
        OpenAI format (tool_calls[].function).
        """
        calls: list[ToolCall] = []
        try:
            # Claude format: content blocks with type "tool_use"
            for block in response.get("content", []):
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    calls.append(
                        ToolCall(
                            name=block.get("name", ""),
                            arguments=block.get("input", {}),
                            call_id=block.get("id", ""),
                        )
                    )
            if calls:
                return calls

            # OpenAI format: tool_calls[].function
            for tc in response.get("tool_calls", []):
                if not isinstance(tc, dict):
                    continue
                func = tc.get("function", {})
                arguments = func.get("arguments", "{}")
                if isinstance(arguments, str):
                    arguments = json.loads(arguments)
                calls.append(
                    ToolCall(
                        name=func.get("name", ""),
                        arguments=arguments,
                        call_id=tc.get("id", ""),
                    )
                )
        except (json.JSONDecodeError, TypeError, AttributeError):
            logger.warning("failed to parse tool calls from response")
            return []
        return calls

    def execute_all(self, tool_calls: list[ToolCall]) -> list[ToolResult]:
        """Execute multiple tool calls and return results."""
        return [self.execute(call) for call in tool_calls]

    def validate_params(self, tool_name: str, params: dict[str, Any]) -> bool:
        """Validate parameters against tool's parameter schema.

        Supports basic JSON Schema validation: required fields and type checking.
        Returns True if valid, raises ValueError with details if not.
        """
        tool = self._tools.get(tool_name)
        if tool is None:
            raise ValueError(f"Tool not found: {tool_name}")

        schema = tool.parameters
        # If no schema or not an object schema, always pass
        if not schema or schema.get("type") != "object":
            return True

        # Check required fields
        required = schema.get("required", [])
        for field in required:
            if field not in params:
                raise ValueError(f"Missing required field: {field}")

        # Check types for provided params
        properties = schema.get("properties", {})
        for key, value in params.items():
            if key not in properties:
                continue
            expected_type = properties[key].get("type")
            if not expected_type:
                continue

            # Basic type checking
            type_map = {
                "string": str,
                "number": (int, float),
                "boolean": bool,
                "array": list,
                "object": dict,
            }
            expected_python_type = type_map.get(expected_type)
            if expected_python_type and not isinstance(value, expected_python_type):
                raise ValueError(
                    f"Field '{key}' expected type {expected_type}, got {type(value).__name__}"
                )

        return True

    def chain(
        self, tool_names: list[str], initial_input: dict[str, Any]
    ) -> list[ToolResult]:
        """Execute tools in sequence, passing each output as input to the next.

        Returns list of ToolResult objects. Stops on first error.
        """
        if not tool_names:
            return []

        results: list[ToolResult] = []
        current_input = initial_input

        for i, name in enumerate(tool_names):
            call = ToolCall(name=name, arguments=current_input, call_id=f"chain_{i}")
            result = self.execute(call)
            results.append(result)

            # Stop on error
            if result.error:
                break

            # Use result as next input (if it's a dict, otherwise wrap it)
            if isinstance(result.result, dict):
                current_input = result.result
            else:
                current_input = {"value": result.result}

        return results

    async def async_execute(self, tool_name: str, params: dict[str, Any]) -> ToolResult:
        """Execute a single tool asynchronously.

        Wraps execute() for async compatibility.
        """
        import asyncio

        call = ToolCall(name=tool_name, arguments=params, call_id="async")
        # Run in executor to avoid blocking
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.execute, call)

    async def async_execute_all(self, tool_calls: list[ToolCall]) -> list[ToolResult]:
        """Execute multiple tool calls asynchronously.

        Returns list of ToolResult objects.
        """
        import asyncio

        tasks = [self.async_execute(call.name, call.arguments) for call in tool_calls]
        return await asyncio.gather(*tasks)
