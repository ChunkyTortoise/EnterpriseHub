"""Tests for TokenBucketLimiter rate limiting."""

import time

import pytest

from agentforge.rate_limiter import RateLimitConfig, TokenBucketLimiter

# ── RateLimitConfig ────────────────────────────────────────────────────────


class TestRateLimitConfig:
    def test_defaults(self) -> None:
        """Default values are correct."""
        config = RateLimitConfig()
        assert config.requests_per_minute == 60
        assert config.tokens_per_minute == 100_000
        assert config.burst_multiplier == 1.5

    def test_custom_config(self) -> None:
        """Custom values stored correctly."""
        config = RateLimitConfig(
            requests_per_minute=120,
            tokens_per_minute=200_000,
            burst_multiplier=2.0,
        )
        assert config.requests_per_minute == 120
        assert config.tokens_per_minute == 200_000
        assert config.burst_multiplier == 2.0


# ── Token Bucket ───────────────────────────────────────────────────────────


class TestTokenBucket:
    def test_initial_capacity(self) -> None:
        """Starts with full bucket matching config values."""
        config = RateLimitConfig(requests_per_minute=60, tokens_per_minute=1000)
        limiter = TokenBucketLimiter(config)
        assert limiter.available_requests >= 59.0  # allow tiny drift
        assert limiter.available_tokens >= 999.0

    def test_acquire_decrements(self) -> None:
        """Acquiring reduces available tokens."""
        config = RateLimitConfig(requests_per_minute=60, tokens_per_minute=1000)
        limiter = TokenBucketLimiter(config)
        before_requests = limiter.available_requests
        before_tokens = limiter.available_tokens
        assert limiter.try_acquire(100)
        after_requests = limiter.available_requests
        after_tokens = limiter.available_tokens
        # Should have decremented (allowing small refill drift)
        assert after_requests < before_requests
        assert after_tokens < before_tokens

    def test_acquire_until_empty(self) -> None:
        """Eventually returns False when bucket is exhausted."""
        config = RateLimitConfig(
            requests_per_minute=3, tokens_per_minute=100_000, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)
        acquired = 0
        for _ in range(10):
            if limiter.try_acquire(1):
                acquired += 1
        # Should have acquired exactly 3 (matching requests_per_minute)
        assert acquired == 3

    def test_refill_over_time(self) -> None:
        """Tokens refill after waiting."""
        config = RateLimitConfig(
            requests_per_minute=60, tokens_per_minute=100_000, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)
        # Drain some tokens
        for _ in range(10):
            limiter.try_acquire(1)
        after_drain = limiter.available_requests
        # Wait for refill
        time.sleep(0.15)
        after_refill = limiter.available_requests
        assert after_refill > after_drain

    def test_burst_capacity(self) -> None:
        """Burst allows exceeding base rate via multiplier."""
        config = RateLimitConfig(
            requests_per_minute=10, tokens_per_minute=100_000, burst_multiplier=2.0
        )
        limiter = TokenBucketLimiter(config)
        # Max request tokens = 10 * 2.0 = 20
        # Initial tokens = 10 (from config), so can acquire 10
        # After refill to burst, could acquire up to 20
        # Just check that max is correctly set
        assert limiter._max_request_tokens == 20.0


# ── Async Acquire ──────────────────────────────────────────────────────────


class TestAsyncAcquire:
    @pytest.mark.asyncio
    async def test_acquire_success(self) -> None:
        """Acquires when tokens are available."""
        config = RateLimitConfig(requests_per_minute=60, tokens_per_minute=100_000)
        limiter = TokenBucketLimiter(config)
        result = await limiter.acquire(estimated_tokens=1, timeout=1.0)
        assert result is True

    @pytest.mark.asyncio
    async def test_acquire_timeout(self) -> None:
        """Returns False on timeout when bucket is empty."""
        config = RateLimitConfig(
            requests_per_minute=1, tokens_per_minute=100_000, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)
        # Drain the single request token
        assert limiter.try_acquire(1)
        # Now should timeout quickly
        result = await limiter.acquire(estimated_tokens=1, timeout=0.15)
        assert result is False


# ── Wait Time ──────────────────────────────────────────────────────────────


class TestWaitTime:
    def test_no_wait_when_available(self) -> None:
        """Wait time is 0 when tokens are available."""
        config = RateLimitConfig(requests_per_minute=60, tokens_per_minute=100_000)
        limiter = TokenBucketLimiter(config)
        assert limiter.wait_time(1) == 0.0

    def test_wait_when_empty(self) -> None:
        """Positive wait time when bucket is empty."""
        config = RateLimitConfig(
            requests_per_minute=2, tokens_per_minute=100_000, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)
        # Drain all request tokens
        limiter.try_acquire(1)
        limiter.try_acquire(1)
        wait = limiter.wait_time(1)
        assert wait > 0.0

    def test_wait_proportional(self) -> None:
        """More tokens needed = longer wait."""
        config = RateLimitConfig(
            requests_per_minute=600, tokens_per_minute=100, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)
        # Drain all token tokens
        limiter.try_acquire(100)
        wait_small = limiter.wait_time(10)
        wait_large = limiter.wait_time(50)
        assert wait_large > wait_small


# ── Properties ─────────────────────────────────────────────────────────────


class TestProperties:
    def test_available_requests(self) -> None:
        """Returns current request count."""
        config = RateLimitConfig(requests_per_minute=60)
        limiter = TokenBucketLimiter(config)
        assert limiter.available_requests >= 59.0

    def test_available_tokens(self) -> None:
        """Returns current token count."""
        config = RateLimitConfig(tokens_per_minute=50_000)
        limiter = TokenBucketLimiter(config)
        assert limiter.available_tokens >= 49_000.0

    def test_decrements_reflected(self) -> None:
        """After acquire, counts decrease."""
        config = RateLimitConfig(requests_per_minute=60, tokens_per_minute=1000)
        limiter = TokenBucketLimiter(config)
        before = limiter.available_requests
        limiter.try_acquire(1)
        after = limiter.available_requests
        assert after < before


# ── Extended: Concurrent Access ───────────────────────────────────────────


class TestConcurrentAccess:
    @pytest.mark.asyncio
    async def test_concurrent_acquires(self) -> None:
        """Multiple concurrent acquires don't exceed capacity."""
        import asyncio

        config = RateLimitConfig(
            requests_per_minute=10, tokens_per_minute=100_000, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)

        results = await asyncio.gather(
            *[limiter.acquire(estimated_tokens=1, timeout=0.05) for _ in range(20)]
        )
        successes = sum(1 for r in results if r is True)
        # Should not exceed initial capacity of 10
        assert successes <= 10

    @pytest.mark.asyncio
    async def test_concurrent_different_token_amounts(self) -> None:
        """Concurrent requests with varying token costs."""
        import asyncio

        config = RateLimitConfig(
            requests_per_minute=100, tokens_per_minute=50, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)

        results = await asyncio.gather(
            limiter.acquire(estimated_tokens=20, timeout=0.05),
            limiter.acquire(estimated_tokens=20, timeout=0.05),
            limiter.acquire(estimated_tokens=20, timeout=0.05),
        )
        successes = sum(1 for r in results if r is True)
        # 50 tokens available, 20 each = at most 2 succeed
        assert successes <= 2


# ── Extended: Burst Capacity ──────────────────────────────────────────────


class TestExtendedBurst:
    def test_burst_multiplier_sets_max(self) -> None:
        """Max tokens = base * burst_multiplier."""
        config = RateLimitConfig(
            requests_per_minute=100, tokens_per_minute=1000, burst_multiplier=3.0
        )
        limiter = TokenBucketLimiter(config)
        assert limiter._max_request_tokens == 300.0
        assert limiter._max_token_tokens == 3000.0

    def test_burst_multiplier_one_no_burst(self) -> None:
        """Multiplier of 1.0 means no burst beyond base rate."""
        config = RateLimitConfig(
            requests_per_minute=10, tokens_per_minute=100, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)
        assert limiter._max_request_tokens == 10.0
        assert limiter._max_token_tokens == 100.0


# ── Extended: Multiple Limiters ───────────────────────────────────────────


class TestMultipleLimiters:
    def test_independent_instances(self) -> None:
        """Two limiter instances don't affect each other."""
        config_a = RateLimitConfig(
            requests_per_minute=5, tokens_per_minute=100, burst_multiplier=1.0
        )
        config_b = RateLimitConfig(
            requests_per_minute=5, tokens_per_minute=100, burst_multiplier=1.0
        )
        limiter_a = TokenBucketLimiter(config_a)
        limiter_b = TokenBucketLimiter(config_b)

        # Drain limiter_a
        for _ in range(5):
            limiter_a.try_acquire(1)
        assert not limiter_a.try_acquire(1)

        # limiter_b should still have capacity
        assert limiter_b.try_acquire(1)


# ── Extended: Edge Cases ──────────────────────────────────────────────────


class TestEdgeCases:
    def test_try_acquire_default_tokens(self) -> None:
        """try_acquire with default estimated_tokens=1 works."""
        config = RateLimitConfig(requests_per_minute=60, tokens_per_minute=100_000)
        limiter = TokenBucketLimiter(config)
        assert limiter.try_acquire() is True

    def test_large_token_request_fails(self) -> None:
        """Request for more tokens than available fails."""
        config = RateLimitConfig(
            requests_per_minute=60, tokens_per_minute=100, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)
        # Request 200 tokens when only 100 available
        assert limiter.try_acquire(200) is False

    def test_exact_capacity_succeeds(self) -> None:
        """Request for exactly available tokens succeeds."""
        config = RateLimitConfig(
            requests_per_minute=60, tokens_per_minute=100, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)
        assert limiter.try_acquire(100) is True

    def test_token_exhaustion_separate_from_requests(self) -> None:
        """Token bucket and request bucket are independent limits."""
        config = RateLimitConfig(
            requests_per_minute=100,
            tokens_per_minute=10,
            burst_multiplier=1.0,
        )
        limiter = TokenBucketLimiter(config)
        # Plenty of request tokens but only 10 token tokens
        assert limiter.try_acquire(10) is True
        # Request tokens still available, but token tokens exhausted
        assert limiter.try_acquire(1) is False


# ── Extended: Refill Behavior ─────────────────────────────────────────────


class TestRefillBehavior:
    def test_refill_capped_at_max(self) -> None:
        """Refill never exceeds max (burst * base)."""
        config = RateLimitConfig(
            requests_per_minute=60, tokens_per_minute=1000, burst_multiplier=1.5
        )
        limiter = TokenBucketLimiter(config)
        # Wait briefly for refill
        time.sleep(0.05)
        # Should not exceed max
        assert limiter.available_requests <= limiter._max_request_tokens
        assert limiter.available_tokens <= limiter._max_token_tokens

    def test_refill_after_drain(self) -> None:
        """After draining, waiting restores some tokens."""
        config = RateLimitConfig(
            requests_per_minute=600, tokens_per_minute=100_000, burst_multiplier=1.0
        )
        limiter = TokenBucketLimiter(config)
        # Drain 10 request tokens
        for _ in range(10):
            limiter.try_acquire(1)
        drained = limiter.available_requests
        # Wait for refill (600/min = 10/sec, so 0.1s = ~1 token)
        time.sleep(0.12)
        refilled = limiter.available_requests
        assert refilled > drained


# ── Extended: Wait Time ───────────────────────────────────────────────────


class TestExtendedWaitTime:
    def test_wait_time_for_token_exhaustion(self) -> None:
        """Wait time reflects token (not request) shortage."""
        config = RateLimitConfig(
            requests_per_minute=600,
            tokens_per_minute=60,
            burst_multiplier=1.0,
        )
        limiter = TokenBucketLimiter(config)
        # Drain all token tokens
        limiter.try_acquire(60)
        wait = limiter.wait_time(10)
        # 60 tokens/min = 1 token/sec, need 10 => ~10 sec wait
        assert wait > 5.0

    def test_wait_time_zero_when_plenty_available(self) -> None:
        """Wait time is zero when both buckets have capacity."""
        config = RateLimitConfig(requests_per_minute=1000, tokens_per_minute=1_000_000)
        limiter = TokenBucketLimiter(config)
        assert limiter.wait_time(100) == 0.0

    @pytest.mark.asyncio
    async def test_acquire_succeeds_after_refill(self) -> None:
        """Async acquire succeeds after tokens refill within timeout."""
        config = RateLimitConfig(
            requests_per_minute=600,
            tokens_per_minute=100_000,
            burst_multiplier=1.0,
        )
        limiter = TokenBucketLimiter(config)
        # Drain all request tokens (600)
        for _ in range(600):
            limiter.try_acquire(1)

        # Should fail immediately but succeed within timeout as tokens refill
        # 600/min = 10/sec, so 1 token refills in 0.1s
        result = await limiter.acquire(estimated_tokens=1, timeout=1.0)
        assert result is True
