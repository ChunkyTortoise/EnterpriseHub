"""Tests for the model registry and versioning."""

from __future__ import annotations

import threading

import pytest

from agentforge.model_registry import ModelComparison, ModelRegistry, ModelVersion


# ---- Helpers ----


def _make_registry() -> ModelRegistry:
    return ModelRegistry()


def _register_sample(
    reg: ModelRegistry,
    name: str = "gpt",
    version: str = "4.0",
    provider: str = "openai",
    **kwargs,
) -> ModelVersion:
    return reg.register(name, version, provider, **kwargs)


# ---- CRUD Tests ----


class TestRegistryCRUD:
    def test_register_and_get(self):
        reg = _make_registry()
        mv = _register_sample(reg, metrics={"accuracy": 0.95})
        assert mv.name == "gpt"
        assert mv.version == "4.0"
        assert mv.status == "testing"
        fetched = reg.get("gpt", "4.0")
        assert fetched is not None
        assert fetched.metrics["accuracy"] == 0.95

    def test_get_nonexistent(self):
        reg = _make_registry()
        assert reg.get("nope", "1.0") is None

    def test_duplicate_registration_raises(self):
        reg = _make_registry()
        _register_sample(reg)
        with pytest.raises(ValueError, match="already registered"):
            _register_sample(reg)

    def test_register_with_metadata(self):
        reg = _make_registry()
        mv = _register_sample(reg, metadata={"author": "test"})
        assert mv.metadata["author"] == "test"

    def test_list_versions(self):
        reg = _make_registry()
        reg.register("claude", "3.0", "anthropic")
        reg.register("claude", "3.5", "anthropic")
        reg.register("claude", "2.0", "anthropic")
        versions = reg.list_versions("claude")
        assert len(versions) == 3
        assert [v.version for v in versions] == ["2.0", "3.0", "3.5"]

    def test_list_versions_empty(self):
        reg = _make_registry()
        assert reg.list_versions("nonexistent") == []


# ---- Lifecycle Transition Tests ----


class TestLifecycleTransitions:
    def test_promote_testing_to_active(self):
        reg = _make_registry()
        _register_sample(reg)
        mv = reg.promote("gpt", "4.0")
        assert mv.status == "active"

    def test_deprecate_active_to_deprecated(self):
        reg = _make_registry()
        _register_sample(reg)
        reg.promote("gpt", "4.0")
        mv = reg.deprecate("gpt", "4.0")
        assert mv.status == "deprecated"

    def test_archive_deprecated_to_archived(self):
        reg = _make_registry()
        _register_sample(reg)
        reg.promote("gpt", "4.0")
        reg.deprecate("gpt", "4.0")
        mv = reg.archive("gpt", "4.0")
        assert mv.status == "archived"

    def test_full_lifecycle(self):
        reg = _make_registry()
        mv = _register_sample(reg)
        assert mv.status == "testing"
        reg.promote("gpt", "4.0")
        assert mv.status == "active"
        reg.deprecate("gpt", "4.0")
        assert mv.status == "deprecated"
        reg.archive("gpt", "4.0")
        assert mv.status == "archived"

    def test_invalid_promote_from_active(self):
        reg = _make_registry()
        _register_sample(reg)
        reg.promote("gpt", "4.0")
        with pytest.raises(ValueError, match="Cannot transition"):
            reg.promote("gpt", "4.0")

    def test_invalid_deprecate_from_testing(self):
        reg = _make_registry()
        _register_sample(reg)
        with pytest.raises(ValueError, match="Cannot transition"):
            reg.deprecate("gpt", "4.0")

    def test_invalid_archive_from_active(self):
        reg = _make_registry()
        _register_sample(reg)
        reg.promote("gpt", "4.0")
        with pytest.raises(ValueError, match="Cannot transition"):
            reg.archive("gpt", "4.0")

    def test_promote_nonexistent_raises(self):
        reg = _make_registry()
        with pytest.raises(ValueError, match="not found"):
            reg.promote("nope", "1.0")


# ---- Filtering Tests ----


class TestFiltering:
    def test_filter_by_provider(self):
        reg = _make_registry()
        reg.register("gpt", "4.0", "openai")
        reg.register("claude", "3.0", "anthropic")
        results = reg.filter(provider="openai")
        assert len(results) == 1
        assert results[0].name == "gpt"

    def test_filter_by_status(self):
        reg = _make_registry()
        reg.register("a", "1.0", "x")
        reg.register("b", "1.0", "x")
        reg.promote("a", "1.0")
        results = reg.filter(status="active")
        assert len(results) == 1
        assert results[0].name == "a"

    def test_filter_by_min_metric(self):
        reg = _make_registry()
        reg.register("a", "1.0", "x", metrics={"accuracy": 0.9})
        reg.register("b", "1.0", "x", metrics={"accuracy": 0.5})
        reg.register("c", "1.0", "x", metrics={"accuracy": 0.95})
        results = reg.filter(min_metric=("accuracy", 0.85))
        assert len(results) == 2
        names = {mv.name for mv in results}
        assert names == {"a", "c"}

    def test_filter_combined(self):
        reg = _make_registry()
        reg.register("a", "1.0", "openai", metrics={"accuracy": 0.9})
        reg.register("b", "1.0", "anthropic", metrics={"accuracy": 0.95})
        reg.register("c", "1.0", "openai", metrics={"accuracy": 0.3})
        results = reg.filter(provider="openai", min_metric=("accuracy", 0.5))
        assert len(results) == 1
        assert results[0].name == "a"

    def test_filter_no_matches(self):
        reg = _make_registry()
        reg.register("a", "1.0", "openai")
        assert reg.filter(provider="google") == []


# ---- Get Best Tests ----


class TestGetBest:
    def test_get_best_active_only(self):
        reg = _make_registry()
        reg.register("a", "1.0", "x", metrics={"accuracy": 0.8})
        reg.register("b", "1.0", "x", metrics={"accuracy": 0.95})
        reg.promote("a", "1.0")
        reg.promote("b", "1.0")
        best = reg.get_best("accuracy")
        assert best is not None
        assert best.name == "b"

    def test_get_best_ignores_testing(self):
        reg = _make_registry()
        reg.register("a", "1.0", "x", metrics={"accuracy": 0.99})
        # a is still in testing status
        assert reg.get_best("accuracy") is None

    def test_get_best_no_models(self):
        reg = _make_registry()
        assert reg.get_best("accuracy") is None


# ---- History Tests ----


class TestHistory:
    def test_get_history_sorted_by_created_at(self):
        reg = _make_registry()
        reg.register("model", "1.0", "x")
        reg.register("model", "2.0", "x")
        reg.register("model", "3.0", "x")
        history = reg.get_history("model")
        assert len(history) == 3
        assert history[0].version == "1.0"
        # created_at should be non-decreasing
        for i in range(len(history) - 1):
            assert history[i].created_at <= history[i + 1].created_at

    def test_get_history_empty(self):
        reg = _make_registry()
        assert reg.get_history("nonexistent") == []


# ---- Comparison Tests ----


class TestComparison:
    def test_compare_two_versions(self):
        reg = _make_registry()
        reg.register("a", "1.0", "x", metrics={"accuracy": 0.8, "latency": 100})
        reg.register("b", "1.0", "y", metrics={"accuracy": 0.9, "latency": 50})
        cmp = reg.compare([("a", "1.0"), ("b", "1.0")])
        assert len(cmp.versions) == 2
        assert cmp.best_by["accuracy"] == "b@1.0"
        assert cmp.best_by["latency"] == "a@1.0"  # 100 > 50, higher is "best"

    def test_compare_nonexistent_versions(self):
        reg = _make_registry()
        cmp = reg.compare([("nope", "1.0")])
        assert cmp.versions == []
        assert "No versions found" in cmp.summary

    def test_compare_single_version(self):
        reg = _make_registry()
        reg.register("a", "1.0", "x", metrics={"accuracy": 0.9})
        cmp = reg.compare([("a", "1.0")])
        assert len(cmp.versions) == 1
        assert cmp.best_by["accuracy"] == "a@1.0"

    def test_compare_mixed_metrics(self):
        reg = _make_registry()
        reg.register("a", "1.0", "x", metrics={"accuracy": 0.9})
        reg.register("b", "1.0", "y", metrics={"speed": 200})
        cmp = reg.compare([("a", "1.0"), ("b", "1.0")])
        assert cmp.best_by["accuracy"] == "a@1.0"
        assert cmp.best_by["speed"] == "b@1.0"


# ---- Thread Safety Tests ----


class TestThreadSafety:
    def test_concurrent_registration(self):
        reg = _make_registry()
        errors: list[str] = []

        def register_model(i: int):
            try:
                reg.register(f"model_{i}", "1.0", "test", metrics={"score": float(i)})
            except Exception as e:
                errors.append(str(e))

        threads = [
            threading.Thread(target=register_model, args=(i,)) for i in range(50)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        assert len(reg.list_versions("model_0")) == 1

    def test_concurrent_reads_and_writes(self):
        reg = _make_registry()
        for i in range(10):
            reg.register(f"m{i}", "1.0", "test", metrics={"score": float(i)})

        results: list[int] = []

        def reader():
            for _ in range(20):
                results.append(len(reg.filter(provider="test")))

        def writer(start: int):
            for i in range(5):
                reg.register(f"extra_{start}_{i}", "1.0", "test")

        threads = [
            threading.Thread(target=reader),
            threading.Thread(target=writer, args=(0,)),
            threading.Thread(target=reader),
            threading.Thread(target=writer, args=(1,)),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # Should have 10 + 10 = 20 models total
        assert len(reg.filter(provider="test")) == 20


# ---- Dataclass Tests ----


class TestDataclasses:
    def test_model_version_defaults(self):
        mv = ModelVersion(name="test", version="1.0", provider="x")
        assert mv.status == "testing"
        assert mv.metrics == {}
        assert mv.metadata == {}
        assert mv.created_at > 0

    def test_model_comparison_defaults(self):
        cmp = ModelComparison()
        assert cmp.versions == []
        assert cmp.best_by == {}
        assert cmp.summary == ""
