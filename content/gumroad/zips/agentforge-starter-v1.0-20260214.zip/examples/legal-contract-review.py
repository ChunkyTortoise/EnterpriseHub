"""Legal contract analysis using ReAct agent with structured output.

This example demonstrates:
- Multi-step contract review with ReAct pattern
- Structured extraction of key terms
- Guardrails for PII detection
- Cost tracking per analysis

Use case: LegalTech startups automating contract review workflows.
"""

from __future__ import annotations

import asyncio
from agentforge import AIOrchestrator, StructuredOutput, ReActAgent, ToolRegistry
from agentforge.guardrails import GuardrailsEngine
from agentforge.cost_tracker import CostTracker


CONTRACT_TEXT = """
SERVICE AGREEMENT

This Service Agreement ("Agreement") is entered into as of January 15, 2026 ("Effective Date"),
between TechCorp Inc. ("Company") and CloudServices LLC ("Provider").

1. TERM: This Agreement shall commence on the Effective Date and continue for 12 months,
   automatically renewing for successive 12-month periods unless terminated with 30 days notice.

2. PRICING: Company shall pay Provider $5,000 per month for the Standard Plan. 
   Additional API calls billed at $0.01 per request. Annual increase capped at 5%.

3. SERVICE LEVELS: Provider guarantees 99.9% uptime. Downtime credits: 10% of monthly fee
   per hour of unavailability, up to 100% of monthly fee.

4. DATA SECURITY: Provider maintains SOC2 Type II certification. Data stored in US-East region.
   Encryption at rest (AES-256) and in transit (TLS 1.3).

5. TERMINATION: Either party may terminate for convenience with 60 days written notice.
   Company may terminate immediately for material breach with 10 days cure period.

6. LIMITATION OF LIABILITY: Provider's liability capped at fees paid in preceding 12 months.
   Excludes liability for data breach, gross negligence, or willful misconduct.

Signed: _________________                    Date: _______________
"""


async def analyze_contract():
    """Run contract analysis with ReAct agent."""
    
    # Initialize components
    cost_tracker = CostTracker()
    orchestrator = AIOrchestrator(
        temperature=0.1,  # Low temperature for consistency
        max_tokens=2048,
    )
    guardrails = GuardrailsEngine()
    
    # Check for PII before processing
    pii_check = guardrails.check_pii(CONTRACT_TEXT)
    if pii_check.violations:
        print("⚠️  PII detected:", pii_check.violations)
        # In production: redact or reject
    
    # Structured extraction schema
    schema = {
        "type": "object",
        "properties": {
            "contract_type": {"type": "string"},
            "effective_date": {"type": "string"},
            "term_months": {"type": "integer"},
            "monthly_cost": {"type": "number"},
            "annual_increase_cap": {"type": "number"},
            "sla_uptime": {"type": "string"},
            "termination_notice_days": {"type": "integer"},
            "liability_cap": {"type": "string"},
            "key_risks": {
                "type": "array",
                "items": {"type": "string"}
            },
            "recommendations": {
                "type": "array",
                "items": {"type": "string"}
            }
        },
        "required": ["contract_type", "term_months", "monthly_cost"]
    }
    
    # Multi-step analysis prompt
    analysis_prompt = f"""
    Analyze this service agreement comprehensively:

    {CONTRACT_TEXT}

    Extract all key terms and identify risks. Be thorough:
    1. Identify contract parties and effective date
    2. Extract pricing structure and annual increase cap
    3. Note SLA guarantees and penalty structure
    4. Identify termination clauses and notice periods
    5. Assess liability limitations and exclusions
    6. Flag any unusual or risky terms
    7. Provide specific recommendations for negotiation

    Return structured data following the schema.
    """
    
    # Run analysis
    print("🔍 Analyzing contract with Claude...")
    response = await orchestrator.chat(
        "claude",
        analysis_prompt,
        system="You are a legal contract analyst. Extract structured data and flag risks."
    )
    
    # Extract structured output
    structured = StructuredOutput(schema=schema)
    result = structured.extract(response.content)
    
    # Track costs
    cost_tracker.record_request(
        provider="claude",
        model=response.model,
        prompt_tokens=1500,
        completion_tokens=800,
    )
    
    # Display results
    print("\n📊 CONTRACT ANALYSIS RESULTS")
    print("=" * 50)
    print(f"Contract Type: {result.data.get('contract_type', 'N/A')}")
    print(f"Term: {result.data.get('term_months', 'N/A')} months")
    print(f"Monthly Cost: ${result.data.get('monthly_cost', 'N/A')}")
    print(f"SLA Uptime: {result.data.get('sla_uptime', 'N/A')}")
    print(f"Termination Notice: {result.data.get('termination_notice_days', 'N/A')} days")
    print(f"\n💰 Analysis Cost: ${cost_tracker.session_total():.4f}")
    
    print("\n⚠️  KEY RISKS IDENTIFIED:")
    for risk in result.data.get('key_risks', []):
        print(f"  - {risk}")
    
    print("\n✅ RECOMMENDATIONS:")
    for rec in result.data.get('recommendations', []):
        print(f"  - {rec}")
    
    return result


if __name__ == "__main__":
    asyncio.run(analyze_contract())
