"""Fintech fraud detection using multi-agent consensus system.

This example demonstrates:
- Multi-agent mesh with specialized fraud detection agents
- Consensus-based decision making (weighted voting)
- Parallel analysis of transaction data
- Risk scoring and confidence thresholds

Use case: Fintech platforms detecting suspicious transactions in real-time.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Optional
from agentforge import AIOrchestrator
from agentforge.multi_agent import AgentMesh, AgentMessage, MessageType
from agentforge.evaluation import AgentEvaluator, EvalCase


@dataclass
class Transaction:
    """Sample transaction data."""
    tx_id: str
    amount: float
    sender_id: str
    receiver_id: str
    timestamp: str
    location: str
    device_fingerprint: str
    historical_volume_avg: float


# Simulated suspicious transaction
SUSPICIOUS_TX = Transaction(
    tx_id="TX-2026-02-11-001",
    amount=15000.00,  # 10x normal volume
    sender_id="USR-55432",
    receiver_id="USR-NEW-88921",  # New recipient
    timestamp="2026-02-11T03:45:00Z",  # 3:45 AM - unusual time
    location="Moscow, RU",  # Unusual location
    device_fingerprint="fp-abc123-new-device",  # New device
    historical_volume_avg=1200.00
)


class FraudDetectionMesh:
    """Multi-agent system for fraud detection."""
    
    def __init__(self):
        self.orchestrator = AIOrchestrator(temperature=0.1, max_tokens=1024)
        self.mesh = AgentMesh()
        self.evaluator = AgentEvaluator()
        
        # Register specialized fraud detection agents
        self._register_agents()
    
    def _register_agents(self):
        """Register fraud detection specialist agents."""
        
        # Agent 1: Amount Pattern Analyzer
        self.mesh.register_agent(
            agent_id="amount_analyzer",
            role="fraud_specialist",
            capabilities=["amount_analysis", "volume_detection"],
            handler=self._analyze_amount_patterns
        )
        
        # Agent 2: Location & Time Analyzer  
        self.mesh.register_agent(
            agent_id="geo_temporal_analyzer",
            role="fraud_specialist",
            capabilities=["geolocation", "temporal_analysis"],
            handler=self._analyze_geo_temporal
        )
        
        # Agent 3: Device & Identity Analyzer
        self.mesh.register_agent(
            agent_id="identity_analyzer",
            role="fraud_specialist",
            capabilities=["device_fingerprinting", "identity_verification"],
            handler=self._analyze_identity
        )
        
        # Agent 4: Network Relationship Analyzer
        self.mesh.register_agent(
            agent_id="network_analyzer",
            role="fraud_specialist",
            capabilities=["network_analysis", "relationship_mapping"],
            handler=self._analyze_network
        )
        
        # Agent 5: Velocity & Frequency Analyzer
        self.mesh.register_agent(
            agent_id="velocity_analyzer",
            role="fraud_specialist",
            capabilities=["velocity_checks", "frequency_analysis"],
            handler=self._analyze_velocity
        )
    
    async def analyze_transaction(self, tx: Transaction) -> dict:
        """
        Run multi-agent fraud analysis with consensus.
        
        Each agent analyzes a different risk vector.
        Final decision uses weighted consensus.
        """
        
        print(f"🔍 Analyzing transaction {tx.tx_id}")
        print(f"   Amount: ${tx.amount:,.2f} (avg: ${tx.historical_volume_avg:,.2f})")
        print(f"   Location: {tx.location}")
        print("-" * 50)
        
        # Broadcast to all agents
        tx_data = {
            "tx_id": tx.tx_id,
            "amount": tx.amount,
            "sender": tx.sender_id,
            "receiver": tx.receiver_id,
            "timestamp": tx.timestamp,
            "location": tx.location,
            "device": tx.device_fingerprint,
            "historical_avg": tx.historical_volume_avg
        }
        
        # Collect agent assessments
        assessments = []
        
        for agent_id in self.mesh.list_agents():
            agent_info = self.mesh.get_agent(agent_id)
            
            # Create analysis message
            msg = AgentMessage(
                sender="coordinator",
                recipient=agent_id,
                message_type=MessageType.TASK,
                payload={"transaction": tx_data, "agent_role": agent_info.role}
            )
            
            # Get agent assessment
            response = await agent_info.handler(msg)
            assessments.append(response)
            
            print(f"✅ {agent_id}: Risk={response['risk_score']:.2f}, "
                  f"Confidence={response['confidence']:.2f}")
        
        # Weighted consensus calculation
        consensus = self._calculate_consensus(assessments)
        
        return {
            "transaction_id": tx.tx_id,
            "consensus_risk_score": consensus["risk_score"],
            "consensus_confidence": consensus["confidence"],
            "recommendation": consensus["recommendation"],
            "agent_count": len(assessments),
            "high_confidence_agents": consensus["high_confidence_count"],
            "risk_factors": consensus["risk_factors"]
        }
    
    async def _analyze_amount_patterns(self, msg: AgentMessage) -> dict:
        """Agent 1: Analyze amount patterns and velocity."""
        tx = msg.payload["transaction"]
        
        prompt = f"""
        Analyze this transaction for amount-related fraud indicators:
        - Amount: ${tx['amount']:,.2f}
        - User historical average: ${tx['historical_avg']:,.2f}
        
        Calculate:
        1. Risk score (0.0-1.0) based on deviation from historical patterns
        2. Confidence level (0.0-1.0) in your assessment
        3. Key risk factors identified
        
        Return JSON with: risk_score, confidence, factors (list)
        """
        
        response = await self.orchestrator.chat("claude", prompt)
        
        # Parse structured response
        return {
            "agent": "amount_analyzer",
            "risk_score": 0.85,  # Would parse from response
            "confidence": 0.92,
            "factors": ["10x historical volume", "unusual round number"],
            "raw_assessment": response.content
        }
    
    async def _analyze_geo_temporal(self, msg: AgentMessage) -> dict:
        """Agent 2: Analyze location and timing patterns."""
        tx = msg.payload["transaction"]
        
        prompt = f"""
        Analyze geographic and temporal fraud indicators:
        - Location: {tx['location']}
        - Timestamp: {tx['timestamp']}
        - Device: {tx['device']}
        
        Flag if:
        - Transaction at unusual hours (3-6 AM)
        - Location inconsistent with user history
        - High-risk geography
        
        Return JSON with: risk_score, confidence, factors
        """
        
        response = await self.orchestrator.chat("claude", prompt)
        
        return {
            "agent": "geo_temporal_analyzer",
            "risk_score": 0.75,
            "confidence": 0.88,
            "factors": ["unusual hour", "international location"],
            "raw_assessment": response.content
        }
    
    async def _analyze_identity(self, msg: AgentMessage) -> dict:
        """Agent 3: Analyze device and identity signals."""
        tx = msg.payload["transaction"]
        
        return {
            "agent": "identity_analyzer",
            "risk_score": 0.60,
            "confidence": 0.75,
            "factors": ["new device fingerprint", "first-time recipient"],
            "raw_assessment": "New device + new recipient combination"
        }
    
    async def _analyze_network(self, msg: AgentMessage) -> dict:
        """Agent 4: Analyze network relationships."""
        tx = msg.payload["transaction"]
        
        return {
            "agent": "network_analyzer",
            "risk_score": 0.45,
            "confidence": 0.60,
            "factors": ["limited network history with recipient"],
            "raw_assessment": "Recipient appears legitimate but low interaction history"
        }
    
    async def _analyze_velocity(self, msg: AgentMessage) -> dict:
        """Agent 5: Analyze transaction velocity and frequency."""
        tx = msg.payload["transaction"]
        
        return {
            "agent": "velocity_analyzer",
            "risk_score": 0.70,
            "confidence": 0.85,
            "factors": ["unusual velocity spike", "single large tx vs pattern"],
            "raw_assessment": "Significant deviation from typical transaction pattern"
        }
    
    def _calculate_consensus(self, assessments: list) -> dict:
        """Calculate weighted consensus across all agents."""
        
        if not assessments:
            return {"risk_score": 0.0, "confidence": 0.0, "recommendation": "insufficient_data"}
        
        # Weight by confidence
        total_weight = sum(a["confidence"] for a in assessments)
        weighted_risk = sum(a["risk_score"] * a["confidence"] for a in assessments) / total_weight
        
        # Collect all risk factors
        all_factors = []
        for a in assessments:
            all_factors.extend(a.get("factors", []))
        
        # High confidence threshold
        high_confidence_count = sum(1 for a in assessments if a["confidence"] > 0.80)
        
        # Recommendation logic
        if weighted_risk > 0.75 and high_confidence_count >= 3:
            recommendation = "BLOCK"
        elif weighted_risk > 0.60:
            recommendation = "REVIEW"
        elif weighted_risk > 0.40:
            recommendation = "MONITOR"
        else:
            recommendation = "APPROVE"
        
        return {
            "risk_score": weighted_risk,
            "confidence": total_weight / len(assessments),
            "recommendation": recommendation,
            "high_confidence_count": high_confidence_count,
            "risk_factors": list(set(all_factors))  # Deduplicate
        }


async def main():
    """Demo fraud detection system."""
    
    print("🏦 Fintech Fraud Detection - Multi-Agent Consensus")
    print("=" * 60)
    
    # Initialize mesh
    fraud_system = FraudDetectionMesh()
    
    # Analyze suspicious transaction
    result = await fraud_system.analyze_transaction(SUSPICIOUS_TX)
    
    # Display results
    print("\n" + "=" * 60)
    print("📊 CONSENSUS RESULT")
    print("=" * 60)
    print(f"Risk Score: {result['consensus_risk_score']:.2f}/1.0")
    print(f"Confidence: {result['consensus_confidence']:.2%}")
    print(f"Agents Consulted: {result['agent_count']}")
    print(f"High Confidence: {result['high_confidence_agents']} agents")
    
    print(f"\n🎯 RECOMMENDATION: {result['recommendation']}")
    
    if result['recommendation'] == "BLOCK":
        print("   ⚠️  Transaction should be blocked pending review")
    elif result['recommendation'] == "REVIEW":
        print("   🔍 Route to manual review queue")
    elif result['recommendation'] == "MONITOR":
        print("   👁️  Approve but flag for monitoring")
    else:
        print("   ✅ Approve transaction")
    
    print("\n📋 Risk Factors Identified:")
    for factor in result['risk_factors']:
        print(f"   • {factor}")
    
    print("\n✨ Analysis complete using multi-agent consensus")


if __name__ == "__main__":
    asyncio.run(main())
