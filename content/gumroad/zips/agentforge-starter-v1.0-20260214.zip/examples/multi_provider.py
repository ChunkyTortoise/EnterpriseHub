import asyncio

from agentforge import AIOrchestrator


async def main() -> None:
    orc = AIOrchestrator()
    prompt = "Explain vector databases in 1 sentence."
    for provider in ["gemini", "perplexity", "claude", "openai"]:
        try:
            response = await orc.chat(provider, prompt)
            print(f"[{provider}] {response.content}")
        except Exception as exc:
            print(f"[{provider}] error: {exc}")


if __name__ == "__main__":
    asyncio.run(main())
