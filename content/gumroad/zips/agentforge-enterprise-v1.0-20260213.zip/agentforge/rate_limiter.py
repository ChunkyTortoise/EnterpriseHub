"""Token-aware rate limiting with token bucket algorithm."""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass

logger = logging.getLogger("agentforge.rate_limiter")


@dataclass
class RateLimitConfig:
    """Rate limit configuration for a provider."""

    requests_per_minute: int = 60
    tokens_per_minute: int = 100_000
    burst_multiplier: float = 1.5  # allow burst up to this multiplier


class TokenBucketLimiter:
    """Token bucket rate limiter with async support.

    Uses the token bucket algorithm: tokens are added at a fixed rate,
    and each request consumes tokens. Supports burst via multiplier.
    """

    def __init__(self, config: RateLimitConfig) -> None:
        self.config = config
        self._request_tokens = float(config.requests_per_minute)
        self._token_tokens = float(config.tokens_per_minute)
        self._max_request_tokens = config.requests_per_minute * config.burst_multiplier
        self._max_token_tokens = config.tokens_per_minute * config.burst_multiplier
        self._last_refill = time.monotonic()
        self._request_rate = config.requests_per_minute / 60.0  # per second
        self._token_rate = config.tokens_per_minute / 60.0

    def _refill(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._last_refill = now
        self._request_tokens = min(
            self._max_request_tokens,
            self._request_tokens + elapsed * self._request_rate,
        )
        self._token_tokens = min(
            self._max_token_tokens,
            self._token_tokens + elapsed * self._token_rate,
        )

    def try_acquire(self, estimated_tokens: int = 1) -> bool:
        """Try to acquire rate limit tokens. Returns True if allowed, False if should wait."""
        self._refill()
        if self._request_tokens >= 1.0 and self._token_tokens >= estimated_tokens:
            self._request_tokens -= 1.0
            self._token_tokens -= estimated_tokens
            return True
        return False

    async def acquire(self, estimated_tokens: int = 1, timeout: float = 30.0) -> bool:
        """Async acquire with wait. Returns True when acquired, False if timeout."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.try_acquire(estimated_tokens):
                return True
            await asyncio.sleep(0.1)
        return False

    def wait_time(self, estimated_tokens: int = 1) -> float:
        """Estimate seconds to wait before next request can proceed."""
        self._refill()
        request_wait = (
            max(0.0, (1.0 - self._request_tokens) / self._request_rate)
            if self._request_tokens < 1.0
            else 0.0
        )
        token_wait = (
            max(0.0, (estimated_tokens - self._token_tokens) / self._token_rate)
            if self._token_tokens < estimated_tokens
            else 0.0
        )
        return max(request_wait, token_wait)

    @property
    def available_requests(self) -> float:
        """Current available request tokens."""
        self._refill()
        return self._request_tokens

    @property
    def available_tokens(self) -> float:
        """Current available token tokens."""
        self._refill()
        return self._token_tokens
