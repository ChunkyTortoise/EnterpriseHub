"""ReAct (Reasoning + Acting) agent loop implementation.

Implements the Yao et al. ReAct pattern: think -> act -> observe loop
with loop detection, max iterations, and error recovery.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from .tools import ToolCall, ToolRegistry, ToolResult
from .tracing import EventCollector, TraceEvent

logger = logging.getLogger("agentforge.react_agent")


@dataclass
class Thought:
    """A single reasoning thought produced by the agent."""

    text: str
    confidence: float = 0.0


@dataclass
class ReActStep:
    """A single step in the ReAct loop: thought, action, observation."""

    step_number: int
    thought: Thought
    action: ToolCall | None = None
    observation: str = ""
    elapsed_ms: float = 0.0


@dataclass
class AgentTrace:
    """Complete trace of a ReAct agent run."""

    goal: str
    steps: list[ReActStep] = field(default_factory=list)
    final_answer: str = ""
    total_ms: float = 0.0
    success: bool = False


class ReActAgent:
    """ReAct agent that executes a think-act-observe loop.

    Uses a reasoning function to decide what to do at each step,
    executes tool calls via ToolRegistry, and observes results.

    Args:
        tool_registry: Registry of available tools.
        reason_fn: Function that takes (goal, history) and returns
            (thought, optional tool_call, optional final_answer).
            history is a list of ReActStep objects from prior iterations.
        max_iterations: Maximum number of loop iterations (default 10).
        event_collector: Optional EventCollector for tracing integration.
    """

    def __init__(
        self,
        tool_registry: ToolRegistry,
        reason_fn: Callable[
            [str, list[ReActStep]],
            tuple[Thought, ToolCall | None, str | None],
        ],
        max_iterations: int = 10,
        event_collector: EventCollector | None = None,
    ) -> None:
        self._registry = tool_registry
        self._reason_fn = reason_fn
        self._max_iterations = max_iterations
        self._collector = event_collector

    def _emit_event(
        self, event_type: str, metadata: dict[str, Any] | None = None
    ) -> None:
        """Emit a trace event if collector is available."""
        if self._collector is not None:
            self._collector.collect(
                TraceEvent(
                    event_type=event_type,
                    metadata=metadata or {},
                )
            )

    def _detect_loop(
        self,
        steps: list[ReActStep],
        current_thought: Thought,
        current_action: ToolCall | None,
    ) -> bool:
        """Detect if the agent is stuck in a loop.

        Returns True if the same thought+action pair has appeared
        in the last 3 steps.
        """
        if len(steps) < 2:
            return False

        recent = steps[-3:] if len(steps) >= 3 else steps
        matches = 0
        for step in recent:
            thought_match = step.thought.text == current_thought.text
            action_match = (step.action is None and current_action is None) or (
                step.action is not None
                and current_action is not None
                and step.action.name == current_action.name
                and step.action.arguments == current_action.arguments
            )
            if thought_match and action_match:
                matches += 1

        return matches >= 2

    def run(self, goal: str) -> AgentTrace:
        """Execute the ReAct loop for the given goal.

        Args:
            goal: The objective for the agent to accomplish.

        Returns:
            AgentTrace with all steps, final answer, and timing.
        """
        if not goal or not goal.strip():
            return AgentTrace(
                goal=goal,
                final_answer="",
                total_ms=0.0,
                success=False,
            )

        trace = AgentTrace(goal=goal)
        start_time = time.monotonic()

        self._emit_event("react_start", {"goal": goal})

        for iteration in range(1, self._max_iterations + 1):
            step_start = time.monotonic()

            # Think
            try:
                thought, action, final_answer = self._reason_fn(goal, trace.steps)
            except Exception as exc:
                logger.warning("reason_fn error at step %d: %s", iteration, exc)
                step = ReActStep(
                    step_number=iteration,
                    thought=Thought(text=f"Error during reasoning: {exc}"),
                    observation=f"Reasoning failed: {exc}",
                    elapsed_ms=(time.monotonic() - step_start) * 1000,
                )
                trace.steps.append(step)
                self._emit_event("react_error", {"step": iteration, "error": str(exc)})
                break

            self._emit_event(
                "react_thought", {"step": iteration, "thought": thought.text}
            )

            # Check for final answer
            if final_answer is not None:
                step = ReActStep(
                    step_number=iteration,
                    thought=thought,
                    observation="Final answer reached.",
                    elapsed_ms=(time.monotonic() - step_start) * 1000,
                )
                trace.steps.append(step)
                trace.final_answer = final_answer
                trace.success = True
                self._emit_event(
                    "react_final_answer", {"step": iteration, "answer": final_answer}
                )
                break

            # Loop detection
            if self._detect_loop(trace.steps, thought, action):
                step = ReActStep(
                    step_number=iteration,
                    thought=thought,
                    action=action,
                    observation="Loop detected: repeated thought/action pattern.",
                    elapsed_ms=(time.monotonic() - step_start) * 1000,
                )
                trace.steps.append(step)
                trace.final_answer = "Agent detected a reasoning loop and stopped."
                trace.success = False
                self._emit_event("react_loop_detected", {"step": iteration})
                break

            # Act
            observation = ""
            if action is not None:
                self._emit_event(
                    "react_action", {"step": iteration, "tool": action.name}
                )
                result: ToolResult = self._registry.execute(action)
                if result.error:
                    observation = f"Tool error: {result.error}"
                    self._emit_event(
                        "react_tool_error", {"step": iteration, "error": result.error}
                    )
                else:
                    observation = str(result.result)
                    self._emit_event(
                        "react_observation",
                        {"step": iteration, "observation": observation},
                    )
            else:
                observation = "No action taken."

            step = ReActStep(
                step_number=iteration,
                thought=thought,
                action=action,
                observation=observation,
                elapsed_ms=(time.monotonic() - step_start) * 1000,
            )
            trace.steps.append(step)

        trace.total_ms = (time.monotonic() - start_time) * 1000
        self._emit_event(
            "react_end", {"total_steps": len(trace.steps), "success": trace.success}
        )

        return trace
