"""Anthropic Claude provider."""

from __future__ import annotations

import json
from typing import AsyncGenerator

from ..client_types import AIResponse
from .base import ProviderBase, extract_sse_data


class ClaudeProvider(ProviderBase):
    name = "claude"
    default_model = "claude-3-5-sonnet-20241022"
    env_key = "ANTHROPIC_API_KEY"

    async def chat(
        self,
        prompt: str,
        system: str,
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> AIResponse:
        key = self._require_key()
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        payload = {
            "model": model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
        }
        data, elapsed_ms, status_code = await self.orchestrator._request_json(
            self.name, url, payload, headers=headers
        )
        content = data["content"][0]["text"]
        metadata = {"usage": data.get("usage"), "status_code": status_code}
        model_name = data.get("model") or model
        return AIResponse(
            content=content,
            provider=self.name,
            model=model_name,
            elapsed_ms=elapsed_ms,
            metadata=metadata,
        )

    async def stream(
        self,
        prompt: str,
        system: str,
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> AsyncGenerator[str, None]:
        key = self._require_key()
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        payload = {
            "model": model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "stream": True,
        }
        current_event = None
        async for line in self.orchestrator._stream_lines(
            self.name, url, payload, headers=headers
        ):
            if line.startswith("event:"):
                current_event = line.replace("event:", "").strip()
                continue
            data_line = extract_sse_data(line)
            if not data_line or data_line == "[DONE]":
                continue
            try:
                data = json.loads(data_line)
            except json.JSONDecodeError:
                continue
            if current_event == "content_block_delta":
                text = data.get("delta", {}).get("text")
                if text:
                    yield text
