"""AgentForge Flow Visualizer - Streamlit Cloud entry point.

This file serves as the main entry point for Streamlit Cloud deployment.
It imports and runs the main app from app.py.

For local development, you can run either:
    streamlit run streamlit_app.py
    streamlit run app.py
"""

from app import main

if __name__ == "__main__":
    main()
