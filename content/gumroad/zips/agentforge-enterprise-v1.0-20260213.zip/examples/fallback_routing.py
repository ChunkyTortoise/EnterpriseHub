import asyncio

from agentforge import AIOrchestrator


async def main() -> None:
    orc = AIOrchestrator(fallback_chain=["openai", "gemini"])
    response = await orc.chat("claude", "Summarize RAG in 1 sentence")
    print(f"Provider used: {response.provider}")
    print(response.content)


if __name__ == "__main__":
    asyncio.run(main())
