"""Tests for agentforge.tracing — TraceEvent, TraceSpan, EventCollector."""

from __future__ import annotations

from agentforge.tracing import EventCollector, TraceEvent, TraceSpan

# --- TraceEvent tests ---


class TestTraceEvent:
    def test_creation_with_defaults(self) -> None:
        event = TraceEvent()
        assert event.event_type == ""
        assert event.provider == ""
        assert event.model == ""
        assert event.elapsed_ms == 0.0
        assert event.metadata == {}
        assert event.timestamp > 0

    def test_creation_with_values(self) -> None:
        event = TraceEvent(
            event_type="request",
            provider="anthropic",
            model="claude-sonnet-4-5-20250929",
            elapsed_ms=150.0,
            metadata={"prompt_tokens": 100},
        )
        assert event.event_type == "request"
        assert event.provider == "anthropic"
        assert event.model == "claude-sonnet-4-5-20250929"
        assert event.elapsed_ms == 150.0
        assert event.metadata == {"prompt_tokens": 100}

    def test_to_dict_serialization(self) -> None:
        event = TraceEvent(
            event_type="response",
            provider="openai",
            model="gpt-4o",
            elapsed_ms=280.0,
            metadata={"completion_tokens": 200},
        )
        d = event.to_dict()
        assert d["event_type"] == "response"
        assert d["provider"] == "openai"
        assert d["model"] == "gpt-4o"
        assert d["elapsed_ms"] == 280.0
        assert d["metadata"] == {"completion_tokens": 200}
        assert "timestamp" in d


# --- TraceSpan tests ---


class TestTraceSpan:
    def test_total_ms_calculation(self) -> None:
        span = TraceSpan(trace_id="test-span")
        span.events = [
            TraceEvent(elapsed_ms=100.0),
            TraceEvent(elapsed_ms=200.0),
            TraceEvent(elapsed_ms=50.0),
        ]
        assert span.total_ms == 350.0

    def test_total_ms_empty_span(self) -> None:
        span = TraceSpan(trace_id="empty")
        assert span.total_ms == 0.0

    def test_event_count_property(self) -> None:
        span = TraceSpan(trace_id="count-test")
        assert span.event_count == 0
        span.events.append(TraceEvent(event_type="request"))
        span.events.append(TraceEvent(event_type="response"))
        assert span.event_count == 2

    def test_to_dict_with_multiple_events(self) -> None:
        span = TraceSpan(trace_id="dict-test")
        span.events = [
            TraceEvent(event_type="request", provider="anthropic", elapsed_ms=10.0),
            TraceEvent(event_type="response", provider="anthropic", elapsed_ms=120.0),
        ]
        d = span.to_dict()
        assert d["trace_id"] == "dict-test"
        assert d["total_ms"] == 130.0
        assert d["event_count"] == 2
        assert len(d["events"]) == 2
        assert d["events"][0]["event_type"] == "request"
        assert d["events"][1]["event_type"] == "response"

    def test_auto_generated_trace_id(self) -> None:
        span = TraceSpan()
        assert len(span.trace_id) == 12


# --- EventCollector tests ---


class TestEventCollector:
    def test_start_span(self) -> None:
        collector = EventCollector()
        span = collector.start_span(trace_id="span-1")
        assert span.trace_id == "span-1"
        assert collector.get_trace("span-1") is span

    def test_start_span_auto_id(self) -> None:
        collector = EventCollector()
        span = collector.start_span()
        assert len(span.trace_id) == 12
        assert collector.get_trace(span.trace_id) is span

    def test_collect_to_active_span(self) -> None:
        collector = EventCollector()
        span = collector.start_span(trace_id="active-test")
        event = TraceEvent(event_type="request", provider="anthropic")
        collector.collect(event)
        assert len(span.events) == 1
        assert span.events[0].event_type == "request"

    def test_collect_to_specific_trace_id(self) -> None:
        collector = EventCollector()
        span_a = collector.start_span(trace_id="span-a")
        span_b = collector.start_span(trace_id="span-b")
        # Active span is now span_b; but we target span_a explicitly
        event = TraceEvent(event_type="tool_call", provider="openai")
        collector.collect(event, trace_id="span-a")
        assert len(span_a.events) == 1
        assert len(span_b.events) == 0

    def test_collect_creates_span_when_none_active(self) -> None:
        collector = EventCollector()
        event = TraceEvent(event_type="error")
        collector.collect(event)
        traces = collector.get_all_traces()
        assert len(traces) == 1
        assert traces[0].events[0].event_type == "error"

    def test_get_trace_returns_none_for_missing(self) -> None:
        collector = EventCollector()
        assert collector.get_trace("nonexistent") is None

    def test_get_all_traces(self) -> None:
        collector = EventCollector()
        collector.start_span(trace_id="s1")
        collector.start_span(trace_id="s2")
        traces = collector.get_all_traces()
        assert len(traces) == 2
        trace_ids = {t.trace_id for t in traces}
        assert trace_ids == {"s1", "s2"}

    def test_clear_resets_state(self) -> None:
        collector = EventCollector()
        span = collector.start_span(trace_id="to-clear")
        collector.collect(TraceEvent(event_type="request"))
        assert len(span.events) == 1

        collector.clear()
        assert collector.get_trace("to-clear") is None
        assert collector.get_all_traces() == []

    def test_to_dict_full_serialization(self) -> None:
        collector = EventCollector()
        collector.start_span(trace_id="ser-test")
        collector.collect(
            TraceEvent(event_type="request", provider="anthropic", elapsed_ms=50.0)
        )
        collector.collect(
            TraceEvent(event_type="response", provider="anthropic", elapsed_ms=200.0)
        )

        d = collector.to_dict()
        assert d["total_spans"] == 1
        assert "ser-test" in d["spans"]
        span_dict = d["spans"]["ser-test"]
        assert span_dict["trace_id"] == "ser-test"
        assert span_dict["total_ms"] == 250.0
        assert span_dict["event_count"] == 2
        assert len(span_dict["events"]) == 2
