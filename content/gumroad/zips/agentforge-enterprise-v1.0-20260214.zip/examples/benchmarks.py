import asyncio

from benchmarks.run_benchmarks import run_benchmarks


async def main() -> None:
    await run_benchmarks()


if __name__ == "__main__":
    asyncio.run(main())
