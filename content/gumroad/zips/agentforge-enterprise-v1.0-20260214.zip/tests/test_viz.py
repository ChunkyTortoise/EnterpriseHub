"""Tests for agentforge.viz — FlowDiagram, MetricsDashboard, MessageInspector."""

from __future__ import annotations

from agentforge.tracing import EventCollector, TraceEvent, TraceSpan
from agentforge.viz import FlowDiagram, MessageInspector, MetricsDashboard

# --- Helpers ---


def _make_span(trace_id: str = "test-span") -> TraceSpan:
    """Create a TraceSpan with representative events."""
    span = TraceSpan(trace_id=trace_id)
    span.events = [
        TraceEvent(
            event_type="request",
            provider="anthropic",
            model="claude-sonnet-4-5-20250929",
            elapsed_ms=10.0,
        ),
        TraceEvent(
            event_type="tool_call",
            provider="anthropic",
            model="claude-sonnet-4-5-20250929",
            elapsed_ms=120.0,
        ),
        TraceEvent(
            event_type="response",
            provider="openai",
            model="gpt-4o",
            elapsed_ms=280.0,
        ),
    ]
    return span


def _make_collector() -> EventCollector:
    """Create an EventCollector with two populated traces."""
    collector = EventCollector()
    span1 = collector.start_span(trace_id="t1")
    span1.events = [
        TraceEvent(
            event_type="request",
            provider="anthropic",
            model="claude-sonnet-4-5-20250929",
            elapsed_ms=50.0,
        ),
        TraceEvent(
            event_type="response",
            provider="anthropic",
            model="claude-sonnet-4-5-20250929",
            elapsed_ms=200.0,
        ),
    ]
    span2 = collector.start_span(trace_id="t2")
    span2.events = [
        TraceEvent(
            event_type="request",
            provider="openai",
            model="gpt-4o",
            elapsed_ms=30.0,
        ),
        TraceEvent(
            event_type="response",
            provider="openai",
            model="gpt-4o",
            elapsed_ms=180.0,
        ),
    ]
    return collector


# --- FlowDiagram tests ---


class TestFlowDiagram:
    def test_mermaid_output_contains_graph_lr(self) -> None:
        diagram = FlowDiagram(_make_span())
        mermaid = diagram.to_mermaid()
        assert mermaid.startswith("graph LR")

    def test_mermaid_nodes_for_each_event(self) -> None:
        span = _make_span()
        diagram = FlowDiagram(span)
        mermaid = diagram.to_mermaid()
        for i in range(len(span.events)):
            assert f"E{i}[" in mermaid

    def test_mermaid_edges_between_consecutive_events(self) -> None:
        span = _make_span()
        diagram = FlowDiagram(span)
        mermaid = diagram.to_mermaid()
        assert "E0 --> E1" in mermaid
        assert "E1 --> E2" in mermaid

    def test_graphviz_dot_output(self) -> None:
        diagram = FlowDiagram(_make_span())
        dot = diagram.to_graphviz_dot()
        assert dot.startswith("digraph trace {")
        assert "rankdir=LR;" in dot
        assert "E0 -> E1;" in dot
        assert "E1 -> E2;" in dot
        assert dot.strip().endswith("}")

    def test_provider_groups(self) -> None:
        diagram = FlowDiagram(_make_span())
        groups = diagram.get_provider_groups()
        assert "anthropic" in groups
        assert "openai" in groups
        assert len(groups["anthropic"]) == 2
        assert len(groups["openai"]) == 1

    def test_latency_breakdown(self) -> None:
        diagram = FlowDiagram(_make_span())
        breakdown = diagram.get_latency_breakdown()
        assert breakdown["anthropic"] == 130.0  # 10 + 120
        assert breakdown["openai"] == 280.0


# --- MetricsDashboard tests ---


class TestMetricsDashboard:
    def test_empty_collector_summary(self) -> None:
        collector = EventCollector()
        dashboard = MetricsDashboard(collector)
        summary = dashboard.get_summary()
        assert summary["total_traces"] == 0
        assert summary["total_events"] == 0
        assert summary["total_latency_ms"] == 0.0
        assert summary["avg_latency_ms"] == 0.0
        assert summary["unique_providers"] == []
        assert summary["unique_models"] == []

    def test_summary_with_traces(self) -> None:
        dashboard = MetricsDashboard(_make_collector())
        summary = dashboard.get_summary()
        assert summary["total_traces"] == 2
        assert summary["total_events"] == 4
        assert summary["total_latency_ms"] == 460.0  # 250 + 210
        assert summary["avg_latency_ms"] == 230.0
        assert "anthropic" in summary["unique_providers"]
        assert "openai" in summary["unique_providers"]

    def test_trace_table_rows(self) -> None:
        dashboard = MetricsDashboard(_make_collector())
        rows = dashboard.get_trace_table()
        assert len(rows) == 2
        ids = {r["trace_id"] for r in rows}
        assert ids == {"t1", "t2"}
        for row in rows:
            assert "events" in row
            assert "total_ms" in row
            assert "providers" in row

    def test_unique_providers_and_models(self) -> None:
        dashboard = MetricsDashboard(_make_collector())
        summary = dashboard.get_summary()
        assert sorted(summary["unique_providers"]) == ["anthropic", "openai"]
        assert sorted(summary["unique_models"]) == [
            "claude-sonnet-4-5-20250929",
            "gpt-4o",
        ]


# --- MessageInspector tests ---


class TestMessageInspector:
    def test_get_event_details(self) -> None:
        span = _make_span()
        inspector = MessageInspector(span)
        details = inspector.get_event_details(0)
        assert details is not None
        assert details["index"] == 0
        assert details["event_type"] == "request"
        assert details["provider"] == "anthropic"
        assert "pct_of_total" in details

    def test_get_event_details_out_of_range(self) -> None:
        inspector = MessageInspector(_make_span())
        assert inspector.get_event_details(-1) is None
        assert inspector.get_event_details(99) is None

    def test_filter_by_type(self) -> None:
        inspector = MessageInspector(_make_span())
        requests = inspector.filter_by_type("request")
        assert len(requests) == 1
        assert requests[0]["event_type"] == "request"

    def test_filter_by_provider(self) -> None:
        inspector = MessageInspector(_make_span())
        openai_events = inspector.filter_by_provider("openai")
        assert len(openai_events) == 1
        assert openai_events[0]["provider"] == "openai"

    def test_timeline(self) -> None:
        span = _make_span()
        inspector = MessageInspector(span)
        timeline = inspector.get_timeline()
        assert len(timeline) == 3
        assert timeline[0]["index"] == 0
        assert timeline[0]["type"] == "request"
        assert timeline[1]["index"] == 1
        assert timeline[2]["ms"] == 280.0
