"""Tests for the ReAct agent loop."""

from __future__ import annotations

from agentforge.react_agent import AgentTrace, ReActAgent, ReActStep, Thought
from agentforge.tools import ToolCall, ToolRegistry
from agentforge.tracing import EventCollector


# ---- Helpers ----


def _make_registry_with_tools() -> ToolRegistry:
    """Create a registry with simple test tools."""
    reg = ToolRegistry()
    reg.register(
        "add",
        "Add two numbers",
        {
            "type": "object",
            "properties": {"a": {"type": "number"}, "b": {"type": "number"}},
        },
        handler=lambda a, b: float(a) + float(b),
    )
    reg.register(
        "multiply",
        "Multiply two numbers",
        {
            "type": "object",
            "properties": {"a": {"type": "number"}, "b": {"type": "number"}},
        },
        handler=lambda a, b: float(a) * float(b),
    )
    reg.register(
        "lookup",
        "Look up a value",
        {"type": "object", "properties": {"key": {"type": "string"}}},
        handler=lambda key: {"price": 100, "name": "Widget"}.get(key, "unknown"),
    )
    return reg


def _single_step_reason(goal, history):
    """Reason function that immediately returns a final answer."""
    return (Thought(text="I know the answer", confidence=1.0), None, "42")


def _two_step_reason(goal, history):
    """Reason function: first step calls add, second returns answer."""
    if len(history) == 0:
        return (
            Thought(text="Need to add 2+3"),
            ToolCall(name="add", arguments={"a": 2, "b": 3}, call_id="c1"),
            None,
        )
    return (Thought(text="Got the result"), None, history[0].observation)


def _multi_step_reason(goal, history):
    """Three-step reasoning: add, multiply, then answer."""
    if len(history) == 0:
        return (
            Thought(text="Step 1: add"),
            ToolCall(name="add", arguments={"a": 10, "b": 20}, call_id="c1"),
            None,
        )
    if len(history) == 1:
        return (
            Thought(text="Step 2: multiply"),
            ToolCall(name="multiply", arguments={"a": 5, "b": 6}, call_id="c2"),
            None,
        )
    return (
        Thought(text="Done"),
        None,
        f"add={history[0].observation}, mul={history[1].observation}",
    )


# ---- Tests ----


class TestReActAgentBasic:
    def test_single_step_final_answer(self):
        agent = ReActAgent(ToolRegistry(), _single_step_reason)
        trace = agent.run("What is the answer?")
        assert trace.success is True
        assert trace.final_answer == "42"
        assert len(trace.steps) == 1
        assert trace.goal == "What is the answer?"

    def test_two_step_with_tool(self):
        reg = _make_registry_with_tools()
        agent = ReActAgent(reg, _two_step_reason)
        trace = agent.run("Add 2 and 3")
        assert trace.success is True
        assert trace.final_answer == "5.0"
        assert len(trace.steps) == 2
        assert trace.steps[0].action is not None
        assert trace.steps[0].action.name == "add"

    def test_multi_step_reasoning(self):
        reg = _make_registry_with_tools()
        agent = ReActAgent(reg, _multi_step_reason)
        trace = agent.run("Compute values")
        assert trace.success is True
        assert len(trace.steps) == 3
        assert "add=30.0" in trace.final_answer
        assert "mul=30.0" in trace.final_answer

    def test_total_ms_tracked(self):
        agent = ReActAgent(ToolRegistry(), _single_step_reason)
        trace = agent.run("Quick")
        assert trace.total_ms >= 0
        assert trace.steps[0].elapsed_ms >= 0

    def test_step_numbers_sequential(self):
        reg = _make_registry_with_tools()
        agent = ReActAgent(reg, _multi_step_reason)
        trace = agent.run("Go")
        for i, step in enumerate(trace.steps, 1):
            assert step.step_number == i


class TestReActAgentEmptyGoal:
    def test_empty_string(self):
        agent = ReActAgent(ToolRegistry(), _single_step_reason)
        trace = agent.run("")
        assert trace.success is False
        assert trace.final_answer == ""
        assert len(trace.steps) == 0

    def test_whitespace_only(self):
        agent = ReActAgent(ToolRegistry(), _single_step_reason)
        trace = agent.run("   ")
        assert trace.success is False
        assert len(trace.steps) == 0


class TestReActAgentMaxIterations:
    def test_hits_max_iterations(self):
        def never_finishes(goal, history):
            n = len(history)
            return (
                Thought(text=f"Thinking step {n}"),
                ToolCall(name="add", arguments={"a": n, "b": 1}, call_id=f"c{n}"),
                None,
            )

        reg = _make_registry_with_tools()
        agent = ReActAgent(reg, never_finishes, max_iterations=5)
        trace = agent.run("Never ends")
        assert trace.success is False
        assert len(trace.steps) == 5

    def test_max_iterations_one(self):
        def no_answer(goal, history):
            return (Thought(text="Thinking"), None, None)

        agent = ReActAgent(ToolRegistry(), no_answer, max_iterations=1)
        trace = agent.run("One shot")
        assert len(trace.steps) == 1
        assert trace.success is False

    def test_custom_max_iterations(self):
        call_count = 0

        def counting_reason(goal, history):
            nonlocal call_count
            call_count += 1
            if call_count >= 3:
                return (Thought(text="Done"), None, "finished")
            return (Thought(text=f"Step {call_count}"), None, None)

        agent = ReActAgent(ToolRegistry(), counting_reason, max_iterations=20)
        trace = agent.run("Count")
        assert trace.success is True
        assert len(trace.steps) == 3


class TestReActAgentLoopDetection:
    def test_detects_repeated_thought_action(self):
        call = 0

        def looping_reason(goal, history):
            nonlocal call
            call += 1
            return (
                Thought(text="Same thought"),
                ToolCall(name="add", arguments={"a": 1, "b": 2}, call_id=f"c{call}"),
                None,
            )

        reg = _make_registry_with_tools()
        agent = ReActAgent(reg, looping_reason, max_iterations=20)
        trace = agent.run("Loop test")
        assert trace.success is False
        assert "loop" in trace.final_answer.lower()
        assert len(trace.steps) < 20

    def test_no_false_positive_loop(self):
        def varying_reason(goal, history):
            n = len(history)
            if n >= 3:
                return (Thought(text="Done"), None, "result")
            return (
                Thought(text=f"Different thought {n}"),
                ToolCall(name="add", arguments={"a": n, "b": n + 1}, call_id=f"c{n}"),
                None,
            )

        reg = _make_registry_with_tools()
        agent = ReActAgent(reg, varying_reason)
        trace = agent.run("Varied")
        assert trace.success is True


class TestReActAgentErrorRecovery:
    def test_tool_not_found(self):
        def calls_missing_tool(goal, history):
            if not history:
                return (
                    Thought(text="Call missing"),
                    ToolCall(name="nonexistent", arguments={}, call_id="c1"),
                    None,
                )
            return (Thought(text="Done"), None, "recovered")

        agent = ReActAgent(ToolRegistry(), calls_missing_tool)
        trace = agent.run("Missing tool")
        assert trace.success is True
        assert "Tool error" in trace.steps[0].observation

    def test_tool_execution_error(self):
        reg = ToolRegistry()
        reg.register(
            "fail",
            "Always fails",
            {},
            handler=lambda: (_ for _ in ()).throw(RuntimeError("boom")),
        )

        def calls_failing_tool(goal, history):
            if not history:
                return (
                    Thought(text="Try failing"),
                    ToolCall(name="fail", arguments={}, call_id="c1"),
                    None,
                )
            return (Thought(text="Done"), None, "handled")

        agent = ReActAgent(reg, calls_failing_tool)
        trace = agent.run("Error handling")
        assert trace.success is True
        assert "error" in trace.steps[0].observation.lower()

    def test_reason_fn_exception(self):
        call_count = 0

        def exploding_reason(goal, history):
            nonlocal call_count
            call_count += 1
            raise RuntimeError("reason_fn exploded")

        agent = ReActAgent(ToolRegistry(), exploding_reason)
        trace = agent.run("Explode")
        assert trace.success is False
        assert len(trace.steps) == 1
        assert "Error" in trace.steps[0].thought.text


class TestReActAgentNoAction:
    def test_step_with_no_action(self):
        def no_action_then_answer(goal, history):
            if not history:
                return (Thought(text="Thinking without acting"), None, None)
            return (Thought(text="Answer"), None, "done")

        agent = ReActAgent(ToolRegistry(), no_action_then_answer)
        trace = agent.run("Think only")
        assert trace.success is True
        assert trace.steps[0].action is None
        assert trace.steps[0].observation == "No action taken."


class TestReActAgentEventCollector:
    def test_events_emitted(self):
        collector = EventCollector()
        collector.start_span("react-test")
        agent = ReActAgent(
            ToolRegistry(), _single_step_reason, event_collector=collector
        )
        agent.run("Traced goal")
        span = collector.get_trace("react-test")
        assert span is not None
        assert span.event_count >= 3  # start, thought, final_answer, end
        event_types = [e.event_type for e in span.events]
        assert "react_start" in event_types
        assert "react_final_answer" in event_types
        assert "react_end" in event_types

    def test_events_with_tool_calls(self):
        collector = EventCollector()
        collector.start_span("tool-test")
        reg = _make_registry_with_tools()
        agent = ReActAgent(reg, _two_step_reason, event_collector=collector)
        agent.run("Add things")
        span = collector.get_trace("tool-test")
        event_types = [e.event_type for e in span.events]
        assert "react_action" in event_types
        assert "react_observation" in event_types

    def test_no_collector_ok(self):
        agent = ReActAgent(ToolRegistry(), _single_step_reason, event_collector=None)
        trace = agent.run("No collector")
        assert trace.success is True


class TestReActDataclasses:
    def test_thought_defaults(self):
        t = Thought(text="hello")
        assert t.text == "hello"
        assert t.confidence == 0.0

    def test_react_step_defaults(self):
        step = ReActStep(step_number=1, thought=Thought(text="t"))
        assert step.action is None
        assert step.observation == ""
        assert step.elapsed_ms == 0.0

    def test_agent_trace_defaults(self):
        trace = AgentTrace(goal="g")
        assert trace.steps == []
        assert trace.final_answer == ""
        assert trace.total_ms == 0.0
        assert trace.success is False
