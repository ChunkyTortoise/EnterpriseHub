"""Tests for agent memory systems."""

from __future__ import annotations

import time

from agentforge.memory import (
    ConversationMemory,
    MemoryEntry,
    MemorySearchResult,
    SlidingWindowMemory,
    SummaryMemory,
    _estimate_tokens,
)


# ---- ConversationMemory ----


class TestConversationMemory:
    def test_add_and_retrieve(self):
        mem = ConversationMemory()
        entry = mem.add("user", "Hello world")
        assert entry.role == "user"
        assert entry.content == "Hello world"
        assert len(mem) == 1

    def test_add_with_metadata(self):
        mem = ConversationMemory()
        entry = mem.add("user", "test", metadata={"key": "value"})
        assert entry.metadata == {"key": "value"}

    def test_entries_returns_copy(self):
        mem = ConversationMemory()
        mem.add("user", "msg")
        entries = mem.entries
        entries.clear()
        assert len(mem) == 1

    def test_timestamp_ordering(self):
        mem = ConversationMemory()
        mem.add("user", "first")
        time.sleep(0.01)
        mem.add("assistant", "second")
        entries = mem.entries
        assert entries[0].timestamp <= entries[1].timestamp

    def test_clear(self):
        mem = ConversationMemory()
        mem.add("user", "a")
        mem.add("user", "b")
        mem.clear()
        assert len(mem) == 0

    def test_get_context_all_fit(self):
        mem = ConversationMemory()
        mem.add("user", "Hello")
        mem.add("assistant", "Hi there")
        context = mem.get_context(max_tokens=4000)
        assert len(context) == 2
        assert context[0].content == "Hello"
        assert context[1].content == "Hi there"

    def test_get_context_token_budget(self):
        mem = ConversationMemory()
        # Each ~25 chars = ~6 tokens
        for i in range(100):
            mem.add("user", f"Message number {i:03d} padding")
        context = mem.get_context(max_tokens=20)
        assert len(context) < 100
        assert len(context) > 0
        # Should be most recent messages
        assert context[-1].content == mem.entries[-1].content

    def test_get_context_empty(self):
        mem = ConversationMemory()
        assert mem.get_context() == []


class TestSummarize:
    def test_summarize_basic(self):
        mem = ConversationMemory()
        entries = [
            MemoryEntry(
                role="user", content="The weather in San Francisco is foggy today"
            ),
            MemoryEntry(
                role="assistant", content="San Francisco often has fog in the mornings"
            ),
            MemoryEntry(
                role="user", content="What about the temperature in San Francisco?"
            ),
        ]
        summary = mem.summarize(entries)
        assert isinstance(summary, str)
        assert len(summary) > 0

    def test_summarize_empty(self):
        mem = ConversationMemory()
        assert mem.summarize([]) == ""

    def test_summarize_single_message(self):
        mem = ConversationMemory()
        entries = [MemoryEntry(role="user", content="Hello world")]
        summary = mem.summarize(entries)
        assert len(summary) > 0

    def test_summarize_includes_roles(self):
        mem = ConversationMemory()
        entries = [
            MemoryEntry(
                role="user", content="Important data analysis for machine learning"
            ),
            MemoryEntry(
                role="assistant", content="Machine learning models need clean data"
            ),
        ]
        summary = mem.summarize(entries)
        assert "assistant" in summary or "user" in summary


class TestSearch:
    def test_search_relevant(self):
        mem = ConversationMemory()
        mem.add("user", "Python programming language guide")
        mem.add("user", "JavaScript framework comparison")
        mem.add("user", "Python data science libraries numpy pandas")
        results = mem.search("Python programming")
        assert len(results) > 0
        assert isinstance(results[0], MemorySearchResult)
        assert results[0].score > 0
        # Python entries should rank higher
        assert (
            "Python" in results[0].entry.content
            or "python" in results[0].entry.content.lower()
        )

    def test_search_empty_memory(self):
        mem = ConversationMemory()
        assert mem.search("anything") == []

    def test_search_empty_query(self):
        mem = ConversationMemory()
        mem.add("user", "some content")
        assert mem.search("") == []
        assert mem.search("   ") == []

    def test_search_top_k(self):
        mem = ConversationMemory()
        for i in range(10):
            mem.add("user", f"Document about topic {i} with details")
        results = mem.search("topic", top_k=3)
        assert len(results) <= 3

    def test_search_scores_sorted(self):
        mem = ConversationMemory()
        mem.add("user", "The cat sat on the mat")
        mem.add("user", "Dogs love playing fetch in the park")
        mem.add("user", "The cat and the dog played together")
        results = mem.search("cat")
        if len(results) > 1:
            for i in range(len(results) - 1):
                assert results[i].score >= results[i + 1].score


# ---- SlidingWindowMemory ----


class TestSlidingWindowMemory:
    def test_window_keeps_recent(self):
        mem = SlidingWindowMemory(window_size=3)
        for i in range(5):
            mem.add("user", f"msg-{i}")
        assert len(mem) == 3
        contents = [e.content for e in mem.entries]
        assert contents == ["msg-2", "msg-3", "msg-4"]

    def test_window_within_limit(self):
        mem = SlidingWindowMemory(window_size=10)
        for i in range(5):
            mem.add("user", f"msg-{i}")
        assert len(mem) == 5

    def test_window_size_property(self):
        mem = SlidingWindowMemory(window_size=42)
        assert mem.window_size == 42

    def test_window_single_message(self):
        mem = SlidingWindowMemory(window_size=1)
        mem.add("user", "first")
        mem.add("user", "second")
        assert len(mem) == 1
        assert mem.entries[0].content == "second"


# ---- SummaryMemory ----


class TestSummaryMemory:
    def test_auto_summarize_on_overflow(self):
        mem = SummaryMemory(threshold=5)
        for i in range(7):
            mem.add("user", f"Important message about topic number {i}")
        # Should have compacted: fewer entries than added
        assert len(mem) < 7

    def test_no_summarize_under_threshold(self):
        mem = SummaryMemory(threshold=10)
        for i in range(5):
            mem.add("user", f"msg-{i}")
        assert len(mem) == 5

    def test_summary_entry_has_metadata(self):
        mem = SummaryMemory(threshold=4)
        for i in range(6):
            mem.add("user", f"Content about data science topic {i}")
        # First entry should be summary
        first = mem.entries[0]
        assert first.metadata.get("is_summary") is True
        assert first.metadata.get("summarized_count", 0) > 0

    def test_threshold_property(self):
        mem = SummaryMemory(threshold=15)
        assert mem.threshold == 15


# ---- Utility ----


class TestEstimateTokens:
    def test_basic(self):
        assert _estimate_tokens("hello world") >= 1

    def test_empty(self):
        assert _estimate_tokens("") == 1

    def test_longer_text(self):
        text = "a" * 400
        assert _estimate_tokens(text) == 100
