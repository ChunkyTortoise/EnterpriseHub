"""Tests for agent memory store and conversation context."""

from __future__ import annotations

import time


from agentforge.agent_memory import (
    AgentMemoryStore,
    ConversationContext,
    AgentMemoryEntry,
)


# ---------------------------------------------------------------------------
# AgentMemoryEntry
# ---------------------------------------------------------------------------


class TestAgentMemoryEntry:
    """Tests for the AgentMemoryEntry dataclass."""

    def test_create_entry(self) -> None:
        entry = AgentMemoryEntry(key="k1", value="v1")
        assert entry.key == "k1"
        assert entry.value == "v1"
        assert entry.ttl_seconds == 0.0
        assert entry.relevance_score == 0.0
        assert entry.metadata == {}

    def test_not_expired_when_no_ttl(self) -> None:
        entry = AgentMemoryEntry(key="k1", value="v1", ttl_seconds=0)
        assert not entry.is_expired

    def test_not_expired_within_ttl(self) -> None:
        entry = AgentMemoryEntry(key="k1", value="v1", ttl_seconds=60)
        assert not entry.is_expired

    def test_expired_past_ttl(self) -> None:
        entry = AgentMemoryEntry(
            key="k1",
            value="v1",
            timestamp=time.time() - 10,
            ttl_seconds=5,
        )
        assert entry.is_expired


# ---------------------------------------------------------------------------
# AgentMemoryStore — store / retrieve
# ---------------------------------------------------------------------------


class TestAgentMemoryStoreBasic:
    """Basic store and retrieve operations."""

    def test_store_and_retrieve(self) -> None:
        store = AgentMemoryStore()
        store.store("greeting", "hello")
        entry = store.retrieve("greeting")
        assert entry is not None
        assert entry.value == "hello"

    def test_retrieve_missing_key(self) -> None:
        store = AgentMemoryStore()
        assert store.retrieve("nope") is None

    def test_store_overwrites_existing(self) -> None:
        store = AgentMemoryStore()
        store.store("k", "v1")
        store.store("k", "v2")
        entry = store.retrieve("k")
        assert entry is not None
        assert entry.value == "v2"

    def test_size_property(self) -> None:
        store = AgentMemoryStore()
        assert store.size == 0
        store.store("a", 1)
        store.store("b", 2)
        assert store.size == 2

    def test_clear(self) -> None:
        store = AgentMemoryStore()
        store.store("a", 1)
        store.store("b", 2)
        store.clear()
        assert store.size == 0
        assert store.retrieve("a") is None

    def test_store_with_metadata(self) -> None:
        store = AgentMemoryStore()
        entry = store.store("k", "v", metadata={"source": "test"})
        assert entry.metadata == {"source": "test"}

    def test_store_returns_memory_entry(self) -> None:
        store = AgentMemoryStore()
        entry = store.store("k", "v", relevance_score=0.9)
        assert isinstance(entry, AgentMemoryEntry)
        assert entry.relevance_score == 0.9


# ---------------------------------------------------------------------------
# TTL expiration
# ---------------------------------------------------------------------------


class TestAgentMemoryStoreTTL:
    """TTL-based expiration tests."""

    def test_retrieve_expired_returns_none(self) -> None:
        store = AgentMemoryStore()
        store.store("temp", "data", ttl_seconds=0.01)
        time.sleep(0.05)
        assert store.retrieve("temp") is None

    def test_retrieve_not_expired(self) -> None:
        store = AgentMemoryStore()
        store.store("temp", "data", ttl_seconds=60)
        assert store.retrieve("temp") is not None

    def test_evict_expired(self) -> None:
        store = AgentMemoryStore()
        store.store("a", 1, ttl_seconds=0.01)
        store.store("b", 2, ttl_seconds=0.01)
        store.store("c", 3, ttl_seconds=600)
        time.sleep(0.05)
        evicted = store.evict_expired()
        assert evicted == 2
        assert store.size == 1

    def test_evict_expired_returns_zero_when_none_expired(self) -> None:
        store = AgentMemoryStore()
        store.store("a", 1, ttl_seconds=600)
        assert store.evict_expired() == 0


# ---------------------------------------------------------------------------
# LRU eviction
# ---------------------------------------------------------------------------


class TestAgentMemoryStoreLRU:
    """LRU eviction with max capacity."""

    def test_lru_eviction(self) -> None:
        store = AgentMemoryStore(max_capacity=2)
        store.store("a", 1)
        store.store("b", 2)
        store.store("c", 3)  # should evict "a"
        assert store.retrieve("a") is None
        assert store.retrieve("b") is not None
        assert store.retrieve("c") is not None

    def test_lru_updates_on_access(self) -> None:
        store = AgentMemoryStore(max_capacity=2)
        store.store("a", 1)
        store.store("b", 2)
        store.retrieve("a")  # touch "a", making "b" the LRU
        store.store("c", 3)  # should evict "b"
        assert store.retrieve("a") is not None
        assert store.retrieve("b") is None
        assert store.retrieve("c") is not None

    def test_unlimited_capacity(self) -> None:
        store = AgentMemoryStore(max_capacity=0)
        for i in range(100):
            store.store(f"k{i}", i)
        assert store.size == 100


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


class TestAgentMemoryStoreSearch:
    """Relevance-based search tests."""

    def test_search_keyword_match(self) -> None:
        store = AgentMemoryStore()
        store.store("weather_sf", "sunny in San Francisco", relevance_score=0.8)
        store.store("weather_ny", "rain in New York", relevance_score=0.6)
        store.store("stocks", "AAPL up 2%", relevance_score=0.9)
        results = store.search("weather")
        assert len(results) == 2
        # Highest relevance first
        assert results[0].key == "weather_sf"

    def test_search_top_k(self) -> None:
        store = AgentMemoryStore()
        for i in range(10):
            store.store(f"item_{i}", f"test item {i}", relevance_score=float(i))
        results = store.search("item", top_k=3)
        assert len(results) == 3
        assert results[0].relevance_score == 9.0

    def test_search_empty_query(self) -> None:
        store = AgentMemoryStore()
        store.store("k", "v")
        assert store.search("") == []

    def test_search_no_match(self) -> None:
        store = AgentMemoryStore()
        store.store("k", "v")
        assert store.search("zzzzz") == []

    def test_search_excludes_expired(self) -> None:
        store = AgentMemoryStore()
        store.store("fresh", "test data", ttl_seconds=600, relevance_score=0.5)
        store.store("stale", "test data", ttl_seconds=0.01, relevance_score=0.9)
        time.sleep(0.05)
        results = store.search("test")
        assert len(results) == 1
        assert results[0].key == "fresh"


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


class TestAgentMemoryStoreSerialization:
    """Serialization tests."""

    def test_to_dict(self) -> None:
        store = AgentMemoryStore(max_capacity=10)
        store.store("a", 1, relevance_score=0.5)
        store.store("b", 2, relevance_score=0.8)
        data = store.to_dict()
        assert data["size"] == 2
        assert data["max_capacity"] == 10
        assert len(data["entries"]) == 2

    def test_to_dict_empty(self) -> None:
        store = AgentMemoryStore()
        data = store.to_dict()
        assert data["size"] == 0
        assert data["entries"] == []


# ---------------------------------------------------------------------------
# ConversationContext
# ---------------------------------------------------------------------------


class TestConversationContext:
    """Conversation context management tests."""

    def test_add_and_get_history(self) -> None:
        ctx = ConversationContext()
        ctx.add_turn("user", "Hello")
        ctx.add_turn("assistant", "Hi there!")
        history = ctx.get_history()
        assert len(history) == 2
        assert history[0].role == "user"
        assert history[1].content == "Hi there!"

    def test_get_history_last_n(self) -> None:
        ctx = ConversationContext()
        for i in range(5):
            ctx.add_turn("user", f"msg {i}")
        history = ctx.get_history(last_n=2)
        assert len(history) == 2
        assert history[0].content == "msg 3"

    def test_max_turns(self) -> None:
        ctx = ConversationContext(max_turns=3)
        for i in range(5):
            ctx.add_turn("user", f"msg {i}")
        assert ctx.turn_count == 3
        history = ctx.get_history()
        assert history[0].content == "msg 2"

    def test_get_summary(self) -> None:
        ctx = ConversationContext(summary_window=2)
        ctx.add_turn("user", "What's the weather?")
        ctx.add_turn("assistant", "It's sunny.")
        ctx.add_turn("user", "Thanks!")
        summary = ctx.get_summary()
        assert "assistant: It's sunny." in summary
        assert "user: Thanks!" in summary
        # First turn should not be in the 2-turn window
        assert "What's the weather?" not in summary

    def test_get_summary_empty(self) -> None:
        ctx = ConversationContext()
        assert ctx.get_summary() == ""

    def test_active_topic_from_user(self) -> None:
        ctx = ConversationContext()
        ctx.add_turn("user", "Tell me about Python")
        ctx.add_turn("assistant", "Python is great")
        assert ctx.active_topic == "Tell me about Python"

    def test_active_topic_fallback(self) -> None:
        ctx = ConversationContext()
        ctx.add_turn("system", "You are helpful")
        assert ctx.active_topic == "You are helpful"

    def test_active_topic_empty(self) -> None:
        ctx = ConversationContext()
        assert ctx.active_topic == ""


# ---------------------------------------------------------------------------
# Entity extraction
# ---------------------------------------------------------------------------


class TestEntityExtraction:
    """Entity extraction from text."""

    def test_extract_emails(self) -> None:
        entities = ConversationContext.extract_entities(
            "Contact alice@example.com for info"
        )
        assert "alice@example.com" in entities

    def test_extract_numbers(self) -> None:
        entities = ConversationContext.extract_entities(
            "The price is $500,000 for 3 bedrooms"
        )
        assert any("500" in e for e in entities)

    def test_extract_capitalized_names(self) -> None:
        entities = ConversationContext.extract_entities(
            "Meeting with John Smith tomorrow"
        )
        assert any("John" in e for e in entities)

    def test_extract_filters_stop_words(self) -> None:
        entities = ConversationContext.extract_entities("The cat sat on a mat")
        assert "The" not in entities

    def test_extract_empty_text(self) -> None:
        assert ConversationContext.extract_entities("") == []

    def test_extract_deduplicates(self) -> None:
        entities = ConversationContext.extract_entities(
            "alice@example.com and alice@example.com again"
        )
        assert entities.count("alice@example.com") == 1
