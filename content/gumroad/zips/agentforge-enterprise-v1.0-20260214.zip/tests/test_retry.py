"""Tests for retry_with_backoff decorator."""

from unittest.mock import AsyncMock, patch

import pytest

from agentforge.retry import retry_with_backoff

# ── Basic Retry Behavior ────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_succeeds_without_retry():
    """Function that succeeds on first call is not retried."""
    call_count = 0

    @retry_with_backoff(max_retries=3, base_delay=0.01)
    async def succeed():
        nonlocal call_count
        call_count += 1
        return "ok"

    result = await succeed()
    assert result == "ok"
    assert call_count == 1


@pytest.mark.asyncio
async def test_retries_on_retryable_exception():
    """Retryable exception triggers retry and eventually succeeds."""
    call_count = 0

    @retry_with_backoff(
        max_retries=3,
        base_delay=0.01,
        retryable_exceptions=[ConnectionError],
    )
    async def flaky():
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise ConnectionError("connection refused")
        return "recovered"

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await flaky()

    assert result == "recovered"
    assert call_count == 3


@pytest.mark.asyncio
async def test_max_retries_exhausted_raises_original():
    """After max_retries, the original exception is raised."""

    @retry_with_backoff(
        max_retries=2,
        base_delay=0.01,
        retryable_exceptions=[TimeoutError],
    )
    async def always_fails():
        raise TimeoutError("timed out")

    with patch("asyncio.sleep", new_callable=AsyncMock):
        with pytest.raises(TimeoutError, match="timed out"):
            await always_fails()


# ── Non-Retryable Errors ────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_non_retryable_error_raises_immediately():
    """Non-retryable exceptions are raised without retry."""
    call_count = 0

    @retry_with_backoff(
        max_retries=3,
        base_delay=0.01,
        retryable_exceptions=[ConnectionError],
    )
    async def auth_fail():
        nonlocal call_count
        call_count += 1
        raise ValueError("bad input")

    with pytest.raises(ValueError, match="bad input"):
        await auth_fail()

    assert call_count == 1


# ── Backoff Timing ──────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_exponential_backoff_delays():
    """Delays increase exponentially: base_delay * 2^attempt."""
    delays_recorded: list[float] = []

    @retry_with_backoff(
        max_retries=3,
        base_delay=1.0,
        max_delay=60.0,
        jitter=False,
        retryable_exceptions=[ConnectionError],
    )
    async def always_fails():
        raise ConnectionError("fail")

    async def capture_sleep(delay: float) -> None:
        delays_recorded.append(delay)

    with patch("asyncio.sleep", side_effect=capture_sleep):
        with pytest.raises(ConnectionError):
            await always_fails()

    # Attempt 0: delay = min(1.0 * 2^0, 60) = 1.0
    # Attempt 1: delay = min(1.0 * 2^1, 60) = 2.0
    # Attempt 2: delay = min(1.0 * 2^2, 60) = 4.0
    assert len(delays_recorded) == 3
    assert delays_recorded[0] == 1.0
    assert delays_recorded[1] == 2.0
    assert delays_recorded[2] == 4.0


@pytest.mark.asyncio
async def test_max_delay_cap():
    """Delay is capped at max_delay."""
    delays_recorded: list[float] = []

    @retry_with_backoff(
        max_retries=2,
        base_delay=50.0,
        max_delay=10.0,
        jitter=False,
        retryable_exceptions=[ConnectionError],
    )
    async def always_fails():
        raise ConnectionError("fail")

    async def capture_sleep(delay: float) -> None:
        delays_recorded.append(delay)

    with patch("asyncio.sleep", side_effect=capture_sleep):
        with pytest.raises(ConnectionError):
            await always_fails()

    # base_delay=50 > max_delay=10, so all delays capped at 10
    for delay in delays_recorded:
        assert delay == 10.0


# ── Jitter ──────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_jitter_adds_randomness():
    """When jitter=True, delays have random component added."""
    delays_run1: list[float] = []
    delays_run2: list[float] = []

    @retry_with_backoff(
        max_retries=2,
        base_delay=1.0,
        max_delay=60.0,
        jitter=True,
        retryable_exceptions=[ConnectionError],
    )
    async def always_fails():
        raise ConnectionError("fail")

    async def capture_run1(delay: float) -> None:
        delays_run1.append(delay)

    async def capture_run2(delay: float) -> None:
        delays_run2.append(delay)

    with patch("asyncio.sleep", side_effect=capture_run1):
        with pytest.raises(ConnectionError):
            await always_fails()

    with patch("asyncio.sleep", side_effect=capture_run2):
        with pytest.raises(ConnectionError):
            await always_fails()

    # With jitter, delays should be >= base (no jitter) value
    # base values: 1.0, 2.0
    assert delays_run1[0] >= 1.0
    assert delays_run1[1] >= 2.0


# ── Custom Exceptions ───────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_custom_retryable_exceptions():
    """Custom exception types are retried."""
    call_count = 0

    class TransientError(Exception):
        pass

    @retry_with_backoff(
        max_retries=2,
        base_delay=0.01,
        retryable_exceptions=[TransientError],
    )
    async def flaky():
        nonlocal call_count
        call_count += 1
        if call_count < 2:
            raise TransientError("transient")
        return "ok"

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await flaky()

    assert result == "ok"
    assert call_count == 2


# ── Sync Function Support ──────────────────────────────────────────────────


def test_sync_function_retry():
    """Decorator works with synchronous functions too."""
    call_count = 0

    @retry_with_backoff(
        max_retries=2,
        base_delay=0.001,
        jitter=False,
        retryable_exceptions=[ConnectionError],
    )
    def flaky_sync():
        nonlocal call_count
        call_count += 1
        if call_count < 2:
            raise ConnectionError("fail")
        return "sync_ok"

    with patch("time.sleep"):
        result = flaky_sync()

    assert result == "sync_ok"
    assert call_count == 2


# ── Zero Retries ────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_zero_retries_raises_immediately():
    """max_retries=0 means no retries, raises on first failure."""
    call_count = 0

    @retry_with_backoff(
        max_retries=0,
        retryable_exceptions=[ConnectionError],
    )
    async def fails():
        nonlocal call_count
        call_count += 1
        raise ConnectionError("fail")

    with pytest.raises(ConnectionError):
        await fails()

    assert call_count == 1
