"""Multi-agent coordination: messaging, consensus, and handoff protocols.

Provides an agent mesh for registration and communication, consensus-based
decision making, and confidence-gated agent handoff.
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger("agentforge.multi_agent")


class MessageType(str, Enum):
    """Type of inter-agent message."""

    REQUEST = "request"
    RESPONSE = "response"
    BROADCAST = "broadcast"


class AgentStatus(str, Enum):
    """Agent operational status."""

    ACTIVE = "active"
    IDLE = "idle"
    BUSY = "busy"


@dataclass
class AgentMessage:
    """A message passed between agents."""

    sender: str
    recipient: str
    content: str
    message_type: MessageType = MessageType.REQUEST
    timestamp: float = field(default_factory=time.time)
    correlation_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])


@dataclass
class AgentRegistration:
    """Registration record for an agent in the mesh."""

    agent_id: str
    name: str
    capabilities: list[str] = field(default_factory=list)
    status: AgentStatus = AgentStatus.ACTIVE


class AgentMesh:
    """Registry and message bus for multi-agent coordination.

    Thread-safe agent mesh that supports:
    - Agent registration/unregistration
    - Directed messaging between agents
    - Broadcast messaging to all agents
    - Capability-based agent lookup

    Usage:
        mesh = AgentMesh()
        mesh.register("agent-1", "Researcher", ["search", "summarize"])
        mesh.register("agent-2", "Writer", ["compose", "edit"])
        mesh.send(AgentMessage(sender="agent-1", recipient="agent-2", content="Write report"))
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._agents: dict[str, AgentRegistration] = {}
        self._inboxes: dict[str, list[AgentMessage]] = {}

    def register(
        self,
        agent_id: str,
        name: str,
        capabilities: list[str] | None = None,
    ) -> AgentRegistration:
        """Register an agent in the mesh.

        Args:
            agent_id: Unique agent identifier.
            name: Human-readable agent name.
            capabilities: List of capability strings.

        Returns:
            The created AgentRegistration.

        Raises:
            ValueError: If agent_id is already registered.
        """
        with self._lock:
            if agent_id in self._agents:
                raise ValueError(f"Agent already registered: {agent_id}")
            reg = AgentRegistration(
                agent_id=agent_id,
                name=name,
                capabilities=capabilities or [],
            )
            self._agents[agent_id] = reg
            self._inboxes[agent_id] = []
        logger.debug("registered agent=%s name=%s", agent_id, name)
        return reg

    def unregister(self, agent_id: str) -> bool:
        """Remove an agent from the mesh.

        Args:
            agent_id: The agent to remove.

        Returns:
            True if the agent was found and removed, False otherwise.
        """
        with self._lock:
            if agent_id not in self._agents:
                return False
            del self._agents[agent_id]
            self._inboxes.pop(agent_id, None)
        logger.debug("unregistered agent=%s", agent_id)
        return True

    def send(self, message: AgentMessage) -> bool:
        """Send a message to a specific agent.

        Args:
            message: The message to deliver.

        Returns:
            True if the recipient exists and message was delivered.
        """
        with self._lock:
            if message.recipient not in self._agents:
                logger.warning("send failed: recipient=%s not found", message.recipient)
                return False
            self._inboxes[message.recipient].append(message)
        logger.debug(
            "delivered message from=%s to=%s", message.sender, message.recipient
        )
        return True

    def broadcast(self, sender: str, content: str) -> int:
        """Broadcast a message to all registered agents (except sender).

        Args:
            sender: The sending agent's ID.
            content: Message content.

        Returns:
            Number of agents the message was delivered to.
        """
        count = 0
        with self._lock:
            for agent_id in self._agents:
                if agent_id == sender:
                    continue
                msg = AgentMessage(
                    sender=sender,
                    recipient=agent_id,
                    content=content,
                    message_type=MessageType.BROADCAST,
                )
                self._inboxes[agent_id].append(msg)
                count += 1
        logger.debug("broadcast from=%s delivered=%d", sender, count)
        return count

    def get_by_capability(self, capability: str) -> list[AgentRegistration]:
        """Find agents that have a specific capability.

        Args:
            capability: The capability to search for.

        Returns:
            List of matching AgentRegistration objects.
        """
        with self._lock:
            return [
                reg for reg in self._agents.values() if capability in reg.capabilities
            ]

    def get_inbox(self, agent_id: str) -> list[AgentMessage]:
        """Retrieve and clear an agent's message inbox.

        Args:
            agent_id: The agent whose inbox to retrieve.

        Returns:
            List of messages (inbox is cleared after retrieval).
        """
        with self._lock:
            messages = list(self._inboxes.get(agent_id, []))
            if agent_id in self._inboxes:
                self._inboxes[agent_id] = []
        return messages

    def get_agent(self, agent_id: str) -> AgentRegistration | None:
        """Get an agent's registration by ID."""
        with self._lock:
            return self._agents.get(agent_id)

    @property
    def agent_count(self) -> int:
        """Number of registered agents."""
        with self._lock:
            return len(self._agents)


@dataclass
class Vote:
    """A single vote in a consensus round."""

    agent_id: str
    option: str
    confidence: float = 1.0


@dataclass
class ConsensusResult:
    """Result of a consensus resolution."""

    winner: str
    confidence: float
    vote_count: int
    dissenting_count: int


class ConsensusResolver:
    """Aggregate opinions from multiple agents to reach consensus.

    Supports majority voting and confidence-weighted voting.

    Usage:
        resolver = ConsensusResolver()
        resolver.collect_vote("agent-1", "option-a", confidence=0.9)
        resolver.collect_vote("agent-2", "option-b", confidence=0.5)
        resolver.collect_vote("agent-3", "option-a", confidence=0.8)
        result = resolver.resolve(method="weighted")
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._votes: list[Vote] = []

    def collect_vote(self, agent_id: str, option: str, confidence: float = 1.0) -> None:
        """Record a vote from an agent.

        Args:
            agent_id: The voting agent's ID.
            option: The option being voted for.
            confidence: Confidence weight (0.0 to 1.0).
        """
        confidence = max(0.0, min(1.0, confidence))
        vote = Vote(agent_id=agent_id, option=option, confidence=confidence)
        with self._lock:
            self._votes.append(vote)
        logger.debug("vote from=%s option=%s conf=%.2f", agent_id, option, confidence)

    def resolve(self, method: str = "majority") -> ConsensusResult:
        """Resolve votes to determine consensus.

        Args:
            method: "majority" for simple majority, "weighted" for
                confidence-weighted voting.

        Returns:
            ConsensusResult with winner, confidence, and vote counts.

        Raises:
            ValueError: If no votes have been collected.
        """
        with self._lock:
            votes = list(self._votes)

        if not votes:
            raise ValueError("No votes collected")

        if method == "weighted":
            return self._resolve_weighted(votes)
        return self._resolve_majority(votes)

    @staticmethod
    def _resolve_majority(votes: list[Vote]) -> ConsensusResult:
        """Simple majority: option with most votes wins."""
        counts: dict[str, int] = {}
        for vote in votes:
            counts[vote.option] = counts.get(vote.option, 0) + 1

        winner = max(counts, key=lambda k: counts[k])
        winner_count = counts[winner]
        total = len(votes)
        dissenting = total - winner_count

        return ConsensusResult(
            winner=winner,
            confidence=winner_count / total if total > 0 else 0.0,
            vote_count=total,
            dissenting_count=dissenting,
        )

    @staticmethod
    def _resolve_weighted(votes: list[Vote]) -> ConsensusResult:
        """Confidence-weighted: option with highest total weight wins."""
        weights: dict[str, float] = {}
        counts: dict[str, int] = {}
        for vote in votes:
            weights[vote.option] = weights.get(vote.option, 0.0) + vote.confidence
            counts[vote.option] = counts.get(vote.option, 0) + 1

        winner = max(weights, key=lambda k: weights[k])
        total_weight = sum(weights.values())
        winner_weight = weights[winner]
        total_votes = len(votes)
        winner_votes = counts[winner]

        return ConsensusResult(
            winner=winner,
            confidence=winner_weight / total_weight if total_weight > 0 else 0.0,
            vote_count=total_votes,
            dissenting_count=total_votes - winner_votes,
        )

    def reset(self) -> None:
        """Clear all collected votes."""
        with self._lock:
            self._votes.clear()

    @property
    def vote_count(self) -> int:
        """Number of votes collected."""
        with self._lock:
            return len(self._votes)


@dataclass
class HandoffDecision:
    """Result of a handoff evaluation."""

    approved: bool
    reason: str
    confidence_threshold: float


class HandoffProtocol:
    """Manage agent-to-agent delegation with confidence gating.

    Evaluates whether a handoff between agents should proceed based
    on a configurable confidence threshold.

    Args:
        confidence_threshold: Minimum confidence to approve (default 0.7).
    """

    def __init__(self, confidence_threshold: float = 0.7) -> None:
        self._threshold = confidence_threshold

    @property
    def confidence_threshold(self) -> float:
        """Current confidence threshold."""
        return self._threshold

    @confidence_threshold.setter
    def confidence_threshold(self, value: float) -> None:
        """Set confidence threshold (clamped to 0.0-1.0)."""
        self._threshold = max(0.0, min(1.0, value))

    def evaluate_handoff(
        self,
        from_agent: str,
        to_agent: str,
        context: str,
        confidence: float,
    ) -> HandoffDecision:
        """Evaluate whether a handoff should be approved.

        Args:
            from_agent: Source agent ID.
            to_agent: Target agent ID.
            context: Context/reason for the handoff.
            confidence: Confidence score for the handoff (0.0 to 1.0).

        Returns:
            HandoffDecision with approval status and reason.
        """
        confidence = max(0.0, min(1.0, confidence))

        if from_agent == to_agent:
            return HandoffDecision(
                approved=False,
                reason="Cannot handoff to the same agent",
                confidence_threshold=self._threshold,
            )

        if confidence >= self._threshold:
            reason = (
                f"Approved: confidence {confidence:.2f} >= "
                f"threshold {self._threshold:.2f}"
            )
            logger.debug(
                "handoff approved from=%s to=%s conf=%.2f",
                from_agent,
                to_agent,
                confidence,
            )
            return HandoffDecision(
                approved=True,
                reason=reason,
                confidence_threshold=self._threshold,
            )

        reason = (
            f"Rejected: confidence {confidence:.2f} < threshold {self._threshold:.2f}"
        )
        logger.debug(
            "handoff rejected from=%s to=%s conf=%.2f",
            from_agent,
            to_agent,
            confidence,
        )
        return HandoffDecision(
            approved=False,
            reason=reason,
            confidence_threshold=self._threshold,
        )
