"""PostgreSQL database connector implementation."""

from __future__ import annotations

import time
from typing import Any, Optional

from insight_engine.connectors.base import (
    ConnectionConfig,
    ConnectorRegistry,
    ConnectorType,
    DataConnector,
    QueryResult,
    TableInfo,
)


class PostgresConnector(DataConnector):
    """PostgreSQL database connector.

    This connector uses psycopg2 for database connectivity with support for
    connection pooling, parameterized queries, and schema introspection.

    Example:
        >>> config = ConnectionConfig(
        ...     connector_type=ConnectorType.POSTGRES,
        ...     host="localhost",
        ...     port=5432,
        ...     database="mydb",
        ...     username="user",
        ...     password="pass",
        ... )
        >>> with PostgresConnector(config) as conn:
        ...     result = conn.execute("SELECT * FROM users LIMIT 10")
        ...     df = result.to_dataframe()
    """

    def __init__(self, config: ConnectionConfig) -> None:
        """Initialize the PostgreSQL connector.

        Args:
            config: Connection configuration
        """
        super().__init__(config)
        self._pool: Any = None

    def connect(self) -> None:
        """Establish connection to PostgreSQL.

        Raises:
            ConnectionError: If connection fails
            ImportError: If psycopg2 is not installed
        """
        try:
            import psycopg2
            from psycopg2 import pool
        except ImportError:
            raise ImportError(
                "psycopg2 is required for PostgreSQL connectivity. "
                "Install with: pip install psycopg2-binary"
            )

        try:
            self._pool = pool.ThreadedConnectionPool(
                minconn=1,
                maxconn=self.config.pool_size,
                host=self.config.host or "localhost",
                port=self.config.port or 5432,
                database=self.config.database or "postgres",
                user=self.config.username,
                password=self.config.password,
                connect_timeout=self.config.timeout,
                **self.config.extra_params,
            )
            self._is_connected = True
        except psycopg2.Error as e:
            raise ConnectionError(f"Failed to connect to PostgreSQL: {e}") from e

    def disconnect(self) -> None:
        """Close all connections in the pool."""
        if self._pool:
            self._pool.closeall()
            self._pool = None
        self._is_connected = False

    def _get_connection(self) -> Any:
        """Get a connection from the pool.

        Returns:
            Database connection

        Raises:
            ConnectionError: If not connected
        """
        if not self._is_connected or not self._pool:
            raise ConnectionError("Not connected to database. Call connect() first.")
        return self._pool.getconn()

    def _return_connection(self, conn: Any) -> None:
        """Return a connection to the pool.

        Args:
            conn: Connection to return
        """
        if self._pool:
            self._pool.putconn(conn)

    def test_connection(self) -> bool:
        """Test if the connection is valid.

        Returns:
            True if connection is valid, False otherwise
        """
        try:
            conn = self._get_connection()
            try:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT 1")
                return True
            finally:
                self._return_connection(conn)
        except Exception:
            return False

    def execute(self, query: str, params: Optional[dict[str, Any]] = None) -> QueryResult:
        """Execute a SQL query and return results.

        Args:
            query: SQL query string
            params: Optional query parameters (named parameters)

        Returns:
            QueryResult with columns, rows, and metadata

        Raises:
            ConnectionError: If not connected
            QueryError: If query execution fails
        """
        import psycopg2

        start_time = time.time()
        conn = self._get_connection()

        try:
            with conn.cursor() as cursor:
                # Convert named parameters to psycopg2 format
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)

                # Get column names
                columns = [desc[0] for desc in cursor.description] if cursor.description else []

                # Fetch all rows
                rows = cursor.fetchall() if cursor.description else []

                # Commit for DDL/DML statements
                if not cursor.description:
                    conn.commit()

                execution_time = (time.time() - start_time) * 1000

                return QueryResult(
                    columns=columns,
                    rows=rows,
                    row_count=len(rows),
                    execution_time_ms=round(execution_time, 2),
                    query=query,
                )

        except psycopg2.Error as e:
            conn.rollback()
            return QueryResult(
                columns=[],
                rows=[],
                row_count=0,
                execution_time_ms=(time.time() - start_time) * 1000,
                query=query,
                error=str(e),
            )
        finally:
            self._return_connection(conn)

    def execute_many(self, query: str, params_list: list[dict[str, Any]]) -> int:
        """Execute a query multiple times with different parameters.

        Args:
            query: SQL query string
            params_list: List of parameter dictionaries

        Returns:
            Total number of affected rows

        Raises:
            ConnectionError: If not connected
            QueryError: If query execution fails
        """
        import psycopg2

        conn = self._get_connection()
        total_affected = 0

        try:
            with conn.cursor() as cursor:
                for params in params_list:
                    cursor.execute(query, params)
                    total_affected += cursor.rowcount
                conn.commit()
            return total_affected

        except psycopg2.Error as e:
            conn.rollback()
            raise RuntimeError(f"Batch execution failed: {e}") from e
        finally:
            self._return_connection(conn)

    def get_tables(self, schema: Optional[str] = None) -> list[TableInfo]:
        """Get list of tables in the database.

        Args:
            schema: Optional schema name to filter tables (default: public)

        Returns:
            List of TableInfo objects
        """
        schema = schema or self.config.schema or "public"

        query = """
            SELECT
                table_name,
                table_schema,
                (SELECT count(*) FROM information_schema.columns c
                 WHERE c.table_name = t.table_name AND c.table_schema = t.table_schema) as column_count
            FROM information_schema.tables t
            WHERE table_schema = %s
            AND table_type = 'BASE TABLE'
            ORDER BY table_name
        """

        result = self.execute(query, {"schema": schema})

        tables = []
        for row in result.rows:
            tables.append(
                TableInfo(
                    name=row[0],
                    schema=row[1],
                    column_count=row[2],
                )
            )

        return tables

    def get_table_schema(self, table_name: str, schema: Optional[str] = None) -> TableInfo:
        """Get detailed schema information for a table.

        Args:
            table_name: Name of the table
            schema: Optional schema name (default: public)

        Returns:
            TableInfo with column details
        """
        schema = schema or self.config.schema or "public"

        # Get column information
        columns_query = """
            SELECT
                column_name,
                data_type,
                is_nullable,
                column_default,
                character_maximum_length,
                numeric_precision,
                numeric_scale
            FROM information_schema.columns
            WHERE table_name = %s AND table_schema = %s
            ORDER BY ordinal_position
        """

        result = self.execute(columns_query, {"table_name": table_name, "schema": schema})

        columns = []
        for row in result.rows:
            columns.append(
                {
                    "name": row[0],
                    "type": row[1],
                    "nullable": row[2] == "YES",
                    "default": row[3],
                    "max_length": row[4],
                    "precision": row[5],
                    "scale": row[6],
                }
            )

        # Get row count estimate
        count_query = f'SELECT count(*) FROM "{schema}"."{table_name}"'
        count_result = self.execute(count_query)
        row_count = count_result.rows[0][0] if count_result.rows else None

        return TableInfo(
            name=table_name,
            schema=schema,
            row_count=row_count,
            column_count=len(columns),
            columns=columns,
        )

    def get_table_preview(
        self,
        table_name: str,
        schema: Optional[str] = None,
        limit: int = 100,
    ) -> QueryResult:
        """Get a preview of table data.

        Args:
            table_name: Name of the table
            schema: Optional schema name (default: public)
            limit: Maximum number of rows to return

        Returns:
            QueryResult with preview data
        """
        schema = schema or self.config.schema or "public"
        query = f'SELECT * FROM "{schema}"."{table_name}" LIMIT {limit}'
        return self.execute(query)

    def copy_to_dataframe(
        self,
        query: str,
        params: Optional[dict[str, Any]] = None,
        chunk_size: Optional[int] = None,
    ) -> Any:
        """Efficiently copy query results to a DataFrame using server-side cursor.

        Args:
            query: SQL query string
            params: Optional query parameters
            chunk_size: If provided, yield DataFrames in chunks

        Returns:
            pandas DataFrame or generator of DataFrames
        """
        import psycopg2

        conn = self._get_connection()

        try:
            if chunk_size:
                # Use named cursor for server-side cursor
                with conn.cursor(name="stream_cursor") as cursor:
                    if params:
                        cursor.execute(query, params)
                    else:
                        cursor.execute(query)

                    columns = [desc[0] for desc in cursor.description]

                    while True:
                        rows = cursor.fetchmany(chunk_size)
                        if not rows:
                            break
                        import pandas as pd

                        yield pd.DataFrame(rows, columns=columns)
            else:
                # Fetch all at once
                with conn.cursor() as cursor:
                    if params:
                        cursor.execute(query, params)
                    else:
                        cursor.execute(query)

                    columns = [desc[0] for desc in cursor.description]
                    rows = cursor.fetchall()
                    import pandas as pd

                    return pd.DataFrame(rows, columns=columns)

        finally:
            self._return_connection(conn)


# Register the connector
ConnectorRegistry.register(ConnectorType.POSTGRES, PostgresConnector)
