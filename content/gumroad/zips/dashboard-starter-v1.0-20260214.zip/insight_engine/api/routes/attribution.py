"""Attribution endpoint: POST /attribution - Marketing attribution analysis."""

from __future__ import annotations

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, status

from insight_engine.api.dependencies import common_dependencies
from insight_engine.api.models import (
    AttributionRequest,
    AttributionResponse,
    ChannelAttribution,
    Touchpoint,
)
from insight_engine.attribution import (
    AttributionModel,
    AttributionResult,
    first_touch,
    last_touch,
    linear,
    time_decay,
)

router = APIRouter(prefix="/attribution", tags=["attribution"])


def _result_to_response(result: AttributionResult) -> AttributionResponse:
    """Convert internal AttributionResult to API response model."""
    # Build channel details from summary DataFrame
    channels: list[ChannelAttribution] = []
    if not result.summary.empty:
        for _, row in result.summary.iterrows():
            channel = ChannelAttribution(
                channel=str(row.get("channel", "")),
                credit_pct=float(row.get("credit_pct", 0.0)),
            )
            if "conversions" in row:
                channel.conversions = int(row.get("conversions", 0))
            if "credit" in row:
                channel.credit = float(row.get("credit", 0.0))
            channels.append(channel)

    return AttributionResponse(
        model=result.model.value,
        channel_credits=result.channel_credits,
        total_conversions=result.total_conversions,
        channels=channels,
    )


def _touchpoints_to_dataframe(touchpoints: list[Touchpoint]) -> pd.DataFrame:
    """Convert API touchpoint models to DataFrame."""
    records = [
        {
            "user_id": tp.user_id,
            "channel": tp.channel,
            "timestamp": tp.timestamp,
        }
        for tp in touchpoints
    ]
    return pd.DataFrame(records)


@router.post(
    "",
    response_model=AttributionResponse,
    summary="Analyze marketing attribution",
    description="Apply attribution models to marketing touchpoint data to understand channel effectiveness.",
    responses={
        200: {
            "description": "Attribution analysis completed",
            "content": {
                "application/json": {
                    "example": {
                        "model": "first_touch",
                        "channel_credits": {
                            "google_ads": 35.5,
                            "facebook": 28.3,
                            "email": 22.1,
                            "organic": 14.1,
                        },
                        "total_conversions": 150,
                        "channels": [
                            {"channel": "google_ads", "conversions": 53, "credit_pct": 35.5},
                            {"channel": "facebook", "conversions": 42, "credit_pct": 28.3},
                        ],
                    }
                }
            },
        },
        400: {"description": "Invalid request data"},
        422: {"description": "Validation error"},
    },
)
async def attribution(
    request: AttributionRequest,
    deps: dict = Depends(common_dependencies),
) -> AttributionResponse:
    """Analyze marketing attribution for channel effectiveness.

    This endpoint:
    - Applies the specified attribution model to touchpoint data
    - Calculates credit distribution across channels
    - Returns conversion counts and credit percentages

    Supported models:
    - `first_touch`: All credit to first channel
    - `last_touch`: All credit to last channel
    - `linear`: Equal credit across all touchpoints
    - `time_decay`: More credit to recent touchpoints
    """
    try:
        # Validate touchpoints
        if not request.touchpoints:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No touchpoints provided",
            )

        # Validate conversions
        if not request.conversions:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No conversions provided",
            )

        # Convert to DataFrame
        df = _touchpoints_to_dataframe(request.touchpoints)
        conversions_set = set(request.conversions)

        # Validate model
        model_map = {
            "first_touch": first_touch,
            "last_touch": last_touch,
            "linear": linear,
            "time_decay": time_decay,
        }

        if request.model not in model_map:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid model '{request.model}'. Supported models: {list(model_map.keys())}",
            )

        # Run attribution
        result: AttributionResult = model_map[request.model](df, conversions_set)

        return _result_to_response(result)

    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error running attribution analysis: {str(e)}",
        )
