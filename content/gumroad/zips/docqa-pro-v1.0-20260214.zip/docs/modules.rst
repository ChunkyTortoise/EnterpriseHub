Python API Reference
====================

.. automodule:: docqa_engine
   :members:
   :undoc-members:
   :show-inheritance:

Core Modules
------------

Pipeline
~~~~~~~~

.. automodule:: docqa_engine.pipeline
   :members:
   :undoc-members:
   :show-inheritance:

Retriever
~~~~~~~~~

.. automodule:: docqa_engine.retriever
   :members:
   :undoc-members:
   :show-inheritance:

Answer
~~~~~~

.. automodule:: docqa_engine.answer
   :members:
   :undoc-members:
   :show-inheritance:

Ingest
~~~~~~

.. automodule:: docqa_engine.ingest
   :members:
   :undoc-members:
   :show-inheritance:

Chunking
~~~~~~~~

.. automodule:: docqa_engine.chunking
   :members:
   :undoc-members:
   :show-inheritance:

Vector Store
~~~~~~~~~~~~

.. automodule:: docqa_engine.vector_store
   :members:
   :undoc-members:
   :show-inheritance:

Embedding
~~~~~~~~~

.. automodule:: docqa_engine.embedder
   :members:
   :undoc-members:
   :show-inheritance:

Reranking
~~~~~~~~~

.. automodule:: docqa_engine.reranker
   :members:
   :undoc-members:
   :show-inheritance:

Query Expansion
~~~~~~~~~~~~~~~~

.. automodule:: docqa_engine.query_expansion
   :members:
   :undoc-members:
   :show-inheritance:

Context Compression
~~~~~~~~~~~~~~~~~~~

.. automodule:: docqa_engine.context_compressor
   :members:
   :undoc-members:
   :show-inheritance:

Multi-hop Retrieval
~~~~~~~~~~~~~~~~~~~

.. automodule:: docqa_engine.multi_hop
   :members:
   :undoc-members:
   :show-inheritance:

Citation Scoring
~~~~~~~~~~~~~~~~

.. automodule:: docqa_engine.citation_scorer
   :members:
   :undoc-members:
   :show-inheritance:

Answer Quality
~~~~~~~~~~~~~~

.. automodule:: docqa_engine.answer_quality
   :members:
   :undoc-members:
   :show-inheritance:

Conversation Management
~~~~~~~~~~~~~~~~~~~~~~~

.. automodule:: docqa_engine.conversation_manager
   :members:
   :undoc-members:
   :show-inheritance:

Document Graph
~~~~~~~~~~~~~~

.. automodule:: docqa_engine.document_graph
   :members:
   :undoc-members:
   :show-inheritance:

Summarization
~~~~~~~~~~~~~

.. automodule:: docqa_engine.summarizer
   :members:
   :undoc-members:
   :show-inheritance:

Batch Processing
~~~~~~~~~~~~~~~~

.. automodule:: docqa_engine.batch
   :members:
   :undoc-members:
   :show-inheritance:

REST API
~~~~~~~~

.. automodule:: docqa_engine.api
   :members:
   :undoc-members:
   :show-inheritance:

Evaluation
~~~~~~~~~~

.. automodule:: docqa_engine.evaluator
   :members:
   :undoc-members:
   :show-inheritance:

Benchmarking
~~~~~~~~~~~~

.. automodule:: docqa_engine.benchmark_runner
   :members:
   :undoc-members:
   :show-inheritance:

Export
~~~~~~

.. automodule:: docqa_engine.exporter
   :members:
   :undoc-members:
   :show-inheritance:

Cost Tracking
~~~~~~~~~~~~~

.. automodule:: docqa_engine.cost_tracker
   :members:
   :undoc-members:
   :show-inheritance:

Prompt Lab
~~~~~~~~~~

.. automodule:: docqa_engine.prompt_lab
   :members:
   :undoc-members:
   :show-inheritance:
