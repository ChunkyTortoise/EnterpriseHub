"""BigQuery database connector implementation (stub)."""

from __future__ import annotations

import time
from typing import Any, Optional

from insight_engine.connectors.base import (
    ConnectionConfig,
    ConnectorRegistry,
    ConnectorType,
    DataConnector,
    QueryResult,
    TableInfo,
)


class BigQueryConnector(DataConnector):
    """Google BigQuery database connector.

    This connector uses google-cloud-bigquery for database connectivity with
    support for service account authentication, query caching, and schema introspection.

    Note:
        This is a stub implementation. Full implementation requires:
        - google-cloud-bigquery package
        - GCP service account credentials
        - BigQuery API enabled in GCP project

    Example:
        >>> config = ConnectionConfig(
        ...     connector_type=ConnectorType.BIGQUERY,
        ...     project_id="my-gcp-project",
        ...     credentials_path="/path/to/service-account.json",
        ... )
        >>> with BigQueryConnector(config) as conn:
        ...     result = conn.execute("SELECT * FROM dataset.table LIMIT 10")
        ...     df = result.to_dataframe()
    """

    def __init__(self, config: ConnectionConfig) -> None:
        """Initialize the BigQuery connector.

        Args:
            config: Connection configuration
        """
        super().__init__(config)
        self._client: Any = None

    def connect(self) -> None:
        """Establish connection to BigQuery.

        Raises:
            ConnectionError: If connection fails
            ImportError: If google-cloud-bigquery is not installed
        """
        try:
            from google.cloud import bigquery
            from google.oauth2 import service_account
        except ImportError:
            raise ImportError(
                "google-cloud-bigquery is required for BigQuery connectivity. "
                "Install with: pip install google-cloud-bigquery"
            )

        try:
            if self.config.credentials_path:
                credentials = service_account.Credentials.from_service_account_file(
                    self.config.credentials_path
                )
                self._client = bigquery.Client(
                    project=self.config.project_id,
                    credentials=credentials,
                )
            else:
                # Use default credentials
                self._client = bigquery.Client(project=self.config.project_id)

            self._is_connected = True

        except Exception as e:
            raise ConnectionError(f"Failed to connect to BigQuery: {e}") from e

    def disconnect(self) -> None:
        """Close the BigQuery client connection."""
        if self._client:
            self._client.close()
            self._client = None
        self._is_connected = False

    def test_connection(self) -> bool:
        """Test if the connection is valid.

        Returns:
            True if connection is valid, False otherwise
        """
        if not self._is_connected or not self._client:
            return False

        try:
            # Run a simple query to test connection
            list(self._client.list_tables(max_results=1))
            return True
        except Exception:
            return False

    def execute(self, query: str, params: Optional[dict[str, Any]] = None) -> QueryResult:
        """Execute a SQL query and return results.

        Args:
            query: SQL query string
            params: Optional query parameters (BigQuery parameterized query format)

        Returns:
            QueryResult with columns, rows, and metadata

        Raises:
            ConnectionError: If not connected
            QueryError: If query execution fails
        """
        if not self._is_connected or not self._client:
            raise ConnectionError("Not connected to BigQuery. Call connect() first.")

        start_time = time.time()

        try:
            from google.cloud import bigquery

            # Configure query job
            job_config = bigquery.QueryJobConfig()
            if params:
                job_config.query_parameters = params

            # Execute query
            query_job = self._client.query(query, job_config=job_config)
            results = query_job.result()

            # Get column names
            columns = [field.name for field in results.schema] if results.schema else []

            # Fetch all rows
            rows = [tuple(row.values()) for row in results]

            execution_time = (time.time() - start_time) * 1000

            return QueryResult(
                columns=columns,
                rows=rows,
                row_count=len(rows),
                execution_time_ms=round(execution_time, 2),
                query=query,
            )

        except Exception as e:
            return QueryResult(
                columns=[],
                rows=[],
                row_count=0,
                execution_time_ms=(time.time() - start_time) * 1000,
                query=query,
                error=str(e),
            )

    def execute_many(self, query: str, params_list: list[dict[str, Any]]) -> int:
        """Execute a query multiple times with different parameters.

        Note:
            BigQuery doesn't support traditional batch inserts efficiently.
            Consider using load_table_from_dataframe for bulk operations.

        Args:
            query: SQL query string
            params_list: List of parameter dictionaries

        Returns:
            Total number of affected rows
        """
        total_affected = 0

        for params in params_list:
            result = self.execute(query, params)
            if result.error:
                raise RuntimeError(f"Batch execution failed: {result.error}")
            total_affected += result.row_count

        return total_affected

    def get_tables(self, schema: Optional[str] = None) -> list[TableInfo]:
        """Get list of tables in the dataset.

        Args:
            schema: Dataset ID (BigQuery equivalent of schema)

        Returns:
            List of TableInfo objects
        """
        if not self._is_connected or not self._client:
            raise ConnectionError("Not connected to BigQuery. Call connect() first.")

        tables = []

        try:
            if schema:
                dataset_ref = self._client.dataset(schema)
                table_list = self._client.list_tables(dataset_ref)
            else:
                table_list = self._client.list_tables()

            for table in table_list:
                tables.append(
                    TableInfo(
                        name=table.table_id,
                        schema=table.dataset_id,
                    )
                )

        except Exception as e:
            raise RuntimeError(f"Failed to list tables: {e}") from e

        return tables

    def get_table_schema(self, table_name: str, schema: Optional[str] = None) -> TableInfo:
        """Get detailed schema information for a table.

        Args:
            table_name: Name of the table
            schema: Dataset ID

        Returns:
            TableInfo with column details
        """
        if not self._is_connected or not self._client:
            raise ConnectionError("Not connected to BigQuery. Call connect() first.")

        try:
            if schema:
                table_ref = self._client.dataset(schema).table(table_name)
            else:
                table_ref = self._client.table(table_name)

            table = self._client.get_table(table_ref)

            columns = [
                {
                    "name": field.name,
                    "type": field.field_type,
                    "nullable": field.mode != "REQUIRED",
                    "description": field.description,
                }
                for field in table.schema
            ]

            return TableInfo(
                name=table_name,
                schema=schema,
                row_count=table.num_rows,
                column_count=len(columns),
                columns=columns,
            )

        except Exception as e:
            raise RuntimeError(f"Failed to get table schema: {e}") from e

    def get_table_preview(
        self,
        table_name: str,
        schema: Optional[str] = None,
        limit: int = 100,
    ) -> QueryResult:
        """Get a preview of table data.

        Args:
            table_name: Name of the table
            schema: Dataset ID
            limit: Maximum number of rows to return

        Returns:
            QueryResult with preview data
        """
        if schema:
            query = f"SELECT * FROM `{schema}.{table_name}` LIMIT {limit}"
        else:
            query = f"SELECT * FROM `{table_name}` LIMIT {limit}"

        return self.execute(query)

    def load_dataframe(
        self,
        df: Any,
        table_name: str,
        schema: Optional[str] = None,
        if_exists: str = "append",
    ) -> None:
        """Load a pandas DataFrame to BigQuery table.

        Args:
            df: pandas DataFrame to load
            table_name: Destination table name
            schema: Dataset ID
            if_exists: Behavior if table exists ('append', 'replace', 'fail')
        """
        if not self._is_connected or not self._client:
            raise ConnectionError("Not connected to BigQuery. Call connect() first.")

        from google.cloud import bigquery

        if schema:
            table_id = f"{self.config.project_id}.{schema}.{table_name}"
        else:
            table_id = f"{self.config.project_id}.{table_name}"

        job_config = bigquery.LoadJobConfig()

        if if_exists == "replace":
            job_config.write_disposition = bigquery.WriteDisposition.WRITE_TRUNCATE
        elif if_exists == "append":
            job_config.write_disposition = bigquery.WriteDisposition.WRITE_APPEND
        else:
            job_config.write_disposition = bigquery.WriteDisposition.WRITE_EMPTY

        job = self._client.load_table_from_dataframe(df, table_id, job_config=job_config)
        job.result()  # Wait for completion

    def to_dataframe(self, query: str, params: Optional[dict[str, Any]] = None) -> Any:
        """Execute query and return results as pandas DataFrame.

        This is more efficient than execute().to_dataframe() for BigQuery
        as it uses the native to_dataframe() method.

        Args:
            query: SQL query string
            params: Optional query parameters

        Returns:
            pandas DataFrame with query results
        """
        if not self._is_connected or not self._client:
            raise ConnectionError("Not connected to BigQuery. Call connect() first.")

        from google.cloud import bigquery

        job_config = bigquery.QueryJobConfig()
        if params:
            job_config.query_parameters = params

        query_job = self._client.query(query, job_config=job_config)
        return query_job.to_dataframe()


# Register the connector
ConnectorRegistry.register(ConnectorType.BIGQUERY, BigQueryConnector)
