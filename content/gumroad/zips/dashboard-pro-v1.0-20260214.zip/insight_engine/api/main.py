"""FastAPI application for insight-engine REST API."""

from __future__ import annotations

import logging
import os
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Callable

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from insight_engine import __version__
from insight_engine.api.dependencies import (
    configure_api_keys,
    configure_rate_limiting,
)
from insight_engine.api.models import HealthResponse
from insight_engine.api.routes import (
    attribution_router,
    forecast_router,
    predict_router,
    profile_router,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler for startup/shutdown events."""
    # Startup
    logger.info("Starting insight-engine API...")

    # Configure from environment
    api_keys_str = os.getenv("INSIGHT_API_KEYS", "")
    if api_keys_str:
        valid_keys = set(k.strip() for k in api_keys_str.split(",") if k.strip())
        configure_api_keys(enabled=True, valid_keys=valid_keys)
        logger.info(f"API key authentication enabled with {len(valid_keys)} key(s)")
    else:
        configure_api_keys(enabled=False)
        logger.info("API key authentication disabled")

    # Configure rate limiting from environment
    rpm = int(os.getenv("INSIGHT_RATE_LIMIT_RPM", "60"))
    rph = int(os.getenv("INSIGHT_RATE_LIMIT_RPH", "1000"))
    configure_rate_limiting(
        enabled=os.getenv("INSIGHT_RATE_LIMIT_ENABLED", "true").lower() == "true",
        requests_per_minute=rpm,
        requests_per_hour=rph,
    )
    logger.info(f"Rate limiting configured: {rpm} req/min, {rph} req/hour")

    yield

    # Shutdown
    logger.info("Shutting down insight-engine API...")


def create_app(
    title: str = "Insight Engine API",
    description: str = """
## Insight Engine API

A powerful analytics engine for automated data profiling, predictive modeling, 
time series forecasting, and marketing attribution analysis.

### Features

- **Data Profiling**: Automatic column type detection, distribution analysis, outlier detection, and data quality scoring
- **Predictive Modeling**: Auto-detect classification vs regression, train models with SHAP explainability
- **Time Series Forecasting**: Multiple methods (moving average, exponential smoothing, linear trend, ensemble)
- **Marketing Attribution**: First-touch, last-touch, linear, and time-decay attribution models

### Authentication

API key authentication is optional. When enabled, provide your key via:
- `Authorization: Bearer <api_key>` header
- `X-API-Key: <api_key>` header

### Rate Limiting

Default limits:
- 60 requests per minute
- 1000 requests per hour

Configure via environment variables:
- `INSIGHT_RATE_LIMIT_RPM`
- `INSIGHT_RATE_LIMIT_RPH`
""",
    version: str = __version__,
    cors_origins: list[str] | None = None,
) -> FastAPI:
    """Create and configure the FastAPI application.

    Args:
        title: API title for OpenAPI docs
        description: API description for OpenAPI docs
        version: API version
        cors_origins: List of allowed CORS origins

    Returns:
        Configured FastAPI application
    """
    app = FastAPI(
        title=title,
        description=description,
        version=version,
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        openapi_tags=[
            {
                "name": "profiling",
                "description": "Data profiling and quality analysis operations",
            },
            {
                "name": "prediction",
                "description": "Predictive modeling operations",
            },
            {
                "name": "forecasting",
                "description": "Time series forecasting operations",
            },
            {
                "name": "attribution",
                "description": "Marketing attribution analysis operations",
            },
        ],
    )

    # CORS middleware
    origins = cors_origins or [
        "http://localhost",
        "http://localhost:3000",
        "http://localhost:8000",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8000",
    ]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Request timing middleware
    @app.middleware("http")
    async def add_process_time_header(request: Request, call_next: Callable) -> Response:
        start_time = time.time()
        response = await call_next(request)
        process_time = time.time() - start_time
        response.headers["X-Process-Time"] = f"{process_time:.4f}"
        return response

    # Request logging middleware
    @app.middleware("http")
    async def log_requests(request: Request, call_next: Callable) -> Response:
        logger.info(f"Request: {request.method} {request.url.path}")
        response = await call_next(request)
        logger.info(f"Response: {request.method} {request.url.path} - {response.status_code}")
        return response

    # Exception handler
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.error(f"Unhandled exception: {exc}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={
                "error": "internal_server_error",
                "message": "An unexpected error occurred",
                "detail": str(exc) if os.getenv("INSIGHT_DEBUG", "").lower() == "true" else None,
            },
        )

    # Include routers
    app.include_router(profile_router, prefix="/api/v1")
    app.include_router(predict_router, prefix="/api/v1")
    app.include_router(forecast_router, prefix="/api/v1")
    app.include_router(attribution_router, prefix="/api/v1")

    # Health check endpoint
    @app.get(
        "/health",
        response_model=HealthResponse,
        tags=["health"],
        summary="Health check",
        description="Check if the API is running and healthy",
    )
    async def health_check() -> HealthResponse:
        """Health check endpoint for monitoring and load balancers."""
        return HealthResponse(
            status="healthy",
            version=__version__,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    # Root endpoint
    @app.get("/", tags=["root"], summary="API root", description="Get API information and available endpoints")
    async def root() -> dict:
        """Root endpoint with API information."""
        return {
            "name": "Insight Engine API",
            "version": __version__,
            "docs": "/docs",
            "redoc": "/redoc",
            "openapi": "/openapi.json",
            "endpoints": {
                "profile": "/api/v1/profile",
                "predict": "/api/v1/predict",
                "forecast": "/api/v1/forecast",
                "attribution": "/api/v1/attribution",
            },
        }

    return app


# Create default app instance
app = create_app()


def run_server(host: str = "0.0.0.0", port: int = 8000) -> None:
    """Run the API server using uvicorn.

    Args:
        host: Host to bind to
        port: Port to bind to
    """
    import uvicorn

    uvicorn.run(
        "insight_engine.api.main:app",
        host=host,
        port=port,
        reload=os.getenv("INSIGHT_DEBUG", "").lower() == "true",
    )


if __name__ == "__main__":
    run_server()
