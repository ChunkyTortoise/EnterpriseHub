#!/usr/bin/env python3
"""Backward-compatible CLI shim for AgentForge."""

from agentforge.cli import main

if __name__ == "__main__":
    main()
