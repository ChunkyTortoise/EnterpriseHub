"""REST API for AgentForge -- expose orchestration as an HTTP service."""

from __future__ import annotations

from typing import Any

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel

# --- Request/Response models ---


class ChatRequest(BaseModel):
    """Request body for the /chat endpoint."""

    provider: str
    message: str
    model: str | None = None
    max_tokens: int = 1024
    temperature: float = 0.7
    system_prompt: str = "You are a helpful assistant."


class ChatResponse(BaseModel):
    """Response body for chat endpoints."""

    content: str
    provider: str
    model: str
    tokens_used: int = 0
    latency_ms: float = 0.0


class TemplateInfo(BaseModel):
    """Schema for agent template metadata."""

    name: str
    description: str
    provider: str
    model: str
    system_prompt: str
    temperature: float


# --- Pre-built agent templates ---

AGENT_TEMPLATES: dict[str, dict[str, Any]] = {
    "code-reviewer": {
        "name": "Code Reviewer",
        "description": "Reviews code for bugs, style issues, and best practices",
        "provider": "anthropic",
        "model": "claude-3-5-sonnet-20241022",
        "system_prompt": (
            "You are an expert code reviewer. Analyze code for bugs, "
            "style issues, security vulnerabilities, and suggest improvements."
        ),
        "temperature": 0.3,
    },
    "creative-writer": {
        "name": "Creative Writer",
        "description": "Generates creative content like stories, poems, and marketing copy",
        "provider": "anthropic",
        "model": "claude-3-5-sonnet-20241022",
        "system_prompt": "You are a creative writer. Generate engaging, original content.",
        "temperature": 0.9,
    },
    "data-analyst": {
        "name": "Data Analyst",
        "description": "Analyzes data patterns and generates insights",
        "provider": "openai",
        "model": "gpt-4o",
        "system_prompt": (
            "You are a data analyst. Analyze data, identify patterns, "
            "and provide actionable insights."
        ),
        "temperature": 0.2,
    },
    "summarizer": {
        "name": "Summarizer",
        "description": "Summarizes long text into concise key points",
        "provider": "anthropic",
        "model": "claude-3-5-sonnet-20241022",
        "system_prompt": (
            "You are a summarization expert. Create clear, accurate summaries "
            "preserving key information."
        ),
        "temperature": 0.1,
    },
}


def create_api(orchestrator: Any = None) -> FastAPI:
    """Create FastAPI app for AgentForge."""
    app = FastAPI(title="AgentForge API", version="1.0.0")

    @app.get("/templates", response_model=list[TemplateInfo])
    async def list_templates() -> list[TemplateInfo]:
        return [TemplateInfo(**t) for t in AGENT_TEMPLATES.values()]

    @app.get("/templates/{name}", response_model=TemplateInfo)
    async def get_template(name: str) -> TemplateInfo:
        if name not in AGENT_TEMPLATES:
            raise HTTPException(status_code=404, detail=f"Template '{name}' not found")
        return TemplateInfo(**AGENT_TEMPLATES[name])

    @app.post("/chat", response_model=ChatResponse)
    async def chat(req: ChatRequest) -> ChatResponse:
        if orchestrator is None:
            # Demo mode
            return ChatResponse(
                content=f"Demo response for: {req.message}",
                provider=req.provider,
                model=req.model or "demo",
                tokens_used=len(req.message),
                latency_ms=0.0,
            )
        try:
            response = await orchestrator.chat(
                req.provider,
                req.message,
                model=req.model,
                max_tokens=req.max_tokens,
                temperature=req.temperature,
                system=req.system_prompt,
            )
            return ChatResponse(
                content=response.content,
                provider=req.provider,
                model=response.model,
                tokens_used=getattr(response, "total_tokens", 0),
                latency_ms=getattr(response, "elapsed_ms", 0.0),
            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e)) from e

    @app.post("/chat/template/{template_name}", response_model=ChatResponse)
    async def chat_with_template(
        template_name: str, message: str = Query(...)
    ) -> ChatResponse:
        if template_name not in AGENT_TEMPLATES:
            raise HTTPException(
                status_code=404,
                detail=f"Template '{template_name}' not found",
            )
        tmpl = AGENT_TEMPLATES[template_name]
        req = ChatRequest(
            provider=tmpl["provider"],
            message=message,
            model=tmpl["model"],
            system_prompt=tmpl["system_prompt"],
            temperature=tmpl["temperature"],
        )
        return await chat(req)

    return app
