"""API dependencies: authentication, rate limiting, and shared utilities."""

from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer


# ============================================================================
# Authentication
# ============================================================================

security = HTTPBearer(auto_error=False)


@dataclass
class APIKeyConfig:
    """Configuration for API key authentication."""

    enabled: bool = False
    valid_keys: set[str] = field(default_factory=set)
    header_name: str = "X-API-Key"


# Global API key configuration (can be set via environment)
_api_key_config = APIKeyConfig()


def configure_api_keys(enabled: bool = False, valid_keys: Optional[set[str]] = None) -> None:
    """Configure API key authentication.

    Args:
        enabled: Whether API key authentication is required
        valid_keys: Set of valid API keys
    """
    _api_key_config.enabled = enabled
    _api_key_config.valid_keys = valid_keys or set()


async def verify_api_key(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> Optional[str]:
    """Verify API key if authentication is enabled.

    Returns the API key if valid, None if auth is disabled.

    Raises:
        HTTPException: If API key is missing or invalid
    """
    if not _api_key_config.enabled:
        return None

    # Check Authorization header (Bearer token)
    api_key: Optional[str] = None
    if credentials:
        api_key = credentials.credentials

    # Check custom header
    if not api_key:
        api_key = request.headers.get(_api_key_config.header_name)

    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key required. Provide via Authorization: Bearer <key> or X-API-Key header.",
        )

    if api_key not in _api_key_config.valid_keys:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid API key.",
        )

    return api_key


# ============================================================================
# Rate Limiting
# ============================================================================


@dataclass
class RateLimitConfig:
    """Configuration for rate limiting."""

    enabled: bool = True
    requests_per_minute: int = 60
    requests_per_hour: int = 1000
    burst_size: int = 10


@dataclass
class ClientRateLimit:
    """Rate limit state for a single client."""

    minute_requests: list[float] = field(default_factory=list)
    hour_requests: list[float] = field(default_factory=list)


# Global rate limit state
_rate_limit_config = RateLimitConfig()
_rate_limits: dict[str, ClientRateLimit] = defaultdict(ClientRateLimit)


def configure_rate_limiting(
    enabled: bool = True,
    requests_per_minute: int = 60,
    requests_per_hour: int = 1000,
    burst_size: int = 10,
) -> None:
    """Configure rate limiting.

    Args:
        enabled: Whether rate limiting is enabled
        requests_per_minute: Maximum requests per minute per client
        requests_per_hour: Maximum requests per hour per client
        burst_size: Maximum burst size
    """
    _rate_limit_config.enabled = enabled
    _rate_limit_config.requests_per_minute = requests_per_minute
    _rate_limit_config.requests_per_hour = requests_per_hour
    _rate_limit_config.burst_size = burst_size


def _get_client_id(request: Request) -> str:
    """Get client identifier for rate limiting.

    Uses X-Forwarded-For header if available, otherwise client IP.
    """
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()

    if request.client:
        return request.client.host

    return "unknown"


def _cleanup_old_requests(requests: list[float], window_seconds: float) -> list[float]:
    """Remove requests older than the window."""
    cutoff = time.time() - window_seconds
    return [r for r in requests if r > cutoff]


async def check_rate_limit(request: Request) -> None:
    """Check rate limit for the current request.

    Raises:
        HTTPException: If rate limit is exceeded
    """
    if not _rate_limit_config.enabled:
        return

    client_id = _get_client_id(request)
    now = time.time()

    client_limits = _rate_limits[client_id]

    # Cleanup old requests
    client_limits.minute_requests = _cleanup_old_requests(client_limits.minute_requests, 60)
    client_limits.hour_requests = _cleanup_old_requests(client_limits.hour_requests, 3600)

    # Check minute limit
    if len(client_limits.minute_requests) >= _rate_limit_config.requests_per_minute:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={
                "error": "rate_limit_exceeded",
                "message": f"Rate limit exceeded: {_rate_limit_config.requests_per_minute} requests per minute",
                "retry_after": 60,
            },
        )

    # Check hour limit
    if len(client_limits.hour_requests) >= _rate_limit_config.requests_per_hour:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={
                "error": "rate_limit_exceeded",
                "message": f"Rate limit exceeded: {_rate_limit_config.requests_per_hour} requests per hour",
                "retry_after": 3600,
            },
        )

    # Record this request
    client_limits.minute_requests.append(now)
    client_limits.hour_requests.append(now)


# ============================================================================
# Combined Dependencies
# ============================================================================


async def common_dependencies(
    request: Request,
    api_key: Optional[str] = Depends(verify_api_key),
) -> dict:
    """Common dependencies for all API endpoints.

    Returns:
        Dictionary with client info and API key (if authenticated)
    """
    await check_rate_limit(request)

    return {
        "client_id": _get_client_id(request),
        "api_key": api_key,
    }


# ============================================================================
# Request Context
# ============================================================================


@dataclass
class RequestContext:
    """Context for a single API request."""

    request_id: str
    client_id: str
    api_key: Optional[str]
    start_time: float


def get_request_context(request: Request, deps: dict = Depends(common_dependencies)) -> RequestContext:
    """Get request context for logging and tracing."""
    import uuid

    return RequestContext(
        request_id=str(uuid.uuid4()),
        client_id=deps["client_id"],
        api_key=deps["api_key"],
        start_time=time.time(),
    )
