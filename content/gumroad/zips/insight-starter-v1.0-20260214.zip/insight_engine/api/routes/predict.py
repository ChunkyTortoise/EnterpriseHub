"""Predict endpoint: POST /predict - Predictive modeling."""

from __future__ import annotations

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, status

from insight_engine.api.dependencies import common_dependencies
from insight_engine.api.models import PredictRequest, PredictResponse
from insight_engine.predictor import PredictionResult, train_model

router = APIRouter(prefix="/predict", tags=["prediction"])


@router.post(
    "",
    response_model=PredictResponse,
    summary="Train a predictive model",
    description="Auto-detect task type (classification/regression), train a model, and return performance metrics with feature importances.",
    responses={
        200: {
            "description": "Model trained successfully",
            "content": {
                "application/json": {
                    "example": {
                        "task_type": "classification",
                        "target_column": "churn",
                        "metrics": {"accuracy": 0.85, "f1_weighted": 0.83},
                        "feature_importances": {
                            "tenure": 0.35,
                            "monthly_charges": 0.25,
                            "total_charges": 0.20,
                        },
                        "feature_names": ["tenure", "monthly_charges", "total_charges"],
                    }
                }
            },
        },
        400: {"description": "Invalid request data or target column not found"},
        422: {"description": "Validation error"},
    },
)
async def predict(
    request: PredictRequest,
    deps: dict = Depends(common_dependencies),
) -> PredictResponse:
    """Train a predictive model on the provided dataset.

    This endpoint:
    - Auto-detects whether the task is classification or regression
    - Trains a Gradient Boosting model
    - Returns performance metrics and feature importances
    - Optionally computes SHAP values for explainability

    The target column must be present in the dataset.
    """
    try:
        # Convert list of dicts to DataFrame
        if not request.data:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Empty dataset provided",
            )

        df = pd.DataFrame(request.data)

        if df.empty:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Empty dataset provided",
            )

        # Validate target column exists
        if request.target not in df.columns:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Target column '{request.target}' not found in dataset. Available columns: {list(df.columns)}",
            )

        # Train the model
        result: PredictionResult = train_model(
            df=df,
            target=request.target,
            test_size=request.test_size,
            random_state=request.random_state,
        )

        return PredictResponse(
            task_type=result.task_type,
            target_column=result.target_column,
            metrics=result.metrics,
            feature_importances=result.feature_importances,
            feature_names=result.feature_names,
        )

    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error training model: {str(e)}",
        )
