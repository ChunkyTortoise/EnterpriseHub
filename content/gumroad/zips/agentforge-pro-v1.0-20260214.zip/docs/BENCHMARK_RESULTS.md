# AgentForge Benchmark Results

**Date**: February 8, 2026
**Environment**: macOS (Darwin 25.2.0), Python 3.14
**AgentForge Version**: 0.1.0

## Provider Health Status

| Provider   | Status      | API Key Configured |
|------------|-------------|--------------------|
| Gemini     | unavailable | No                 |
| Perplexity | unavailable | No (auth error)    |
| Claude     | unavailable | No                 |
| OpenAI     | unavailable | No                 |
| Mock       | ok          | N/A (always on)    |

## Benchmark Results (Mock Provider)

Since no API keys were configured at the time of this benchmark run, only the mock provider
returned results. The mock provider simulates realistic latency (50-200ms jitter) and returns
canned responses matched by keyword detection.

### Default Prompt: "Explain the concept of dependency injection in 2-3 sentences."

| Provider   | Model         | Time  | Tokens | Est. Cost |
|------------|---------------|-------|--------|-----------|
| Gemini     | (not configured) | -  | -      | -         |
| Perplexity | (auth error)  | -     | -      | -         |
| Claude     | (not configured) | -  | -      | -         |
| OpenAI     | (not configured) | -  | -      | -         |
| Mock       | mock-instant  | 93ms  | 45     | $0.0000   |

### Prompt: "Explain quantum computing"

| Provider   | Model         | Time  | Tokens | Est. Cost |
|------------|---------------|-------|--------|-----------|
| Gemini     | (not configured) | -  | -      | -         |
| Perplexity | (auth error)  | -     | -      | -         |
| Claude     | (not configured) | -  | -      | -         |
| OpenAI     | (not configured) | -  | -      | -         |
| Mock       | mock-instant  | 173ms | 95     | $0.0000   |

### Prompt: "Explain machine learning fundamentals"

| Provider   | Model         | Time  | Tokens | Est. Cost |
|------------|---------------|-------|--------|-----------|
| Gemini     | (not configured) | -  | -      | -         |
| Perplexity | (auth error)  | -     | -      | -         |
| Claude     | (not configured) | -  | -      | -         |
| OpenAI     | (not configured) | -  | -      | -         |
| Mock       | mock-instant  | 191ms | 66     | $0.0000   |

### Prompt: "What is Python used for?"

| Provider   | Model         | Time  | Tokens | Est. Cost |
|------------|---------------|-------|--------|-----------|
| Gemini     | (not configured) | -  | -      | -         |
| Perplexity | (auth error)  | -     | -      | -         |
| Claude     | (not configured) | -  | -      | -         |
| OpenAI     | (not configured) | -  | -      | -         |
| Mock       | mock-instant  | 53ms  | 46     | $0.0000   |

## Mock Provider Summary

| Prompt                        | Latency | Response Tokens | Keyword Match     |
|-------------------------------|---------|-----------------|-------------------|
| Dependency injection          | 93ms    | 45              | default (generic) |
| Quantum computing             | 173ms   | 95              | "quantum"         |
| Machine learning fundamentals | 191ms   | 66              | "machine learning"|
| Python usage                  | 53ms    | 46              | "python"          |

**Average mock latency**: ~128ms (simulated 50-200ms jitter range)

## Cost Model (per 1K tokens)

| Provider   | Est. Cost/1K Tokens |
|------------|---------------------|
| Claude     | $0.008              |
| OpenAI     | $0.006              |
| Perplexity | $0.003              |
| Gemini     | $0.002              |
| Mock       | $0.000              |

## How to Run With Real Providers

To get real benchmark results, configure API keys in `.env`:

```bash
cp .env.example .env
# Add your keys:
# ANTHROPIC_API_KEY=sk-ant-...
# GEMINI_API_KEY=AI...
# OPENAI_API_KEY=sk-...
# PERPLEXITY_API_KEY=pplx-...

agentforge benchmark
agentforge benchmark --prompt "Your custom prompt here"
```

## Architecture Notes

- **Benchmark CLI**: `agentforge benchmark` (defined in `agentforge/cli.py`)
- **Standalone script**: `python -m benchmarks.run_benchmarks` (in `benchmarks/run_benchmarks.py`)
- **Providers tested**: Gemini, Perplexity, Claude, OpenAI, Mock
- **Max tokens**: 256 (CLI benchmark), 50 (standalone script)
- **Temperature**: 0.2
- **Retry policy**: 3 attempts with exponential backoff
