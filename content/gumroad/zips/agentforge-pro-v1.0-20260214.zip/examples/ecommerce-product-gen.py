"""E-commerce product description generation with A/B testing framework.

This example demonstrates:
- Batch content generation with cost optimization
- Structured output for product attributes
- A/B test variant generation
- Fallback routing for high-volume scenarios

Use case: E-commerce platforms generating product descriptions at scale.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import list
from agentforge import AIOrchestrator, StructuredOutput
from agentforge.cost_tracker import CostTracker


@dataclass
class Product:
    """E-commerce product data."""
    sku: str
    name: str
    category: str
    features: list[str]
    specifications: dict[str, str]
    target_audience: str
    tone: str = "professional"


# Sample products
SAMPLE_PRODUCTS = [
    Product(
        sku="TECH-001",
        name="Wireless Noise-Canceling Headphones",
        category="Electronics",
        features=[
            "Active noise cancellation",
            "40-hour battery life",
            "Bluetooth 5.3",
            "Multi-device pairing",
            "Comfortable over-ear design"
        ],
        specifications={
            "weight": "250g",
            "driver_size": "40mm",
            "frequency_response": "20Hz-20kHz",
            "impedance": "32 ohms"
        },
        target_audience="Remote workers and travelers",
        tone="professional"
    ),
    Product(
        sku="HOME-042",
        name="Smart Indoor Garden",
        category="Home & Garden",
        features=[
            "Self-watering system",
            "LED grow lights",
            "App-controlled scheduling",
            "Grows herbs, vegetables, flowers",
            "Compact countertop design"
        ],
        specifications={
            "capacity": "6 pods",
            "dimensions": "15x8x12 inches",
            "power": "20W LED",
            "water_reservoir": "2L"
        },
        target_audience="Urban apartment dwellers",
        tone="friendly"
    )
]


class ProductDescriptionGenerator:
    """Generate e-commerce product content with cost optimization."""
    
    def __init__(self):
        # Use fallback chain for cost optimization
        self.orchestrator = AIOrchestrator(
            temperature=0.7,
            fallback_chain=["gemini", "openai", "claude"]  # Cost-optimized order
        )
        self.cost_tracker = CostTracker()
        self.structured = StructuredOutput()
    
    async def generate_description(self, product: Product) -> dict:
        """Generate SEO-optimized product description."""
        
        prompt = f"""
        Write a compelling product description for:
        
        Product: {product.name}
        Category: {product.category}
        Target Audience: {product.target_audience}
        Tone: {product.tone}
        
        Key Features:
        {chr(10).join(f"- {f}" for f in product.features)}
        
        Specifications:
        {chr(10).join(f"- {k}: {v}" for k, v in product.specifications.items())}
        
        Requirements:
        - 150-200 words
        - Include primary keyword naturally
        - Highlight top 3 benefits
        - End with call-to-action
        - Tone: {product.tone}
        """
        
        # Use cost-optimized provider with fallback
        response = await self.orchestrator.chat("gemini", prompt)
        
        # Track cost
        self.cost_tracker.record_request(
            provider=response.provider,
            model=response.model,
            prompt_tokens=len(prompt) // 4,
            completion_tokens=len(response.content) // 4
        )
        
        return {
            "sku": product.sku,
            "description": response.content,
            "provider_used": response.provider,
            "generation_time_ms": response.elapsed_ms
        }
    
    async def generate_variants(self, product: Product, variant_count: int = 3) -> list[dict]:
        """
        Generate A/B test variants for product description.
        
        Each variant tests a different angle:
        - Variant A: Feature-focused
        - Variant B: Benefit-focused  
        - Variant C: Story/emotion-focused
        """
        
        variants = []
        angles = [
            ("features", "Focus on technical specifications and features"),
            ("benefits", "Focus on how it improves customer's life"),
            ("story", "Tell a story about using the product")
        ]
        
        for i, (angle, focus) in enumerate(angles[:variant_count]):
            prompt = f"""
            Write product description for {product.name}.
            
            Angle: {angle.upper()}
            Focus: {focus}
            Tone: {product.tone}
            
            Key points to include:
            {chr(10).join(f"- {f}" for f in product.features)}
            
            Requirements:
            - 100-150 words
            - Test this specific angle: {angle}
            - Same product, different approach
            """
            
            response = await self.orchestrator.chat("gemini", prompt)
            
            variants.append({
                "variant_id": f"{product.sku}-{chr(65+i)}",  # A, B, C
                "angle": angle,
                "description": response.content,
                "word_count": len(response.content.split())
            })
        
        return variants
    
    async def generate_batch(self, products: list[Product]) -> list[dict]:
        """Generate descriptions for multiple products with cost tracking."""
        
        print(f"🚀 Batch generation for {len(products)} products")
        print(f"   Provider chain: gemini → openai → claude (cost-optimized)")
        print("-" * 50)
        
        results = []
        for product in products:
            result = await self.generate_description(product)
            results.append(result)
            print(f"✅ {product.sku}: {result['provider_used']} "
                  f"({result['generation_time_ms']:.0f}ms)")
        
        return results
    
    def get_cost_report(self) -> dict:
        """Get detailed cost breakdown."""
        return {
            "total_cost": self.cost_tracker.session_total(),
            "provider_breakdown": self.cost_tracker.provider_breakdown(),
            "request_count": self.cost_tracker.session_count()
        }


async def main():
    """Demo product description generation."""
    
    print("🛒 E-commerce Product Description Generator")
    print("=" * 50)
    
    generator = ProductDescriptionGenerator()
    
    # Generate descriptions
    results = await generator.generate_batch(SAMPLE_PRODUCTS)
    
    # Display sample output
    print("\n" + "=" * 50)
    print("📄 SAMPLE OUTPUT (TECH-001)")
    print("=" * 50)
    print(results[0]["description"][:300] + "...")
    
    # Generate A/B test variants
    print("\n" + "=" * 50)
    print("🧪 A/B TEST VARIANTS")
    print("=" * 50)
    
    variants = await generator.generate_variants(SAMPLE_PRODUCTS[0], variant_count=3)
    
    for variant in variants:
        print(f"\n{variant['variant_id']} ({variant['angle'].upper()})")
        print(f"Words: {variant['word_count']}")
        print(variant['description'][:200] + "...")
    
    # Cost report
    print("\n" + "=" * 50)
    print("💰 COST REPORT")
    print("=" * 50)
    
    report = generator.get_cost_report()
    print(f"Total Cost: ${report['total_cost']:.4f}")
    print(f"Requests: {report['request_count']}")
    print(f"Cost per description: ${report['total_cost'] / report['request_count']:.4f}")
    
    print("\n💡 Using Gemini as primary (cheapest), with OpenAI/Claude fallback")
    print("   Est. savings vs using Claude exclusively: ~60%")


if __name__ == "__main__":
    asyncio.run(main())
