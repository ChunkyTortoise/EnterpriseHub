import asyncio

from agentforge import AIOrchestrator


async def main() -> None:
    orc = AIOrchestrator()
    async for chunk in orc.stream("openai", "Write a haiku about lightning"):
        print(chunk, end="", flush=True)
    print("")


if __name__ == "__main__":
    asyncio.run(main())
