"""Prompt template engine with variable extraction, rendering, and built-in templates."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

logger = logging.getLogger("agentforge.prompt_template")


@dataclass
class PromptTemplate:
    """A reusable prompt template with variable substitution.

    Variables use {{variable_name}} syntax.
    """

    name: str
    template: str
    description: str = ""
    variables: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Auto-extract variables from template if not provided."""
        if not self.variables:
            self.variables = self.extract_variables()

    def extract_variables(self) -> list[str]:
        """Extract {{variable}} names from template."""
        return sorted(set(re.findall(r"\{\{(\w+)\}\}", self.template)))

    def render(self, **kwargs: str) -> str:
        """Render template with provided variables.

        Raises ValueError if required variables are missing.
        """
        missing = [v for v in self.variables if v not in kwargs]
        if missing:
            raise ValueError(f"Missing variables: {missing}")
        result = self.template
        for key, value in kwargs.items():
            result = result.replace(f"{{{{{key}}}}}", str(value))
        return result

    def partial(self, **kwargs: str) -> PromptTemplate:
        """Create a new template with some variables filled in."""
        rendered = self.template
        for key, value in kwargs.items():
            rendered = rendered.replace(f"{{{{{key}}}}}", str(value))
        return PromptTemplate(
            name=f"{self.name}_partial",
            template=rendered,
            description=self.description,
        )


class PromptRegistry:
    """Registry of prompt templates with 5 built-in templates."""

    def __init__(self) -> None:
        self._templates: dict[str, PromptTemplate] = {}
        self._register_builtins()

    def _register_builtins(self) -> None:
        """Register 5 built-in templates."""
        builtins = [
            PromptTemplate(
                name="classify",
                template=(
                    "Classify the following text into one of these categories:"
                    " {{categories}}\n\nText: {{text}}\n\nCategory:"
                ),
                description="Text classification",
            ),
            PromptTemplate(
                name="extract",
                template=(
                    "Extract the following information from the text:"
                    " {{fields}}\n\nText: {{text}}\n\nExtracted (JSON):"
                ),
                description="Information extraction",
            ),
            PromptTemplate(
                name="summarize",
                template=(
                    "Summarize the following {{content_type}} in {{length}}"
                    " sentences:\n\n{{text}}\n\nSummary:"
                ),
                description="Text summarization",
            ),
            PromptTemplate(
                name="qa",
                template=(
                    "Answer the question based on the context below.\n\n"
                    "Context: {{context}}\n\nQuestion: {{question}}\n\nAnswer:"
                ),
                description="Question answering",
            ),
            PromptTemplate(
                name="code_review",
                template=(
                    "Review the following {{language}} code for bugs, style"
                    " issues, and improvements:\n\n```{{language}}\n{{code}}"
                    "\n```\n\nReview:"
                ),
                description="Code review",
            ),
        ]
        for t in builtins:
            self._templates[t.name] = t

    def register(self, template: PromptTemplate) -> None:
        """Register a custom template."""
        self._templates[template.name] = template
        logger.debug("registered template=%s", template.name)

    def get(self, name: str) -> PromptTemplate | None:
        """Get a template by name."""
        return self._templates.get(name)

    def list_templates(self) -> list[PromptTemplate]:
        """List all templates."""
        return list(self._templates.values())

    def render(self, name: str, **kwargs: str) -> str:
        """Get and render a template by name.

        Raises KeyError if template not found.
        """
        template = self._templates.get(name)
        if template is None:
            raise KeyError(f"Template not found: {name}")
        return template.render(**kwargs)
