"""Shared types for AgentForge."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AIResponse:
    """Structured response from any LLM provider."""

    content: str
    provider: str
    model: str
    elapsed_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)
